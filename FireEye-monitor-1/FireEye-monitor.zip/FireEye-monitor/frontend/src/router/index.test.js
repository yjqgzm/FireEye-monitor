import { describe, it, expect, beforeEach } from 'vitest'
import { createRouter, createWebHistory } from 'vue-router'
import { setActivePinia, createPinia } from 'pinia'

const MockComponent = { template: '<div></div>' }

const routes = [
  { path: '/login', name: 'Login', component: MockComponent },
  { path: '/', name: 'Dashboard', component: MockComponent },
  { path: '/system', name: 'System', component: MockComponent }
]

function createTestRouter() {
  return createRouter({
    history: createWebHistory(),
    routes
  })
}

describe('Router Guards', () => {
  let router

  beforeEach(async () => {
    setActivePinia(createPinia())
    localStorage.clear()
    router = createTestRouter()
    router.beforeEach((to, from, next) => {
      const token = localStorage.getItem('token')
      if (to.path === '/system' && !token) {
        next('/login')
      } else if (to.path === '/login' && token) {
        next('/')
      } else {
        next()
      }
    })
    router.push('/')
    await router.isReady()
  })

  it('allows access to login page without token', async () => {
    await router.push('/login')
    expect(router.currentRoute.value.path).toBe('/login')
  })

  it('redirects to login when accessing protected route without token', async () => {
    localStorage.removeItem('token')
    await router.push('/system')
    expect(router.currentRoute.value.path).toBe('/login')
  })

  it('allows access to protected route with token', async () => {
    localStorage.setItem('token', 'test-token')
    await router.push('/')
    expect(router.currentRoute.value.path).toBe('/')
  })

  it('redirects to dashboard when accessing login with token', async () => {
    localStorage.setItem('token', 'test-token')
    await router.push('/login')
    await router.isReady()
    expect(router.currentRoute.value.path).toBe('/')
  })
})
