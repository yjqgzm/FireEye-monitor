<template>
  <div :class="['history-page', { 'light-mode': isLightMode }]">
    <div class="page-hero">
      <div class="hero-pattern"></div>
      <div class="hero-content">
        <h1>历史数据</h1>
        <p>查看温度趋势与环境变化历史记录，回溯全量监测数据</p>
      </div>
    </div>

    <div class="toolbar">
      <div class="toolbar-left">
        <el-select v-model="filterDevice" placeholder="选择设备" clearable @change="fetchHistory" style="width:180px">
          <el-option v-for="d in devices" :key="d.id" :label="d.name" :value="d.id" />
        </el-select>
        <el-date-picker v-model="dateRange" type="datetimerange" range-separator="至" start-placeholder="开始时间" end-placeholder="结束时间" @change="fetchHistory" style="width:340px" />
        <el-button-group>
          <el-button size="small" @click="setQuickRange('today')">今天</el-button>
          <el-button size="small" @click="setQuickRange('yesterday')">昨天</el-button>
          <el-button size="small" @click="setQuickRange('7d')">近7天</el-button>
          <el-button size="small" @click="setQuickRange('30d')">近30天</el-button>
        </el-button-group>
        <el-button type="primary" @click="fetchHistory">查询</el-button>
      </div>
      <div class="toolbar-right">
        <el-dropdown @command="handleExport">
          <el-button plain size="small"><el-icon><Download /></el-icon> 导出数据</el-button>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="csv">CSV格式</el-dropdown-item>
              <el-dropdown-item command="excel">Excel格式</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </div>

    <div class="stats-row">
      <div class="stat-card"><span class="stat-label">最高物体温度</span><span class="stat-value" :class="getTempClass(stats.maxTemp)">{{ stats.maxTemp?.toFixed(1) || '--' }}°C</span></div>
      <div class="stat-card"><span class="stat-label">最低物体温度</span><span class="stat-value">{{ stats.minTemp?.toFixed(1) || '--' }}°C</span></div>
      <div class="stat-card"><span class="stat-label">平均温度</span><span class="stat-value">{{ stats.avgTemp?.toFixed(1) || '--' }}°C</span></div>
      <div class="stat-card"><span class="stat-label">最高烟雾浓度</span><span class="stat-value" :class="stats.maxSmoke > 600 ? 'danger' : ''">{{ stats.maxSmoke || '--' }}</span></div>
      <div class="stat-card"><span class="stat-label">温度超标次数</span><span class="stat-value" :class="stats.tempOverCount > 0 ? 'warning' : ''">{{ stats.tempOverCount || 0 }}</span></div>
      <div class="stat-card"><span class="stat-label">烟雾超标次数</span><span class="stat-value" :class="stats.smokeOverCount > 0 ? 'danger' : ''">{{ stats.smokeOverCount || 0 }}</span></div>
      <div class="stat-card"><span class="stat-label">预警触发次数</span><span class="stat-value" :class="stats.alertCount > 0 ? 'warning' : ''">{{ stats.alertCount || 0 }}</span></div>
    </div>

    <div class="charts-section">
      <div class="card-module">
        <h3>温度趋势</h3>
        <div ref="trendChartRef" class="chart-container"></div>
      </div>
      <div class="card-module">
        <h3>环境趋势</h3>
        <div ref="humidityChartRef" class="chart-container"></div>
      </div>
    </div>

    <div class="card-module table-section">
      <h3>历史记录</h3>
      <el-table :data="paginatedData" v-loading="loading" size="small" style="width:100%"
        :header-cell-style="{ background:'var(--bg-elevated)', color:'var(--text-secondary)', borderColor:'var(--border-subtle)' }"
        :cell-style="{ background:'var(--bg-card)', borderColor:'var(--border-subtle)' }">
        <el-table-column prop="timestamp" label="时间" min-width="140">
          <template #default="{ row }">{{ formatTime(row.timestamp) }}</template>
        </el-table-column>
        <el-table-column label="物体温度" min-width="100">
          <template #default="{ row }"><span :class="getTempClass(row.temperature)">{{ row.temperature?.toFixed(1) || '--' }}°C</span></template>
        </el-table-column>
        <el-table-column label="环境温度" min-width="100">
          <template #default="{ row }">{{ row.ambient_temp?.toFixed(1) || '--' }}°C</template>
        </el-table-column>
        <el-table-column label="湿度" min-width="80">
          <template #default="{ row }">{{ row.humidity?.toFixed(0) || '--' }}%</template>
        </el-table-column>
        <el-table-column label="烟雾值" min-width="80">
          <template #default="{ row }"><span :class="{ danger: row.smoke_value > 600 }">{{ row.smoke_value || '--' }}</span></template>
        </el-table-column>
      </el-table>
      <div class="pagination" v-if="historyData.length > pageSize">
        <el-pagination v-model:current-page="currentPage" :page-size="pageSize" :total="historyData.length" layout="prev, pager, next" small />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, nextTick, inject, watch } from 'vue'
import * as echarts from 'echarts'
import api from '@/api'

const devices = ref([])
const historyData = ref([])
const isLightMode = inject('isLightMode', ref(false))
const filterDevice = ref('')
const dateRange = ref(null)
const loading = ref(false)
const currentPage = ref(1)
const pageSize = 20

const trendChartRef = ref(null)
const humidityChartRef = ref(null)
let trendChart = null
let humidityChart = null
let refreshTimer = null

const stats = computed(() => {
  const data = historyData.value
  if (!data.length) return {}
  const temps = data.map(d => d.temperature).filter(Boolean)
  const smokes = data.map(d => d.smoke_value).filter(Boolean)
  return {
    maxTemp: temps.length ? Math.max(...temps) : null,
    minTemp: temps.length ? Math.min(...temps) : null,
    avgTemp: temps.length ? temps.reduce((a, b) => a + b, 0) / temps.length : null,
    maxSmoke: smokes.length ? Math.max(...smokes) : null,
    tempOverCount: temps.filter(t => t >= 60).length,
    smokeOverCount: smokes.filter(s => s > 600).length,
    alertCount: data.filter(d => d.temperature >= 45 || (d.smoke_value || 0) > 600).length
  }
})

const paginatedData = computed(() => {
  const start = (currentPage.value - 1) * pageSize
  return historyData.value.slice(start, start + pageSize)
})

async function fetchDevices() {
  try {
    devices.value = await api.get('/api/devices')
    if (devices.value.length > 0 && !filterDevice.value) {
      filterDevice.value = devices.value[0].id
      await fetchHistory()
    }
  } catch (e) { console.error(e) }
}

async function fetchHistory(silent = false) {
  if (!filterDevice.value) return
  if (!silent) loading.value = true
  try {
    let hours = 24
    if (dateRange.value && dateRange.value[0] && dateRange.value[1]) {
      const diffMs = new Date(dateRange.value[1]).getTime() - new Date(dateRange.value[0]).getTime()
      hours = Math.max(1, Math.ceil(diffMs / 3600000))
    }
    const res = await api.get(`/api/data/trend?device_id=${filterDevice.value}&hours=${hours}`)
    historyData.value = res.data || []
    updateCharts()
  } catch (e) { console.error(e) } finally { if (!silent) loading.value = false }
}

function setQuickRange(type) {
  const now = new Date()
  let start
  switch (type) {
    case 'today': start = new Date(now.getFullYear(), now.getMonth(), now.getDate()); break
    case 'yesterday': start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1); dateRange.value = [start, new Date(now.getFullYear(), now.getMonth(), now.getDate())]; fetchHistory(); return
    case '7d': start = new Date(now.getTime() - 7 * 86400000); break
    case '30d': start = new Date(now.getTime() - 30 * 86400000); break
  }
  dateRange.value = [start, now]
  fetchHistory()
}

function getChartAxisStyle() {
  const light = isLightMode.value
  return {
    axisLine: { lineStyle: { color: light ? '#E5E6EB' : '#2a3555' } },
    axisLabel: { color: light ? '#4E5969' : '#8892a0', fontSize: 10 },
    splitLine: { lineStyle: { color: light ? '#E5E6EB' : '#2a3555', type: 'dashed', opacity: light ? 0.6 : 0.3 } }
  }
}

function updateCharts() {
  const data = historyData.value
  const hours = dateRange.value && dateRange.value[0] && dateRange.value[1]
    ? Math.ceil((new Date(dateRange.value[1]).getTime() - new Date(dateRange.value[0]).getTime()) / 3600000)
    : 24
  const times = data.map(d => {
    if (!d.timestamp) return ''
    if (hours > 6) {
      const date = new Date(d.timestamp)
      return `${(date.getMonth()+1).toString().padStart(2,'0')}-${date.getDate().toString().padStart(2,'0')} ${date.getHours().toString().padStart(2,'0')}:${date.getMinutes().toString().padStart(2,'0')}`
    }
    return d.timestamp.split('T')[1]?.slice(0, 5) || ''
  })

  if (trendChart) {
    trendChart.setOption({
      xAxis: { data: times },
      series: [
        { data: data.map(d => d.temperature) },
        { data: data.map(d => d.smoke_value || 0) }
      ]
    }, false, true)
  }

  if (humidityChart) {
    humidityChart.setOption({
      xAxis: { data: times },
      series: [
        { data: data.map(d => d.ambient_temp) },
        { data: data.map(d => d.humidity) }
      ]
    }, false, true)
  }
}

function initCharts() {
  nextTick(() => {
    if (trendChartRef.value) {
      trendChart = echarts.init(trendChartRef.value)
      const light = isLightMode.value
      const textColor = light ? '#4E5969' : '#8892a0'
      const nameColor = light ? '#4E5969' : '#8892a0'
      trendChart.setOption({
        tooltip: { trigger: 'axis', confine: true, transitionDuration: 0.2 },
        legend: { data: ['物体温度', '烟雾浓度'], textStyle: { color: textColor, fontSize: 11 }, top: 0 },
        grid: { left: '10%', right: '4%', bottom: '3%', top: '36px', containLabel: true },
        xAxis: { type: 'category', boundaryGap: false, ...getChartAxisStyle() },
        yAxis: [
          { type: 'value', name: '温度(°C)', nameLocation: 'middle', nameGap: 40, nameTextStyle: { color: nameColor, fontSize: 11 }, ...getChartAxisStyle() },
          { type: 'value', name: '烟雾(ppm)', nameTextStyle: { color: nameColor, fontSize: 10 }, axisLine: { show: false }, axisLabel: { color: textColor, fontSize: 10 }, splitLine: { show: false } }
        ],
        dataZoom: [{ type: 'inside' }],
        animationDuration: 500, animationEasing: 'cubicOut',
        series: [
          { name: '物体温度', type: 'line', smooth: 0.4, showSymbol: false, lineStyle: { color: '#165DFF', width: 2.5 }, areaStyle: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(22,93,255,0.25)' }, { offset: 1, color: 'rgba(22,93,255,0)' }]) }, markLine: { silent: true, symbol: 'none', data: [{ yAxis: 45, label: { formatter: '预警45°C', fontSize: 9, color: '#FFAA00' }, lineStyle: { color: '#FFAA00', type: 'dashed', width: 1 } }, { yAxis: 60, label: { formatter: '报警60°C', fontSize: 9, color: '#F53F3F' }, lineStyle: { color: '#F53F3F', type: 'dashed', width: 1.5 } }] } },
          { name: '烟雾浓度', type: 'bar', yAxisIndex: 1, barWidth: '50%', itemStyle: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: '#FF7D00' }, { offset: 1, color: '#FFAA00' }]), borderRadius: [2, 2, 0, 0] }, markLine: { silent: true, data: [{ yAxis: 600, label: { formatter: '阈值600', fontSize: 9, color: '#F53F3F' } }], lineStyle: { color: '#F53F3F', type: 'dashed', width: 1.5 } } }
        ]
      })
    }
    if (humidityChartRef.value) {
      humidityChart = echarts.init(humidityChartRef.value)
      const light = isLightMode.value
      const textColor = light ? '#4E5969' : '#8892a0'
      const nameColor = light ? '#4E5969' : '#8892a0'
      humidityChart.setOption({
        tooltip: { trigger: 'axis', confine: true, transitionDuration: 0.2 },
        legend: { data: ['环境温度', '环境湿度'], textStyle: { color: textColor, fontSize: 11 }, top: 0 },
        grid: { left: '10%', right: '4%', bottom: '3%', top: '36px', containLabel: true },
        xAxis: { type: 'category', boundaryGap: false, ...getChartAxisStyle() },
        yAxis: [
          { type: 'value', name: '温度(°C)', nameLocation: 'middle', nameGap: 40, nameTextStyle: { color: nameColor, fontSize: 11 }, ...getChartAxisStyle() },
          { type: 'value', name: '湿度(%)', min: 0, max: 100, nameTextStyle: { color: nameColor, fontSize: 10 }, axisLine: { show: false }, axisLabel: { color: textColor, fontSize: 10 }, splitLine: { show: false } }
        ],
        dataZoom: [{ type: 'inside' }],
        animationDuration: 500, animationEasing: 'cubicOut',
        series: [
          { name: '环境温度', type: 'line', smooth: 0.4, showSymbol: false, lineStyle: { color: '#165DFF', width: 2 }, areaStyle: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(22,93,255,0.12)' }, { offset: 1, color: 'rgba(22,93,255,0)' }]) } },
          { name: '环境湿度', type: 'line', smooth: 0.4, showSymbol: false, yAxisIndex: 1, lineStyle: { color: '#0FC6C2', width: 2 }, areaStyle: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(15,198,194,0.15)' }, { offset: 1, color: 'rgba(15,198,194,0)' }]) } }
        ]
      })
    }
    updateCharts()
  })
}

watch(isLightMode, () => {
  if (trendChart || humidityChart) {
    initCharts()
    updateCharts()
  }
})

function handleExport(format) {
  const data = historyData.value
  if (!data.length) { return }
  const headers = ['时间', '物体温度', '环境温度', '湿度', '烟雾值']
  const rows = data.map(d => [formatTime(d.timestamp), d.temperature?.toFixed(1), d.ambient_temp?.toFixed(1), d.humidity?.toFixed(0), d.smoke_value || ''])
  const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n')
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a'); a.href = url; a.download = `history_data.${format === 'excel' ? 'csv' : format}`; a.click(); URL.revokeObjectURL(url)
}

function getTempClass(temp) { if (!temp) return ''; if (temp >= 80) return 'danger'; if (temp >= 60) return 'warning'; if (temp >= 45) return 'caution'; return 'normal' }
function formatTime(timeStr) { if (!timeStr) return ''; return new Date(timeStr).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }) }

function handleResize() { ;[trendChart, humidityChart].forEach(c => c?.resize()) }

onMounted(async () => {
  await fetchDevices()
  initCharts()
  window.addEventListener('resize', handleResize)
  refreshTimer = setInterval(() => {
    if (filterDevice.value) fetchHistory(true)
  }, 3000)
})
onUnmounted(() => { ;[trendChart, humidityChart].forEach(c => c?.dispose()); window.removeEventListener('resize', handleResize); if (refreshTimer) clearInterval(refreshTimer) })
</script>

<style scoped>
.history-page { height:100%; overflow-y:auto; }

.page-hero {
  position:relative; height:100px; border-radius:var(--radius-md);
  overflow:hidden; margin-bottom:16px;
  background:linear-gradient(135deg, #121826, #0c2e3b, #0a2540);
  animation:fade-in-up 0.4s var(--ease-out) both;
}
.hero-pattern { position:absolute; inset:0; background-image:radial-gradient(circle at 20% 80%, rgba(6,182,212,0.12) 0%, transparent 50%); }
.hero-content { position:relative; z-index:1; padding:24px 28px; display:flex; flex-direction:column; justify-content:flex-end; height:100%; }
.hero-content h1 { font-size:22px; font-weight:700; color:var(--text-primary); margin:0 0 2px 0; letter-spacing:2px; }
.hero-content p { font-size:13px; color:var(--text-secondary); margin:0; }

.toolbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; gap:10px; flex-wrap:wrap; }
.toolbar-left { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.toolbar-right { display:flex; align-items:center; gap:8px; }

.stats-row { display:grid; grid-template-columns:repeat(7, 1fr); gap:10px; margin-bottom:14px; }
.stat-card {
  display:flex; flex-direction:column; align-items:center; gap:4px;
  padding:10px 12px; border-radius:var(--radius-md);
  background:var(--bg-card); border:1px solid var(--border-subtle);
  animation:fade-in-up 0.4s var(--ease-out) both;
}
.stat-label { font-size:10px; color:var(--text-muted); text-align:center; }
.stat-value { font-size:16px; font-weight:700; color:var(--text-primary); font-family:var(--font-num); font-variant-numeric:tabular-nums; }
.stat-value.warning { color:#FF7D00; }
.stat-value.danger { color:#F53F3F; }
.stat-value.cautio { color:#165DFF; }

.charts-section { display:flex; flex-direction:column; gap:14px; margin-bottom:14px; }
.chart-container { height:260px; }

.card-module { background:var(--bg-card); border:1px solid var(--border-subtle); border-radius:var(--radius-md); padding:14px; animation:fade-in-up 0.4s var(--ease-out) both; }
.card-module h3 { font-size:13px; font-weight:600; color:var(--text-primary); margin:0 0 10px 0; }

.table-section { margin-bottom:14px; }
.pagination { display:flex; justify-content:flex-end; margin-top:12px; }

.normal { color:#00B42A; }
.cautio { color:#165DFF; }
.warning { color:#FF7D00; }
.danger { color:#F53F3F; }

:deep(.el-table) { --el-table-border-color: var(--border-subtle); --el-table-header-bg-color: var(--bg-elevated); --el-table-row-hover-bg-color: var(--bg-hover); --el-table-bg-color: var(--bg-card); --el-table-tr-bg-color: var(--bg-card); color: var(--text-primary); }
:deep(.el-table th.el-table__cell) { color: var(--text-secondary); font-weight: 600; }

@keyframes fade-in-up { from { opacity:0; transform:translateY(12px); } to { opacity:1; transform:translateY(0); } }

@media (max-width:1200px) { .stats-row { grid-template-columns:repeat(4, 1fr); } }
@media (max-width:768px) { .stats-row { grid-template-columns:repeat(2, 1fr); } .toolbar { flex-direction:column; } }

.light-mode .page-hero { background:linear-gradient(135deg, #E8F0FE, #D4E8FC, #C4D8F0); }
.light-mode .hero-content h1 { color:#1D2129; }
.light-mode .hero-content p { color:#4E5969; }
.light-mode .stat-card { background:#FFFFFF; border-color:#E5E6EB; }
.light-mode .stat-label { color:#86909C; }
.light-mode .stat-value { color:#1D2129; }
.light-mode .card-module { background:#FFFFFF; border-color:#E5E6EB; }
.light-mode .card-module h3 { color:#1D2129; }
.light-mode :deep(.el-table) { --el-table-bg-color:#FFFFFF; --el-table-tr-bg-color:#FFFFFF; --el-table-header-bg-color:#F7F8FA; --el-table-row-hover-bg-color:#F2F3F5; --el-table-border-color:#E5E6EB; color:#1D2129; }
.light-mode :deep(.el-table th.el-table__cell) { color:#4E5969; }
</style>
