<template>
  <div class="system-page">
    <el-tabs v-model="activeTab">
      <el-tab-pane label="用户管理" name="users">
        <div class="section-header">
          <el-button type="primary" @click="openUserDialog()">添加用户</el-button>
        </div>
        <el-table :data="users" v-loading="loading">
          <el-table-column prop="username" label="用户名" />
          <el-table-column prop="role" label="角色">
            <template #default="{ row }">
              <el-tag :type="row.role === 'admin' ? 'danger' : 'info'">
                {{ row.role === 'admin' ? '管理员' : '普通用户' }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="email" label="邮箱" />
          <el-table-column prop="is_active" label="状态">
            <template #default="{ row }">
              <el-tag :type="row.is_active ? 'success' : 'danger'">
                {{ row.is_active ? '启用' : '禁用' }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="is_invited" label="用户类型">
            <template #default="{ row }">
              <el-tag :type="row.is_invited ? '' : 'warning'" size="small">
                {{ row.is_invited ? '邀请用户' : '基础用户' }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="last_login" label="最后登录">
            <template #default="{ row }">
              {{ row.last_login ? formatTime(row.last_login) : '从未' }}
            </template>
          </el-table-column>
          <el-table-column label="操作" width="150">
            <template #default="{ row }">
              <el-button text type="danger" @click="deleteUser(row)" :disabled="row.username === 'admin'">
                删除
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
      
      <el-tab-pane label="预警配置" name="alert-config">
        <div class="config-grid">
          <div v-for="config in alertConfigs" :key="config.id" class="config-card glass-card">
            <h4>{{ getSceneName(config.scene_type) }}</h4>
            <el-form label-width="100px" size="small">
              <el-form-item label="一级温度">
                <el-input-number v-model="config.level1_threshold" :min="0" :max="150" :step="1" />
                <span>°C</span>
              </el-form-item>
              <el-form-item label="一级温升">
                <el-input-number v-model="config.level1_rate" :min="0" :max="20" :step="0.5" />
                <span>°C/min</span>
              </el-form-item>
              <el-form-item label="二级温度">
                <el-input-number v-model="config.level2_threshold" :min="0" :max="150" :step="1" />
                <span>°C</span>
              </el-form-item>
              <el-form-item label="二级温升">
                <el-input-number v-model="config.level2_rate" :min="0" :max="20" :step="0.5" />
                <span>°C/min</span>
              </el-form-item>
              <el-form-item label="三级温度">
                <el-input-number v-model="config.level3_threshold" :min="0" :max="150" :step="1" />
                <span>°C</span>
              </el-form-item>
              <el-form-item label="三级温升">
                <el-input-number v-model="config.level3_rate" :min="0" :max="20" :step="0.5" />
                <span>°C/min</span>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" size="small" @click="saveAlertConfig(config)">
                  保存配置
                </el-button>
              </el-form-item>
            </el-form>
          </div>
        </div>
      </el-tab-pane>
      <el-tab-pane label="邀请码管理" name="invite-codes">
        <div class="section-header">
          <div class="invite-gen-row">
            <el-input-number v-model="inviteGenCount" :min="1" :max="50" size="small" />
            <span class="gen-label">个邀请码</span>
            <el-input-number v-model="inviteGenMaxUses" :min="1" :max="100" size="small" />
            <span class="gen-label">次可用</span>
            <el-input v-model="inviteGenDesc" placeholder="备注（选填）" size="small" style="width: 180px" />
            <el-button type="primary" size="small" @click="generateInviteCodes">生成</el-button>
          </div>
        </div>
        <el-table :data="inviteCodes" v-loading="inviteLoading">
          <el-table-column prop="code" label="邀请码" width="180">
            <template #default="{ row }">
              <span class="code-text">{{ row.code }}</span>
              <el-button text size="small" @click="copyCode(row.code)">复制</el-button>
            </template>
          </el-table-column>
          <el-table-column prop="is_used" label="状态" width="100">
            <template #default="{ row }">
              <el-tag :type="row.is_used ? 'info' : 'success'" size="small">
                {{ row.is_used ? '已用完' : '可用' }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column label="使用情况" width="120">
            <template #default="{ row }">
              {{ row.use_count }} / {{ row.max_uses }}
            </template>
          </el-table-column>
          <el-table-column prop="description" label="备注" />
          <el-table-column prop="created_at" label="创建时间">
            <template #default="{ row }">
              {{ row.created_at ? formatTime(row.created_at) : '-' }}
            </template>
          </el-table-column>
          <el-table-column label="操作" width="80">
            <template #default="{ row }">
              <el-button text type="danger" size="small" @click="deleteInviteCode(row.id)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
      
      <el-tab-pane label="AI服务" name="ai-config">
        <div class="ai-config-section">
          <div class="ai-provider-grid">
            <div v-for="p in providerList" :key="p.value"
              :class="['provider-card', { active: aiConfig.provider === p.value }]"
              @click="selectProvider(p.value)">
              <div class="provider-icon">{{ p.icon }}</div>
              <div class="provider-name">{{ p.label }}</div>
            </div>
          </div>

          <div class="ai-form-area">
            <div class="form-row">
              <label>选择模型</label>
              <el-select v-model="aiConfig.model" placeholder="选择模型" style="flex:1" filterable allow-create>
                <el-option v-for="m in currentModels" :key="m.value" :label="m.label" :value="m.value">
                  <span>{{ m.label }}</span>
                  <span style="float:right;color:var(--text-muted);font-size:11px">{{ m.tag }}</span>
                </el-option>
              </el-select>
            </div>
            <div class="form-row">
              <label>API Key</label>
              <div class="key-input-group">
                <el-input v-model="aiConfig.apiKey" :placeholder="placeholderForProvider(aiConfig.provider)" show-password style="flex:1" />
                <el-tag v-if="hasExistingKey && !aiConfig.apiKey" type="warning" size="small" class="key-hint">已配置，留空保持不变</el-tag>
              </div>
            </div>
            <div class="form-actions">
              <el-button type="primary" @click="saveAiConfig" :loading="aiSaving">保存配置</el-button>
              <el-button @click="testAiConfig" :loading="aiTesting" :type="testResult === 'success' ? 'success' : testResult === 'fail' ? 'danger' : 'default'">
                {{ testResult === 'success' ? '连接成功' : testResult === 'fail' ? '连接失败' : '测试连接' }}
              </el-button>
            </div>
            <div v-if="testMessage" :class="['test-result', testResult]">
              <el-icon v-if="testResult === 'success'"><SuccessFilled /></el-icon>
              <el-icon v-else-if="testResult === 'fail'"><CircleCloseFilled /></el-icon>
              {{ testMessage }}
            </div>
          </div>

          <div class="ai-help-cards">
            <div class="help-card">
              <h4>配置说明</h4>
              <ol>
                <li>选择AI服务商（点击卡片）</li>
                <li>从下拉列表选择模型</li>
                <li>填入该平台的API Key</li>
                <li>点击"测试连接"验证</li>
                <li>预警等级≥2时，手动点击"AI分析"触发</li>
              </ol>
            </div>
            <div class="help-card">
              <h4>获取API Key</h4>
              <ul>
                <li><strong>智谱GLM</strong>：open.bigmodel.cn → API Keys</li>
                <li><strong>通义千问</strong>：dashscope.aliyun.com → API-KEY</li>
                <li><strong>DeepSeek</strong>：platform.deepseek.com → API Keys</li>
                <li><strong>文心一言</strong>：qianfan.baidubce.com → AK/SK</li>
                <li><strong>OpenAI</strong>：platform.openai.com → API Keys</li>
              </ul>
            </div>
          </div>
        </div>
      </el-tab-pane>
      
      <el-tab-pane label="系统日志" name="logs">
        <div class="filters">
          <el-input v-model="logFilter" placeholder="搜索操作日志" clearable style="width: 200px" />
          <el-button @click="fetchLogs">查询</el-button>
          <el-button @click="exportLogs">导出</el-button>
        </div>
        <el-table :data="logs" v-loading="loading" max-height="400">
          <el-table-column prop="timestamp" label="时间" width="180">
            <template #default="{ row }">
              {{ formatTime(row.timestamp) }}
            </template>
          </el-table-column>
          <el-table-column prop="username" label="用户" width="120" />
          <el-table-column prop="action" label="操作" />
          <el-table-column prop="details" label="详情" />
          <el-table-column prop="ip_address" label="IP地址" width="120" />
        </el-table>
      </el-tab-pane>
    </el-tabs>
    
    <el-dialog v-model="userDialogVisible" title="添加用户" width="400px">
      <el-form ref="userFormRef" :model="userForm" :rules="userRules" label-width="80px">
        <el-form-item label="用户名" prop="username">
          <el-input v-model="userForm.username" />
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input v-model="userForm.password" type="password" show-password />
        </el-form-item>
        <el-form-item label="角色" prop="role">
          <el-select v-model="userForm.role">
            <el-option label="普通用户" value="user" />
            <el-option label="管理员" value="admin" />
          </el-select>
        </el-form-item>
        <el-form-item label="邮箱" prop="email">
          <el-input v-model="userForm.email" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="userDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitUser">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import api from '@/api'
import { ElMessage, ElMessageBox } from 'element-plus'
import { SuccessFilled, CircleCloseFilled } from '@element-plus/icons-vue'

const activeTab = ref('users')
const loading = ref(false)
const users = ref([])
const logs = ref([])
const alertConfigs = ref([])
const logFilter = ref('')
const inviteCodes = ref([])
const inviteLoading = ref(false)
const inviteGenCount = ref(1)
const inviteGenMaxUses = ref(1)
const inviteGenDesc = ref('')

const aiConfig = reactive({
  provider: 'qwen',
  model: '',
  apiKey: ''
})
const hasExistingKey = ref(false)
const aiSaving = ref(false)
const aiTesting = ref(false)
const testResult = ref('')
const testMessage = ref('')

const providerList = [
  { value: 'zhipu', label: '智谱GLM', icon: '🧠' },
  { value: 'qwen', label: '通义千问', icon: '☁️' },
  { value: 'deepseek', label: 'DeepSeek', icon: '🔍' },
  { value: 'baidu', label: '文心一言', icon: '📝' },
  { value: 'openai', label: 'OpenAI', icon: '🌍' }
]

const MODEL_MAP = {
  zhipu: [
    { value: 'glm-4-flash', label: 'GLM-4-Flash', tag: '免费/快速' },
    { value: 'glm-4-air', label: 'GLM-4-Air', tag: '均衡' },
    { value: 'glm-4-airx', label: 'GLM-4-AirX', tag: '高性价比' },
    { value: 'glm-4-long', label: 'GLM-4-Long', tag: '长文本' },
    { value: 'glm-4-plus', label: 'GLM-4-Plus', tag: '高级' },
    { value: 'glm-4', label: 'GLM-4', tag: '旗舰' },
    { value: 'glm-4v', label: 'GLM-4V', tag: '多模态' }
  ],
  qwen: [
    { value: 'qwen-turbo', label: 'Qwen-Turbo', tag: '快速' },
    { value: 'qwen-plus', label: 'Qwen-Plus', tag: '均衡' },
    { value: 'qwen-max', label: 'Qwen-Max', tag: '旗舰' },
    { value: 'qwen-long', label: 'Qwen-Long', tag: '长文本' }
  ],
  deepseek: [
    { value: 'deepseek-chat', label: 'DeepSeek-Chat', tag: '通用' },
    { value: 'deepseek-reasoner', label: 'DeepSeek-Reasoner', tag: '推理' }
  ],
  baidu: [
    { value: 'ernie-speed-128k', label: 'ERNIE-Speed-128K', tag: '快速' },
    { value: 'ernie-lite-8k', label: 'ERNIE-Lite-8K', tag: '轻量' },
    { value: 'ernie-4.0-8k', label: 'ERNIE-4.0-8K', tag: '旗舰' },
    { value: 'ernie-4.0-turbo-8k', label: 'ERNIE-4.0-Turbo', tag: '高级' }
  ],
  openai: [
    { value: 'gpt-4o-mini', label: 'GPT-4o-Mini', tag: '快速' },
    { value: 'gpt-4o', label: 'GPT-4o', tag: '旗舰' },
    { value: 'gpt-4-turbo', label: 'GPT-4-Turbo', tag: '高级' },
    { value: 'gpt-3.5-turbo', label: 'GPT-3.5-Turbo', tag: '经济' }
  ]
}

const currentModels = computed(() => MODEL_MAP[aiConfig.provider] || [])

const userDialogVisible = ref(false)
const userFormRef = ref(null)
const userForm = reactive({
  username: '',
  password: '',
  role: 'user',
  email: ''
})

const userRules = {
  username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
  password: [{ required: true, message: '请输入密码', trigger: 'blur' }],
  role: [{ required: true, message: '请选择角色', trigger: 'change' }]
}

async function fetchUsers() {
  try {
    const res = await api.get('/api/users')
    users.value = res
  } catch (e) {
    console.error(e)
  }
}

async function fetchAlertConfigs() {
  try {
    const res = await api.get('/api/config/alert')
    alertConfigs.value = res
  } catch (e) {
    console.error(e)
  }
}

async function fetchAiConfig() {
  try {
    const res = await api.get('/api/config/system')
    aiConfig.provider = res.ai_provider || 'zhipu'
    if (res.ai_model) {
      aiConfig.model = res.ai_model
    } else {
      const models = MODEL_MAP[aiConfig.provider]
      aiConfig.model = models && models.length > 0 ? models[0].value : ''
    }
    if (res.ai_api_key && res.ai_api_key.startsWith('***')) {
      hasExistingKey.value = true
      aiConfig.apiKey = ''
    } else {
      hasExistingKey.value = !!res.ai_api_key
      aiConfig.apiKey = res.ai_api_key || ''
    }
  } catch (e) {
    console.error(e)
  }
}

function defaultModelForProvider(provider) {
  const map = { qwen: 'qwen-turbo', baidu: 'ernie-speed-128k', zhipu: 'glm-4-flash', deepseek: 'deepseek-chat', openai: 'gpt-4o-mini' }
  return map[provider] || 'qwen-turbo'
}

function placeholderForProvider(provider) {
  const map = {
    qwen: '请输入通义千问API Key（DashScope）',
    baidu: '请输入文心一言API Key（千帆平台）',
    zhipu: '请输入智谱GLM API Key（开放平台）',
    deepseek: '请输入DeepSeek API Key',
    openai: '请输入OpenAI API Key'
  }
  return map[provider] || '请输入API Key'
}

async function fetchLogs() {
  loading.value = true
  try {
    const res = await api.get(`/api/logs?limit=100&action=${logFilter.value}`)
    logs.value = res
  } catch (e) {
    console.error(e)
  } finally {
    loading.value = false
  }
}

function openUserDialog() {
  userForm.username = ''
  userForm.password = ''
  userForm.role = 'user'
  userForm.email = ''
  userDialogVisible.value = true
}

async function submitUser() {
  if (!userFormRef.value) return
  await userFormRef.value.validate(async (valid) => {
    if (!valid) return
    try {
      await api.post('/api/users', userForm)
      ElMessage.success('用户添加成功')
      userDialogVisible.value = false
      fetchUsers()
    } catch (e) {
      console.error(e)
    }
  })
}

async function deleteUser(user) {
  try {
    await ElMessageBox.confirm(`确定要删除用户 "${user.username}" 吗?`, '警告', { type: 'error' })
    await api.delete(`/api/users/${user.id}`)
    ElMessage.success('用户删除成功')
    fetchUsers()
  } catch (e) {
    if (e !== 'cancel') console.error(e)
  }
}

async function saveAlertConfig(config) {
  try {
    await api.put(`/api/config/alert/${config.scene_type}`, config)
    ElMessage.success('配置保存成功')
  } catch (e) {
    console.error(e)
  }
}

async function saveAiConfig() {
  aiSaving.value = true
  try {
    await api.put('/api/config/system', { config_key: 'ai_provider', config_value: aiConfig.provider })
    await api.put('/api/config/system', { config_key: 'ai_model', config_value: aiConfig.model })
    if (aiConfig.apiKey) {
      await api.put('/api/config/system', { config_key: 'ai_api_key', config_value: aiConfig.apiKey })
      hasExistingKey.value = true
    }
    testResult.value = ''
    testMessage.value = ''
    ElMessage.success('AI配置保存成功')
    await fetchAiConfig()
  } catch (e) {
    ElMessage.error('保存失败')
    console.error(e)
  } finally {
    aiSaving.value = false
  }
}

async function testAiConfig() {
  aiTesting.value = true
  testResult.value = ''
  testMessage.value = ''
  try {
    if (!aiConfig.apiKey && !hasExistingKey.value) {
      testResult.value = 'fail'
      testMessage.value = '请先填写API Key并保存配置'
      return
    }
    if (aiConfig.apiKey) {
      await api.put('/api/config/system', { config_key: 'ai_api_key', config_value: aiConfig.apiKey })
      hasExistingKey.value = true
    }
    const res = await api.post('/api/config/test-ai')
    if (res.success) {
      testResult.value = 'success'
      testMessage.value = `连接成功！模型: ${res.model || '默认'}, 响应时间: ${res.response_time || '-'}ms`
    } else {
      testResult.value = 'fail'
      testMessage.value = res.message || '连接失败，请检查API Key和网络'
    }
  } catch (e) {
    testResult.value = 'fail'
    testMessage.value = e.response?.data?.detail || '连接失败，请检查配置'
  } finally {
    aiTesting.value = false
  }
}

function selectProvider(value) {
  aiConfig.provider = value
  const models = MODEL_MAP[value]
  if (models && models.length > 0) {
    aiConfig.model = models[0].value
  } else {
    aiConfig.model = ''
  }
  testResult.value = ''
  testMessage.value = ''
}

function exportLogs() {
  const headers = ['时间', '用户', '操作', '详情', 'IP']
  const rows = logs.value.map(l => [
    formatTime(l.timestamp),
    l.username,
    l.action,
    l.details,
    l.ip_address
  ])
  const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n')
  const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `系统日志_${new Date().toISOString().slice(0,10)}.csv`
  a.click()
  URL.revokeObjectURL(url)
  ElMessage.success('导出成功')
}

function getSceneName(type) {
  const names = {
    laboratory: '实验室',
    dormitory: '学生宿舍',
    warehouse: '中小型仓储',
    shop: '临街商铺',
    power_room: '配电房'
  }
  return names[type] || type
}

function formatTime(timeStr) {
  if (!timeStr) return ''
  return new Date(timeStr).toLocaleString('zh-CN')
}

async function fetchInviteCodes() {
  inviteLoading.value = true
  try {
    const res = await api.get('/api/invite-codes')
    inviteCodes.value = res
  } catch (e) { console.error(e) }
  finally { inviteLoading.value = false }
}

async function generateInviteCodes() {
  try {
    const res = await api.post('/api/invite-codes', {
      count: inviteGenCount.value,
      max_uses: inviteGenMaxUses.value,
      description: inviteGenDesc.value || undefined
    })
    ElMessage.success(`已生成 ${res.count} 个邀请码`)
    const codeList = res.codes.join('\n')
    ElMessageBox.alert(codeList, '邀请码', {
      confirmButtonText: '复制并关闭',
      callback: () => {
        navigator.clipboard.writeText(codeList)
        ElMessage.success('已复制到剪贴板')
      }
    })
    fetchInviteCodes()
    inviteGenDesc.value = ''
  } catch (e) {
    ElMessage.error('生成失败')
  }
}

async function deleteInviteCode(id) {
  try {
    await ElMessageBox.confirm('确定删除该邀请码？', '提示', { type: 'warning' })
    await api.delete(`/api/invite-codes/${id}`)
    ElMessage.success('删除成功')
    fetchInviteCodes()
  } catch (e) { /* cancelled */ }
}

function copyCode(code) {
  navigator.clipboard.writeText(code)
  ElMessage.success('已复制邀请码')
}

onMounted(() => {
  fetchUsers()
  fetchAlertConfigs()
  fetchAiConfig()
  fetchLogs()
  fetchInviteCodes()
})
</script>

<style scoped>
.system-page {
  height: 100%;
  overflow-y: auto;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.invite-gen-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.gen-label {
  font-size: 13px;
  color: var(--text-secondary);
}

.code-text {
  font-family: 'SF Mono', 'Fira Code', monospace;
  font-weight: 600;
  color: #818cf8;
  letter-spacing: 1px;
}

.config-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
}

.config-card {
  padding: 20px;
}

.config-card h4 {
  margin-bottom: 16px;
  padding-bottom: 12px;
  border-bottom: 1px solid var(--border-color);
}

.config-card .el-input-number {
  width: 120px;
  margin-right: 8px;
}

.ai-config-form {
  max-width: 600px;
}

.filters {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
}

.light-mode .config-card h4 {
  color: #303133;
}

.light-mode .section-header h4 {
  color: #303133;
}

.ai-config-section { max-width: 900px; }
.ai-provider-grid {
  display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; margin-bottom: 24px;
}
.provider-card {
  display: flex; flex-direction: column; align-items: center; gap: 6px;
  padding: 14px 8px; border-radius: 10px; cursor: pointer;
  background: var(--bg-card); border: 2px solid var(--border-subtle);
  transition: all 0.2s ease;
}
.provider-card:hover { border-color: #165DFF; transform: translateY(-2px); }
.provider-card.active { border-color: #165DFF; background: rgba(22,93,255,0.08); box-shadow: 0 0 0 1px #165DFF; }
.provider-icon { font-size: 28px; line-height: 1; }
.provider-name { font-size: 13px; font-weight: 600; color: var(--text-primary); }
.ai-form-area { margin-bottom: 24px; }
.form-row { display: flex; align-items: center; gap: 12px; margin-bottom: 14px; }
.form-row label { font-size: 13px; font-weight: 500; color: var(--text-secondary); min-width: 70px; text-align: right; }
.key-input-group { display: flex; align-items: center; gap: 8px; flex: 1; }
.key-hint { white-space: nowrap; }
.form-actions { display: flex; gap: 10px; margin-left: 82px; margin-top: 4px; }
.test-result {
  margin-left: 82px; margin-top: 10px; padding: 10px 14px; border-radius: 8px;
  font-size: 13px; display: flex; align-items: center; gap: 6px;
}
.test-result.success { background: rgba(0,180,42,0.1); color: #00B42A; }
.test-result.fail { background: rgba(245,63,63,0.1); color: #F53F3F; }
.ai-help-cards { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
.help-card {
  padding: 16px; border-radius: 10px; background: var(--bg-card); border: 1px solid var(--border-subtle);
}
.help-card h4 { font-size: 14px; font-weight: 600; color: var(--text-primary); margin: 0 0 10px 0; }
.help-card ol, .help-card ul { margin: 0; padding-left: 18px; font-size: 12px; color: var(--text-secondary); line-height: 2; }
.help-card li strong { color: var(--text-primary); }

@media (max-width: 768px) {
  .ai-provider-grid { grid-template-columns: repeat(3, 1fr); }
  .ai-help-cards { grid-template-columns: 1fr; }
  .form-row { flex-direction: column; align-items: flex-start; }
  .form-row label { text-align: left; }
  .form-actions { margin-left: 0; }
  .test-result { margin-left: 0; }
}
</style>
