<template>
  <div :class="['dashboard', { 'edge-alert': hasHighAlert, 'light-mode': isLightMode }]">
    <div class="stats-row">
      <div class="stat-card urgent" :class="{ 'active': urgentCount > 0 }" :style="{ animationDelay: '0s' }">
        <div class="stat-icon urgent-icon"><el-icon :size="20"><WarningFilled /></el-icon></div>
        <div class="stat-content">
          <div class="stat-value"><AnimatedNumber :value="urgentCount" :duration="300" /></div>
          <div class="stat-label">待处理紧急预警</div>
        </div>
        <div class="stat-badge" v-if="urgentCount > 0">!</div>
      </div>
      <div class="stat-card" :style="{ animationDelay: '0.06s' }">
        <div class="stat-icon" style="background:rgba(255,125,0,0.08)"><el-icon :size="20" color="#FF7D00"><WarningFilled /></el-icon></div>
        <div class="stat-content">
          <div class="stat-value"><AnimatedNumber :value="tempAlertCount" :duration="300" /></div>
          <div class="stat-label">温度预警总数</div>
        </div>
      </div>
      <div class="stat-card" :class="{ 'active': smokeDetectedCount > 0 }" :style="{ animationDelay: '0.12s' }">
        <div class="stat-icon" :class="{ 'smoke-alert': smokeDetectedCount > 0 }"><el-icon :size="20"><component :is="smokeDetectedCount > 0 ? 'WarningFilled' : 'CircleCheck'" /></el-icon></div>
        <div class="stat-content">
          <div class="stat-value" :class="{ 'danger': smokeDetectedCount > 0 }"><AnimatedNumber :value="smokeDetectedCount" :duration="300" /></div>
          <div class="stat-label">烟雾报警数</div>
        </div>
      </div>
      <div class="stat-card" :style="{ animationDelay: '0.18s' }">
        <div class="stat-icon" style="background:rgba(0,180,42,0.08)"><el-icon :size="20" color="#00B42A"><Connection /></el-icon></div>
        <div class="stat-content">
          <div class="stat-value"><AnimatedNumber :value="onlineCount" :duration="300" /></div>
          <div class="stat-label">在线设备 <span class="online-rate">{{ onlineRate }}%</span></div>
        </div>
      </div>
      <div class="stat-card" :style="{ animationDelay: '0.24s' }">
        <div class="stat-icon" style="background:rgba(245,63,63,0.08)"><el-icon :size="20" color="#F53F3F"><Close /></el-icon></div>
        <div class="stat-content">
          <div class="stat-value"><AnimatedNumber :value="offlineCount" :duration="300" /></div>
          <div class="stat-label">离线设备</div>
        </div>
      </div>
      <div class="stat-card" :style="{ animationDelay: '0.3s' }">
        <div class="stat-icon" style="background:rgba(22,93,255,0.08)"><el-icon :size="20" color="#165DFF"><Monitor /></el-icon></div>
        <div class="stat-content">
          <div class="stat-value"><AnimatedNumber :value="devices.length" :duration="300" /></div>
          <div class="stat-label">总设备数</div>
        </div>
      </div>
    </div>

    <div class="dashboard-grid">
      <div class="device-list card-module">
        <div class="card-header">
          <h3>设备状态</h3>
          <el-tag size="small" :type="onlineCount > 0 ? 'success' : 'info'">{{ onlineCount }}/{{ devices.length }} 在线</el-tag>
        </div>
        <div class="device-scroll">
          <div
            v-for="device in sortedDevices"
            :key="device.device_id"
            :class="['device-item', { 'offline': device.status !== 'online', 'active': selectedDevice === device.device_id, 'device-warning': device.temperature >= 60 }]"
            @click="selectDevice(device)"
          >
            <div class="device-left">
              <span :class="['status-dot', device.status]"></span>
              <div class="device-info">
                <div class="device-name">{{ device.name }}</div>
                <div class="device-meta">
                  {{ device.location }}
                  <span class="smoke-badge" v-if="device.smoke_detected === 1">烟雾</span>
                </div>
              </div>
            </div>
            <div class="device-right">
              <div class="temp-display" :class="getTempClass(device.temperature)">
                {{ device.temperature?.toFixed(1) || '--' }}°C
              </div>
              <div class="humidity-display">{{ device.humidity?.toFixed(0) || '--' }}%</div>
              <div class="trend-display" :class="device.trend || 'stable'">{{ getTrendLabel(device.trend) }}</div>
            </div>
          </div>
          <el-empty v-if="devices.length === 0" description="暂无设备" :image-size="60" />
        </div>
      </div>

      <div class="center-col">
        <div class="charts-area card-module">
          <div class="card-header">
            <h3>传感器趋势</h3>
            <div class="chart-actions">
              <el-radio-group v-model="timeRange" size="small" @change="fetchTrendData">
                <el-radio-button label="1">1H</el-radio-button>
                <el-radio-button label="6">6H</el-radio-button>
                <el-radio-button label="24">24H</el-radio-button>
              </el-radio-group>
              <div class="data-actions-inline">
                <button class="data-btn sim-btn" @click="handleSimulate" :disabled="simulating" title="生成模拟数据">
                  <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4"/></svg>
                  {{ simulating ? '生成中' : '模拟数据' }}
                </button>
                <button class="data-btn clear-btn" @click="handleClear" :disabled="clearing" title="清除所有数据">
                  <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/></svg>
                  {{ clearing ? '清除中' : '清除' }}
                </button>
              </div>
            </div>
          </div>
          <div ref="trendChartRef" class="chart-container"></div>
        </div>
        <div class="chart-row">
          <div class="card-module chart-box">
            <h4>温度分布分级</h4>
            <div ref="pieChartRef" class="chart-sm"></div>
          </div>
          <div class="card-module chart-box">
            <h4>预警分级统计</h4>
            <div ref="barChartRef" class="chart-sm"></div>
          </div>
        </div>
        <div class="spectrum-row card-module">
          <div class="spectrum-header">
            <h4><el-icon><DataLine /></el-icon> 实时频谱监控</h4>
            <div class="system-controls">
              <el-button size="small" @click="toggleMute" :type="muteAlerts ? 'warning' : 'default'" round>
                <el-icon><component :is="muteAlerts ? 'Mute' : 'MuteNotification'" /></el-icon>
                {{ muteAlerts ? '已消音' : '预警消音' }}
              </el-button>
              <el-button size="small" @click="toggleEmergency" :type="emergencyMode ? 'danger' : 'default'" round>
                <el-icon><WarningFilled /></el-icon>
                {{ emergencyMode ? '退出应急' : '应急模式' }}
              </el-button>
            </div>
          </div>
          <div class="spectrum-grid">
            <div class="spectrum-item">
              <div class="spectrum-label">温度频谱</div>
              <div ref="tempSpectrumRef" class="spectrum-chart"></div>
            </div>
            <div class="spectrum-item">
              <div class="spectrum-label">湿度频谱</div>
              <div ref="humiditySpectrumRef" class="spectrum-chart"></div>
            </div>
            <div class="spectrum-item">
              <div class="spectrum-label">烟雾频谱</div>
              <div ref="smokeSpectrumRef" class="spectrum-chart"></div>
            </div>
            <div class="spectrum-item">
              <div class="spectrum-label">设备状态</div>
              <div ref="deviceSpectrumRef" class="spectrum-chart"></div>
            </div>
          </div>
        </div>
      </div>

      <div class="right-col">
        <div class="alert-feed card-module">
          <div class="card-header">
            <h3>实时预警</h3>
            <div class="alert-header-actions">
              <el-badge :value="pendingAlertCount" :hidden="pendingAlertCount === 0" type="danger">
                <el-tag size="small" type="danger">待处理</el-tag>
              </el-badge>
              <el-button size="small" text @click="markAllRead" :disabled="pendingAlertCount === 0">全部已读</el-button>
              <el-button size="small" text @click="muteAlerts = !muteAlerts">
                <el-icon><component :is="muteAlerts ? 'Mute' : 'MuteNotification'" /></el-icon>
              </el-button>
            </div>
          </div>
          <div class="alert-scroll">
            <TransitionGroup name="slide-fade">
              <div
                v-for="alert in sortedAlerts"
                :key="alert.id"
                :class="['alert-item', `level-${alert.alert_level}`, { 'smoke-alert': alert.alert_type === 'smoke_detected', 'sustained-alert': alert.alert_type?.startsWith('sustained_'), 'handled': alert.status === 'handled' }]"
              >
                <div class="alert-top">
                  <el-tag size="small" :type="getAlertTagType(alert.alert_level)" effect="dark" v-if="!alert.alert_type?.startsWith('sustained_')">
                    {{ alert.alert_type === 'smoke_detected' ? '烟雾' : getAlertLevelName(alert.alert_level) }}
                  </el-tag>
                  <el-tag size="small" type="info" effect="plain" v-else>持续监控</el-tag>
                  <span class="alert-time">{{ formatTime(alert.created_at) }}</span>
                  <el-tag v-if="alert.status === 'handled'" size="small" type="success" effect="plain">已处理</el-tag>
                </div>
                <div class="alert-main">
                  <div class="alert-device">{{ alert.device_name }}</div>
                  <div class="alert-desc">{{ alert.message }}</div>
                  <div class="alert-data" v-if="alert.temperature">
                    <span class="temp-num" :class="getTempClass(alert.temperature)">{{ alert.temperature?.toFixed(1) }}°C</span>
                    <span class="rate-num" v-if="alert.temp_rise_rate">↑{{ alert.temp_rise_rate.toFixed(1) }}/min</span>
                  </div>
                </div>
                <div class="alert-actions">
                  <el-button v-if="alert.status === 'pending'" size="small" type="primary" link @click="handleAlert(alert)">处置</el-button>
                  <el-button v-if="alert.ai_analysis" size="small" link @click="showAiAnalysis(alert)">AI分析</el-button>
                  <el-button v-else-if="alert.alert_level >= 2" size="small" link type="success" @click="triggerAiAnalysis(alert)" :loading="analyzingId === alert.id">AI分析</el-button>
                  <el-button size="small" link @click="locateTwin(alert)">定位孪生</el-button>
                </div>
              </div>
            </TransitionGroup>
            <el-empty v-if="recentAlerts.length === 0" description="暂无预警" :image-size="50" />
          </div>
        </div>

        <div class="card-module twin-window">
          <div class="card-header">
            <h3>3D 数字孪生</h3>
            <div class="twin-actions">
              <el-button size="small" text @click="$router.push('/twin')" title="全屏"><el-icon><FullScreen /></el-icon></el-button>
              <el-button size="small" text @click="resetTwinView" title="复位"><el-icon><RefreshRight /></el-icon></el-button>
              <el-switch v-model="twinLive" size="small" active-text="实时" inactive-text="关闭" />
            </div>
          </div>
          <div class="twin-entry-body" @click="$router.push('/twin')">
            <svg width="40" height="40" viewBox="0 0 48 48" fill="none">
              <rect x="8" y="20" width="32" height="20" rx="2" stroke="#165DFF" stroke-width="1.5" fill="none"/>
              <rect x="14" y="24" width="8" height="6" rx="1" fill="#165DFF" opacity="0.3"/>
              <rect x="26" y="24" width="8" height="6" rx="1" fill="#165DFF" opacity="0.3"/>
              <path d="M16 14h16M24 8v6" stroke="#0FC6C2" stroke-width="1.5" stroke-linecap="round"/>
              <circle cx="24" cy="30" r="3" fill="#00B42A" opacity="0.5"/>
            </svg>
            <div class="twin-entry-text">
              <span>实时3D场景映射</span>
              <span>火灾蔓延模拟 · 历史回溯 · 消防档案</span>
            </div>
            <el-icon :size="18" color="#64748b"><ArrowRight /></el-icon>
          </div>
        </div>
      </div>
    </div>

    <el-dialog v-model="aiDialogVisible" title="AI智能分析" width="550px" destroy-on-close>
      <div class="ai-panel" v-if="currentAlert">
        <div class="ai-title">
          <el-tag size="large" :type="getAlertTagType(currentAlert.alert_level)" effect="dark">
            {{ currentAlert.alert_type === 'smoke_detected' ? '烟雾预警' : `${getAlertLevelName(currentAlert.alert_level)}预警` }}
          </el-tag>
          <span>{{ currentAlert.device_name }}</span>
        </div>
        <div class="ai-body" v-html="formatAiAnalysis(currentAlert.ai_analysis)"></div>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, watch, nextTick, defineComponent, h, inject } from 'vue'
import { useRouter } from 'vue-router'
import * as echarts from 'echarts'
import api from '@/api'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useUserStore } from '@/stores/user'

const AnimatedNumber = defineComponent({
  props: { value: { type: Number, default: 0 }, duration: { type: Number, default: 300 } },
  setup(props) {
    const display = ref(props.value)
    let raf = null
    watch(() => props.value, (newVal) => {
      if (raf) cancelAnimationFrame(raf)
      const start = display.value
      const diff = newVal - start
      const startTime = performance.now()
      function step(now) {
        const elapsed = now - startTime
        const progress = Math.min(elapsed / props.duration, 1)
        const eased = 1 - Math.pow(1 - progress, 3)
        display.value = Math.round(start + diff * eased * 10) / 10
        if (progress < 1) { raf = requestAnimationFrame(step) }
        else { display.value = newVal; raf = null }
      }
      raf = requestAnimationFrame(step)
    })
    return () => h('span', { class: 'anim-num', style: { fontVariantNumeric: 'tabular-nums', fontFamily: 'var(--font-num)' } }, display.value)
  }
})

const router = useRouter()
const isLightMode = inject('isLightMode', ref(false))
const userStore = useUserStore()
const devices = ref([])
const recentAlerts = ref([])
const selectedDevice = ref(null)
const timeRange = ref('1')
const trendChartRef = ref(null)
const pieChartRef = ref(null)
const barChartRef = ref(null)
const tempSpectrumRef = ref(null)
const humiditySpectrumRef = ref(null)
const smokeSpectrumRef = ref(null)
const deviceSpectrumRef = ref(null)
const aiDialogVisible = ref(false)
const currentAlert = ref(null)
const muteAlerts = ref(false)
const emergencyMode = ref(false)
const twinLive = ref(true)
const simulating = ref(false)
const clearing = ref(false)
const analyzingId = ref(null)

let trendChart = null
let pieChart = null
let barChart = null
let tempSpectrum = null
let humiditySpectrum = null
let smokeSpectrum = null
let deviceSpectrum = null
let refreshTimer = null
let alertAudioContext = null
let alertOscillator = null
let lastAlertCount = 0

const onlineCount = computed(() => devices.value.filter(d => d.status === 'online').length)
const offlineCount = computed(() => devices.value.length - onlineCount.value)
const onlineRate = computed(() => devices.value.length > 0 ? Math.round(onlineCount.value / devices.value.length * 100) : 0)
const pendingAlertCount = computed(() => recentAlerts.value.filter(a => a.status === 'pending').length)
const smokeDetectedCount = computed(() => devices.value.filter(d => d.smoke_detected === 1).length)
const tempAlertCount = computed(() => recentAlerts.value.filter(a => a.alert_type !== 'smoke_detected').length)
const urgentCount = computed(() => recentAlerts.value.filter(a => a.alert_level === 3 && a.status === 'pending').length)
const hasHighAlert = computed(() => urgentCount.value > 0)

const sortedDevices = computed(() => {
  return [...devices.value].sort((a, b) => {
    const aW = a.temperature >= 60 || a.smoke_detected === 1 ? 0 : a.status !== 'online' ? 2 : 1
    const bW = b.temperature >= 60 || b.smoke_detected === 1 ? 0 : b.status !== 'online' ? 2 : 1
    return aW - bW
  })
})

const sortedAlerts = computed(() => {
  return [...recentAlerts.value].sort((a, b) => {
    if (a.status === 'pending' && b.status !== 'pending') return -1
    if (a.status !== 'pending' && b.status === 'pending') return 1
    return b.alert_level - a.alert_level
  })
})

async function fetchDevices() {
  try {
    const res = await api.get('/api/data/realtime')
    devices.value = res
    if (!selectedDevice.value && res.length > 0) {
      selectedDevice.value = res[0].device_id
      fetchTrendData()
    }
  } catch (e) { console.error(e) }
}

async function fetchAlerts() {
  try {
    const res = await api.get('/api/alerts?limit=30')
    recentAlerts.value = res
    if (res.length > lastAlertCount && !muteAlerts.value) {
      playAlertSound()
    }
    lastAlertCount = res.length
  } catch (e) { console.error(e) }
}

async function fetchTrendData() {
  if (!selectedDevice.value) return
  try {
    const device = devices.value.find(d => d.device_id === selectedDevice.value)
    if (!device) return
    const res = await api.get(`/api/data/trend?device_id=${device.id}&hours=${timeRange.value}`)
    if (trendChart) {
      const hours = parseInt(timeRange.value)
      const times = res.data.map(d => {
        if (!d.timestamp) return ''
        const date = new Date(d.timestamp)
        if (hours > 6) {
          return `${(date.getMonth()+1).toString().padStart(2,'0')}-${date.getDate().toString().padStart(2,'0')} ${date.getHours().toString().padStart(2,'0')}:${date.getMinutes().toString().padStart(2,'0')}`
        }
        return d.timestamp.split('T')[1]?.slice(0, 5) || ''
      })
      const temps = res.data.map(d => d.temperature)
      const ambients = res.data.map(d => d.ambient_temp)
      const humidities = res.data.map(d => d.humidity)
      const smokes = res.data.map(d => d.smoke_value || 0)
      trendChart.setOption({
        xAxis: { data: times },
        series: [
          { data: temps },
          { data: ambients },
          { data: humidities },
          { data: smokes }
        ]
      })
    }
  } catch (e) { console.error(e) }
}

function getChartAxisStyle() {
  return {
    axisLine: { lineStyle: { color: '#2a3555' } },
    axisLabel: { color: '#8892a0', fontSize: 10 },
    splitLine: { lineStyle: { color: '#2a3555', type: 'dashed', opacity: 0.3 } }
  }
}

function initCharts() {
  nextTick(() => {
    if (trendChartRef.value) {
      trendChart = echarts.init(trendChartRef.value)
      trendChart.setOption({
        tooltip: { trigger: 'axis', confine: true, transitionDuration: 0.2 },
        legend: { data: ['物体温度', '环境温度', '湿度(%)', '烟雾值'], textStyle: { color: '#8892a0', fontSize: 11 }, top: 0, itemWidth: 16, itemHeight: 10, itemGap: 16 },
        grid: { left: '10%', right: '4%', bottom: '12%', top: '36px', containLabel: true },
        xAxis: { type: 'category', boundaryGap: false, ...getChartAxisStyle(), axisLabel: { ...getChartAxisStyle().axisLabel, rotate: 30, interval: 'auto' } },
        yAxis: [
          { type: 'value', name: '温度(°C)', nameLocation: 'middle', nameGap: 40, nameTextStyle: { color: '#8892a0', fontSize: 11 }, ...getChartAxisStyle(), axisLabel: { color: '#8892a0', fontSize: 10, formatter: '{value}°C' } },
          { type: 'value', name: '烟雾(ppm)', nameTextStyle: { color: '#8892a0', fontSize: 10 }, axisLine: { show: false }, axisLabel: { color: '#8892a0', fontSize: 10 }, splitLine: { show: false } }
        ],
        dataZoom: [{ type: 'inside' }],
        animationDuration: 500, animationEasing: 'cubicOut',
        series: [
          { name: '物体温度', type: 'line', smooth: true, showSymbol: false, lineStyle: { color: '#165DFF', width: 2 }, areaStyle: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(22,93,255,0.25)' }, { offset: 1, color: 'rgba(22,93,255,0)' }]) }, markLine: { silent: true, symbol: 'none', data: [{ yAxis: 45, label: { formatter: '预警45°C', fontSize: 9, color: '#FFAA00' }, lineStyle: { color: '#FFAA00', type: 'dashed', width: 1 } }, { yAxis: 60, label: { formatter: '报警60°C', fontSize: 9, color: '#F53F3F' }, lineStyle: { color: '#F53F3F', type: 'dashed', width: 1.5 } }] } },
          { name: '环境温度', type: 'line', smooth: true, showSymbol: false, lineStyle: { color: '#00B42A', width: 1.5 } },
          { name: '湿度(%)', type: 'line', smooth: true, showSymbol: false, yAxisIndex: 1, lineStyle: { color: '#0FC6C2', width: 1.5, type: 'dashed' } },
          { name: '烟雾值', type: 'line', smooth: true, showSymbol: false, yAxisIndex: 1, lineStyle: { color: '#FF7D00', width: 1.5 }, areaStyle: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(255,125,0,0.15)' }, { offset: 1, color: 'rgba(255,125,0,0)' }]) }, markLine: { silent: true, data: [{ yAxis: 600, label: { formatter: '烟雾阈值', fontSize: 9, color: '#F53F3F' } }], lineStyle: { color: '#F53F3F', type: 'dashed', width: 1 } } }
        ]
      })
    }
    if (pieChartRef.value) { pieChart = echarts.init(pieChartRef.value); updatePieChart() }
  if (barChartRef.value) { barChart = echarts.init(barChartRef.value); updateBarChart() }
  initSpectrumCharts()
})
}

function updatePieChart() {
  const low = devices.value.filter(d => d.temperature < 25).length
  const normal = devices.value.filter(d => d.temperature >= 25 && d.temperature < 45).length
  const warning = devices.value.filter(d => d.temperature >= 45 && d.temperature < 60).length
  const danger = devices.value.filter(d => d.temperature >= 60).length
  if (pieChart) {
    pieChart.setOption({
      tooltip: { trigger: 'item', formatter: '{b}: {c}台 ({d}%)' },
      animationDuration: 500,
      series: [{ type: 'pie', radius: ['42%', '68%'], center: ['50%', '50%'], label: { show: false }, emphasis: { label: { show: true, fontSize: 12, fontWeight: 'bold' } }, data: [
        { value: low, name: '低温(<25°C)', itemStyle: { color: '#165DFF' } },
        { value: normal, name: '常温(25-45°C)', itemStyle: { color: '#00B42A' } },
        { value: warning, name: '预警(45-60°C)', itemStyle: { color: '#FFAA00' } },
        { value: danger, name: '报警(≥60°C)', itemStyle: { color: '#F53F3F' } }
      ] }]
    })
  }
}

function initSpectrumCharts() {
  nextTick(() => {
    if (tempSpectrumRef.value) {
      tempSpectrum = echarts.init(tempSpectrumRef.value)
      tempSpectrum.setOption({
        tooltip: { trigger: 'axis' },
        grid: { left: '3%', right: '4%', bottom: '3%', top: '10px', containLabel: true },
        xAxis: { type: 'category', data: [], axisLine: { lineStyle: { color: '#2a3555' } }, axisLabel: { color: '#8892a0', fontSize: 9 } },
        yAxis: { type: 'value', axisLine: { show: false }, splitLine: { lineStyle: { color: '#2a3555', type: 'dashed' } }, axisLabel: { color: '#8892a0', fontSize: 9 } },
        series: [{ type: 'line', smooth: true, data: [], lineStyle: { color: '#165DFF', width: 1.5 }, areaStyle: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(22,93,255,0.3)' }, { offset: 1, color: 'rgba(22,93,255,0)' }]) }, showSymbol: false }]
      })
    }
    if (humiditySpectrumRef.value) {
      humiditySpectrum = echarts.init(humiditySpectrumRef.value)
      humiditySpectrum.setOption({
        tooltip: { trigger: 'axis' },
        grid: { left: '3%', right: '4%', bottom: '3%', top: '10px', containLabel: true },
        xAxis: { type: 'category', data: [], axisLine: { lineStyle: { color: '#2a3555' } }, axisLabel: { color: '#8892a0', fontSize: 9 } },
        yAxis: { type: 'value', axisLine: { show: false }, splitLine: { lineStyle: { color: '#2a3555', type: 'dashed' } }, axisLabel: { color: '#8892a0', fontSize: 9 } },
        series: [{ type: 'line', smooth: true, data: [], lineStyle: { color: '#00B42A', width: 1.5 }, areaStyle: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(0,180,42,0.3)' }, { offset: 1, color: 'rgba(0,180,42,0)' }]) }, showSymbol: false }]
      })
    }
    if (smokeSpectrumRef.value) {
      smokeSpectrum = echarts.init(smokeSpectrumRef.value)
      smokeSpectrum.setOption({
        tooltip: { trigger: 'axis' },
        grid: { left: '3%', right: '4%', bottom: '3%', top: '10px', containLabel: true },
        xAxis: { type: 'category', data: [], axisLine: { lineStyle: { color: '#2a3555' } }, axisLabel: { color: '#8892a0', fontSize: 9 } },
        yAxis: { type: 'value', axisLine: { show: false }, splitLine: { lineStyle: { color: '#2a3555', type: 'dashed' } }, axisLabel: { color: '#8892a0', fontSize: 9 } },
        series: [{ type: 'bar', data: [], itemStyle: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: '#FF7D00' }, { offset: 1, color: 'rgba(255,125,0,0.3)' }]), borderRadius: [2, 2, 0, 0] } }]
      })
    }
    if (deviceSpectrumRef.value) {
      deviceSpectrum = echarts.init(deviceSpectrumRef.value)
      deviceSpectrum.setOption({
        tooltip: { trigger: 'item', formatter: '{b}: {c}台 ({d}%)' },
        series: [{ type: 'pie', radius: ['40%', '65%'], center: ['50%', '50%'], label: { show: true, fontSize: 10, color: '#8892a0' }, data: [] }]
      })
    }
    updateSpectrumCharts()
  })
}

function updateSpectrumCharts() {
  const temps = devices.value.map(d => d.temperature).filter(t => t != null)
  const humidities = devices.value.map(d => d.humidity).filter(h => h != null)
  const smokes = devices.value.map(d => d.smoke_value || 0)

  if (tempSpectrum && temps.length > 0) {
    const sortedTemps = [...temps].sort((a, b) => a - b)
    const labels = sortedTemps.map((_, i) => `D${i + 1}`)
    tempSpectrum.setOption({ xAxis: { data: labels }, series: [{ data: sortedTemps }] })
  }

  if (humiditySpectrum && humidities.length > 0) {
    const sortedHumidities = [...humidities].sort((a, b) => a - b)
    const labels = sortedHumidities.map((_, i) => `D${i + 1}`)
    humiditySpectrum.setOption({ xAxis: { data: labels }, series: [{ data: sortedHumidities }] })
  }

  if (smokeSpectrum && smokes.length > 0) {
    const labels = smokes.map((_, i) => `D${i + 1}`)
    smokeSpectrum.setOption({ xAxis: { data: labels }, series: [{ data: smokes.map(s => Math.round(s)) }] })
  }

  if (deviceSpectrum) {
    const online = devices.value.filter(d => d.status === 'online').length
    const offline = devices.value.length - online
    deviceSpectrum.setOption({
      series: [{
        data: [
          { value: online, name: '在线', itemStyle: { color: '#00B42A' } },
          { value: offline, name: '离线', itemStyle: { color: '#86909C' } }
        ]
      }]
    })
  }
}

function updateBarChart() {
  const level1 = recentAlerts.value.filter(a => a.alert_level === 1 && a.alert_type !== 'smoke_detected').length
  const level2 = recentAlerts.value.filter(a => a.alert_level === 2 && a.alert_type !== 'smoke_detected').length
  const level3 = recentAlerts.value.filter(a => a.alert_level === 3 && a.alert_type !== 'smoke_detected').length
  const smokeAlerts = recentAlerts.value.filter(a => a.alert_type === 'smoke_detected').length
  if (barChart) {
    barChart.setOption({
      tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
      grid: { left: '3%', right: '4%', bottom: '3%', top: '10px', containLabel: true },
      animationDuration: 500,
      xAxis: { type: 'value', ...getChartAxisStyle() },
      yAxis: { type: 'category', data: ['提示', '警告', '紧急', '烟雾'], ...getChartAxisStyle() },
      series: [{ type: 'bar', barWidth: '45%', data: [
        { value: level1, itemStyle: { color: '#165DFF', borderRadius: [0, 3, 3, 0] }, label: { show: true, position: 'right', color: '#8892a0', fontSize: 11 } },
        { value: level2, itemStyle: { color: '#FF7D00', borderRadius: [0, 3, 3, 0] }, label: { show: true, position: 'right', color: '#8892a0', fontSize: 11 } },
        { value: level3, itemStyle: { color: '#F53F3F', borderRadius: [0, 3, 3, 0] }, label: { show: true, position: 'right', color: '#8892a0', fontSize: 11 } },
        { value: smokeAlerts, itemStyle: { color: '#0FC6C2', borderRadius: [0, 3, 3, 0] }, label: { show: true, position: 'right', color: '#8892a0', fontSize: 11 } }
      ] }]
    })
  }
}

function selectDevice(device) {
  selectedDevice.value = device.device_id
  fetchTrendData()
}

function getTempClass(temp) {
  if (!temp) return ''
  if (temp >= 80) return 'danger'
  if (temp >= 60) return 'warning'
  if (temp >= 45) return 'caution'
  return 'normal'
}

function getTrendLabel(trend) { return { rising: '↑升温', falling: '↓降温', stable: '—稳定' }[trend] || '—稳定' }
function getAlertLevelName(level) { return { 1: '提示', 2: '警告', 3: '紧急' }[level] || '未知' }
function getAlertTagType(level) { return { 1: 'info', 2: 'warning', 3: 'danger' }[level] || 'info' }

function formatTime(timeStr) {
  if (!timeStr) return ''
  const date = new Date(timeStr)
  return date.toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })
}

async function handleAlert(alert) {
  try {
    await api.put(`/api/alerts/${alert.id}/handle`, { status: 'handled', handling_notes: '已处理' })
    ElMessage.success('处理成功')
    fetchAlerts()
  } catch (e) { console.error(e) }
}

async function markAllRead() {
  const pending = recentAlerts.value.filter(a => a.status === 'pending')
  for (const alert of pending) {
    try { await api.put(`/api/alerts/${alert.id}/handle`, { status: 'handled', handling_notes: '批量已读' }) } catch (e) { console.error(e) }
  }
  ElMessage.success('已全部标记已读')
  fetchAlerts()
}

function showAiAnalysis(alert) { currentAlert.value = alert; aiDialogVisible.value = true }

async function triggerAiAnalysis(alert) {
  analyzingId.value = alert.id
  try {
    const res = await api.post(`/api/alerts/${alert.id}/analyze`)
    if (res.ai_analysis) {
      alert.ai_analysis = res.ai_analysis
      currentAlert.value = alert
      aiDialogVisible.value = true
    } else {
      currentAlert.value = { ...alert, ai_analysis: res.message || 'AI分析暂无结果，请检查系统设置中的AI服务配置' }
      aiDialogVisible.value = true
    }
  } catch (e) {
    currentAlert.value = { ...alert, ai_analysis: e.response?.data?.detail || 'AI分析请求失败，请检查网络连接和AI服务配置' }
    aiDialogVisible.value = true
  } finally {
    analyzingId.value = null
  }
}

function locateTwin(alert) { router.push('/twin') }

function resetTwinView() {}

function toggleMute() {
  muteAlerts.value = !muteAlerts.value
  if (muteAlerts.value) {
    stopAlertSound()
    ElMessage.success('预警声音已关闭')
  } else {
    ElMessage.info('预警声音已开启')
  }
}

function toggleEmergency() {
  emergencyMode.value = !emergencyMode.value
  if (emergencyMode.value) {
    ElMessage.warning('⚠️ 应急模式已启动 - 增强监控频率')
    if (refreshTimer) clearInterval(refreshTimer)
    refreshTimer = setInterval(() => { fetchDevices(); fetchAlerts(); fetchTrendData(); updateSpectrumCharts() }, 1000)
  } else {
    ElMessage.info('应急模式已退出')
    if (refreshTimer) clearInterval(refreshTimer)
    refreshTimer = setInterval(() => { fetchDevices(); fetchAlerts(); fetchTrendData(); updateSpectrumCharts() }, 3000)
  }
}

function playAlertSound() {
  if (muteAlerts.value || alertAudioContext) return
  try {
    alertAudioContext = new (window.AudioContext || window.webkitAudioContext)()
    alertOscillator = alertAudioContext.createOscillator()
    const gainNode = alertAudioContext.createGain()
    alertOscillator.connect(gainNode)
    gainNode.connect(alertAudioContext.destination)
    alertOscillator.frequency.setValueAtTime(880, alertAudioContext.currentTime)
    alertOscillator.type = 'sine'
    gainNode.gain.setValueAtTime(0.3, alertAudioContext.currentTime)
    alertOscillator.start()
    setTimeout(() => {
      if (alertOscillator) {
        alertOscillator.stop()
        alertAudioContext.close()
        alertAudioContext = null
        alertOscillator = null
      }
    }, 1500)
  } catch (e) {
    console.warn('音频播放失败:', e)
  }
}

function stopAlertSound() {
  if (alertOscillator) {
    try { alertOscillator.stop() } catch (e) {}
    alertOscillator = null
  }
  if (alertAudioContext) {
    try { alertAudioContext.close() } catch (e) {}
    alertAudioContext = null
  }
}

async function handleSimulate() {
  simulating.value = true
  try {
    const res = await api.post('/api/data/simulate')
    if (res.code === 200) {
      ElMessage.success(res.message)
      timeRange.value = '24'
      await fetchDevices()
      await fetchAlerts()
      await nextTick()
      if (devices.value.length > 0) {
        selectedDevice.value = devices.value[0].device_id
        await fetchTrendData()
      }
      updatePieChart()
      updateBarChart()
    } else {
      ElMessage.warning(res.message)
    }
  } catch (e) {
    console.error(e)
    ElMessage.error('模拟数据生成失败')
  } finally {
    simulating.value = false
  }
}

async function handleClear() {
  try {
    await ElMessageBox.confirm(
      '确定要清除所有传感器数据和预警记录吗？设备将恢复离线状态。数据镜像不受影响，可随时从镜像恢复。',
      '确认清除',
      { confirmButtonText: '确认清除', cancelButtonText: '取消', type: 'warning' }
    )
  } catch { return }
  clearing.value = true
  try {
    const res = await api.post('/api/data/clear')
    if (res.code === 200) {
      ElMessage.success(res.message)
      await fetchDevices()
      await fetchAlerts()
      if (trendChart) {
        trendChart.setOption({
          xAxis: { data: [] },
          series: [{ data: [] }, { data: [] }, { data: [] }, { data: [] }]
        })
      }
      updatePieChart()
      updateBarChart()
      updateSpectrumCharts()
    } else {
      ElMessage.warning(res.message)
    }
  } catch (e) {
    console.error(e)
    ElMessage.error('清除数据失败')
  } finally {
    clearing.value = false
  }
}

function formatAiAnalysis(analysis) {
  if (!analysis) return '<p style="color:#999;text-align:center;padding:20px;">暂无分析结果</p>'
  let html = analysis
    .replace(/```[\s\S]*?```/g, m => m.replace(/```\w*\n?/g, '').replace(/```/g, ''))
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/#{1,3}\s+(.*)/g, '<strong style="font-size:14px">$1</strong>')
    .replace(/\n/g, '<br>')
  return html
}

watch([() => devices.value, () => recentAlerts.value], () => { updatePieChart(); updateBarChart(); updateSpectrumCharts() }, { deep: true })

function handleResize() {
  ;[trendChart, pieChart, barChart, tempSpectrum, humiditySpectrum, smokeSpectrum, deviceSpectrum].forEach(c => c?.resize())
}

onMounted(() => {
  fetchDevices(); fetchAlerts(); initCharts()
  refreshTimer = setInterval(() => { fetchDevices(); fetchAlerts(); fetchTrendData(); updateSpectrumCharts() }, emergencyMode.value ? 1000 : 3000)
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  stopAlertSound()
  if (refreshTimer) clearInterval(refreshTimer)
  ;[trendChart, pieChart, barChart, tempSpectrum, humiditySpectrum, smokeSpectrum, deviceSpectrum].forEach(chart => chart?.dispose())
  window.removeEventListener('resize', handleResize)
})
</script>

<style scoped>
.dashboard { height:100%; overflow-y:auto; padding:0; position:relative; }

.dashboard.edge-alert::before {
  content:''; position:fixed; inset:0; z-index:0; pointer-events:none;
  animation:edge-red-pulse 2s ease-in-out infinite;
}

@keyframes edge-red-pulse {
  0%,100% { box-shadow:inset 0 0 60px rgba(245,63,63,0.02); }
  50% { box-shadow:inset 0 0 60px rgba(245,63,63,0.06); }
}

.stats-row {
  display:grid; grid-template-columns:repeat(6, 1fr);
  gap:10px; margin-bottom:14px;
}

.stat-card {
  display:flex; align-items:center; gap:10px;
  padding:12px 14px; border-radius:var(--radius-md);
  background:var(--bg-card); border:1px solid var(--border-subtle);
  transition:all var(--dur-fast) var(--ease-out);
  animation:fade-in-up 0.4s var(--ease-out) both;
  position:relative;
}

.stat-card:hover { border-color:var(--border-default); transform:translateY(-1px); box-shadow:var(--shadow-md); }

.stat-card.urgent.active {
  border-color:rgba(245,63,63,0.3);
  background:linear-gradient(135deg, var(--bg-card), rgba(245,63,63,0.06));
}

.stat-card.urgent.active .stat-value { color:#F53F3F; }

.urgent-icon {
  width:36px; height:36px; border-radius:var(--radius-sm);
  background:rgba(245,63,63,0.1) !important; color:#F53F3F !important;
  display:flex; align-items:center; justify-content:center;
}

.stat-badge {
  position:absolute; top:-4px; right:-4px;
  width:18px; height:18px; border-radius:50%;
  background:#F53F3F; color:#fff; font-size:10px; font-weight:700;
  display:flex; align-items:center; justify-content:center;
  animation:pulse-dot 1.5s ease-in-out infinite;
}

@keyframes pulse-dot {
  0%,100% { transform:scale(1); opacity:1; }
  50% { transform:scale(1.2); opacity:0.7; }
}

.stat-icon {
  width:36px; height:36px; border-radius:var(--radius-sm);
  display:flex; align-items:center; justify-content:center; flex-shrink:0;
  background:var(--accent-green-dim); color:var(--accent-green);
}

.stat-icon.smoke-alert { background:var(--accent-red-dim) !important; color:var(--accent-red) !important; }

.stat-content { flex:1; min-width:0; }

.stat-value {
  font-size:20px; font-weight:700; line-height:1.2;
  color:var(--text-primary); font-variant-numeric:tabular-nums;
  font-family:var(--font-num); transition:color 0.3s var(--ease-out);
}

.stat-value.danger { color:#F53F3F; }

.stat-label { font-size:11px; color:var(--text-muted); margin-top:2px; white-space:nowrap; }

.online-rate { color:var(--accent-green); font-weight:600; font-family:var(--font-num); }

.dashboard-grid {
  display:grid;
  grid-template-columns:220px 1fr 260px;
  gap:12px;
}

.device-list { grid-row:span 2; }

.card-module {
  background:var(--bg-card); border:1px solid var(--border-subtle);
  border-radius:var(--radius-md); padding:14px;
  animation:fade-in-up 0.4s var(--ease-out) both;
}

.card-header {
  display:flex; align-items:center; justify-content:space-between; margin-bottom:10px;
}

.card-header h3 { font-size:13px; font-weight:600; color:var(--text-primary); margin:0; letter-spacing:0.3px; }

.alert-header-actions { display:flex; align-items:center; gap:6px; }

.device-scroll { max-height:520px; overflow-y:auto; }

.device-item {
  display:flex; align-items:center; justify-content:space-between;
  padding:8px 10px; border-radius:var(--radius-sm); cursor:pointer;
  transition:all var(--dur-fast) var(--ease-in-out);
  margin-bottom:3px; border:1px solid transparent;
}

.device-item:hover { background:var(--bg-hover); }
.device-item.active { background:var(--accent-blue-dim); border-color:rgba(22,93,255,0.15); }
.device-item.offline { opacity:0.45; }
.device-item.device-warning { background:rgba(255,125,0,0.04); }

.device-left { display:flex; align-items:center; gap:8px; flex:1; min-width:0; }
.status-dot { width:6px; height:6px; border-radius:50%; flex-shrink:0; }
.status-dot.online { background:var(--accent-green); }
.status-dot.offline { background:var(--text-faint); }

.device-info { min-width:0; }
.device-name { font-size:12px; font-weight:500; color:var(--text-primary); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.device-meta { font-size:10px; color:var(--text-muted); display:flex; align-items:center; gap:4px; margin-top:1px; }
.smoke-badge { font-size:9px; font-weight:600; padding:1px 4px; border-radius:2px; background:rgba(245,63,63,0.12); color:var(--accent-red); }

.device-right { text-align:right; flex-shrink:0; }
.temp-display { font-size:14px; font-weight:600; line-height:1.2; font-variant-numeric:tabular-nums; font-family:var(--font-num); transition:color 0.3s var(--ease-out); }
.humidity-display { font-size:10px; color:var(--text-muted); line-height:1.2; font-variant-numeric:tabular-nums; }
.trend-display { font-size:9px; font-weight:500; line-height:1.2; margin-top:1px; }
.trend-display.rising { color:var(--accent-red); }
.trend-display.falling { color:var(--accent-blue); }
.trend-display.stable { color:var(--text-muted); }

.temp-display.normal { color:var(--accent-green); }
.temp-display.caution { color:var(--accent-blue); }
.temp-display.warning { color:var(--accent-orange); }
.temp-display.danger { color:var(--accent-red); }

.center-col { display:flex; flex-direction:column; gap:12px; }
.charts-area { min-height:300px; }
.chart-container { height:240px; }
.chart-row { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
.chart-box h4 { font-size:13px; font-weight:600; margin:0 0 8px 0; color:var(--text-primary); }
.chart-sm { height:170px; }

.chart-actions {
  display:flex; align-items:center; gap:10px;
}

.data-actions-inline {
  display:flex; gap:6px;
  margin-left:auto;
}

.spectrum-row {
  margin-top:12px;
}

.spectrum-header {
  display:flex; align-items:center; justify-content:space-between;
  margin-bottom:12px;
}

.spectrum-header h4 {
  font-size:13px; font-weight:600; color:var(--text-primary);
  margin:0; display:flex; align-items:center; gap:6px;
}

.system-controls {
  display:flex; align-items:center; gap:8px;
}

.spectrum-grid {
  display:grid;
  grid-template-columns:repeat(4, 1fr);
  gap:12px;
}

.spectrum-item {
  background:var(--bg-elevated);
  border-radius:var(--radius-sm);
  padding:10px;
  border:1px solid var(--border-subtle);
}

.spectrum-label {
  font-size:11px; font-weight:500;
  color:var(--text-muted); margin-bottom:6px;
  text-align:center;
}

.spectrum-chart {
  height:120px;
}

.right-col { display:flex; flex-direction:column; gap:10px; }
.alert-feed { flex:1; }

.alert-scroll { max-height:340px; overflow-y:auto; }

.alert-item {
  padding:8px 10px; border-radius:var(--radius-sm);
  background:var(--bg-elevated); margin-bottom:5px;
  border-left:3px solid transparent;
  transition:all var(--dur-fast) var(--ease-in-out);
}

.alert-item:hover { background:var(--bg-hover); }
.alert-item.level-1 { border-left-color:var(--accent-blue); }
.alert-item.level-2 { border-left-color:var(--accent-orange); }
.alert-item.level-3 { border-left-color:var(--accent-red); }
.alert-item.level-3:not(.handled) { animation:breathe-high 0.8s ease-in-out infinite; }
.alert-item.smoke-alert { background:rgba(245,63,63,0.04); border-left-color:var(--accent-red); }
.alert-item.sustained-alert { opacity:0.5; border-left-color:var(--text-faint); }
.alert-item.handled { opacity:0.4; }

.alert-top { display:flex; align-items:center; justify-content:space-between; margin-bottom:4px; gap:4px; }
.alert-time { font-size:10px; color:var(--text-muted); }
.alert-main { margin-bottom:4px; }
.alert-device { font-size:12px; font-weight:600; color:var(--text-primary); margin-bottom:1px; }
.alert-desc { font-size:11px; color:var(--text-secondary); line-height:1.3; margin-bottom:3px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.alert-data { display:flex; gap:8px; font-size:11px; font-variant-numeric:tabular-nums; }
.temp-num { font-weight:600; font-family:var(--font-num); }
.temp-num.normal { color:var(--accent-green); }
.temp-num.caution { color:var(--accent-blue); }
.temp-num.warning { color:var(--accent-orange); }
.temp-num.danger { color:var(--accent-red); }
.rate-num { color:var(--text-muted); font-family:var(--font-num); }
.alert-actions { display:flex; justify-content:flex-end; gap:2px; }

.twin-window { min-height:140px; }

.twin-actions { display:flex; align-items:center; gap:4px; }

.twin-entry-body {
  display:flex; align-items:center; gap:12px; padding:6px 0;
  cursor:pointer; transition:all var(--dur-fast) var(--ease-out);
}

.twin-entry-body:hover { opacity:0.8; }

.twin-entry-text { display:flex; flex-direction:column; gap:2px; flex:1; }
.twin-entry-text span:first-child { font-size:12px; font-weight:500; color:var(--text-primary); }
.twin-entry-text span:last-child { font-size:10px; color:var(--text-muted); }

.data-btn {
  display:flex; align-items:center; gap:4px;
  padding:5px 10px; border-radius:6px;
  font-size:11px; font-weight:500; cursor:pointer;
  transition:all 0.2s; border:1px solid;
  white-space: nowrap;
}

.data-btn:disabled {
  opacity:0.5; cursor:not-allowed;
}

.sim-btn {
  background:rgba(22,93,255,0.08); border-color:rgba(22,93,255,0.2);
  color:#165DFF;
}

.sim-btn:hover:not(:disabled) {
  background:rgba(22,93,255,0.15); border-color:rgba(22,93,255,0.35);
  box-shadow:0 2px 8px rgba(22,93,255,0.12);
}

.clear-btn {
  background:rgba(245,63,63,0.06); border-color:rgba(245,63,63,0.15);
  color:#F53F3F;
}

.clear-btn:hover:not(:disabled) {
  background:rgba(245,63,63,0.12); border-color:rgba(245,63,63,0.3);
  box-shadow:0 2px 8px rgba(245,63,63,0.1);
}

.slide-fade-enter-active { transition:all 0.25s var(--ease-out); }
.slide-fade-leave-active { transition:all 0.15s var(--ease-in-out); }
.slide-fade-enter-from, .slide-fade-leave-to { transform:translateX(8px); opacity:0; }

.ai-panel { padding:0; }
.ai-title { display:flex; align-items:center; gap:10px; margin-bottom:14px; font-size:14px; font-weight:600; }
.ai-body { font-size:13px; line-height:1.8; color:var(--text-primary); background:var(--bg-elevated); padding:14px; border-radius:var(--radius-sm); border:1px solid var(--border-subtle); }

:deep(.el-radio-button__inner) {
  background:var(--bg-elevated) !important; border-color:var(--border-default) !important;
  color:var(--text-muted) !important; font-size:12px; padding:4px 10px;
}
:deep(.el-radio-button__original-radio:checked + .el-radio-button__inner) {
  background:var(--accent-blue) !important; border-color:var(--accent-blue) !important; color:#fff !important;
}

@keyframes fade-in-up {
  from { opacity:0; transform:translateY(12px); }
  to { opacity:1; transform:translateY(0); }
}

@media (min-width:2560px) {
  .dashboard-grid { grid-template-columns:280px 1fr 320px; }
  .stat-value { font-size:26px; }
  .chart-container { height:320px; }
  .chart-sm { height:220px; }
  .alert-scroll { max-height:480px; }
  .device-scroll { max-height:640px; }
}

@media (max-width:1200px) {
  .stats-row { grid-template-columns:repeat(3, 1fr); }
  .dashboard-grid { grid-template-columns:1fr; }
  .device-list { grid-row:auto; }
}

@media (max-width:768px) {
  .stats-row { grid-template-columns:repeat(2, 1fr); }
  .chart-row { grid-template-columns:1fr; }
  .spectrum-grid { grid-template-columns:repeat(2, 1fr); }
  .twin-window { display:none; }
  .data-actions-inline { display:none; }
}

.light-mode .stat-card { background:#FFFFFF; border-color:#E5E6EB; }
.light-mode .stat-label { color:#86909C; }
.light-mode .stat-value { color:#1D2129; }
.light-mode .device-item { background:#FFFFFF; border-color:#E5E6EB; }
.light-mode .device-name { color:#1D2129; }
.light-mode .device-location { color:#4E5969; }
.light-mode .device-temp { color:#1D2129; }
.light-mode .alert-item { background:#FFFFFF; border-color:#E5E6EB; }
.light-mode .alert-device { color:#1D2129; }
.light-mode .alert-msg { color:#4E5969; }
.light-mode .card-module { background:#FFFFFF; border-color:#E5E6EB; }
.light-mode .card-module h3 { color:#1D2129; }
.light-mode .twin-window { background:#FFFFFF; border-color:#E5E6EB; }
.light-mode :deep(.el-table) { --el-table-bg-color:#FFFFFF; --el-table-tr-bg-color:#FFFFFF; --el-table-header-bg-color:#F7F8FA; --el-table-row-hover-bg-color:#F2F3F5; --el-table-border-color:#E5E6EB; color:#1D2129; }
.light-mode :deep(.el-table th.el-table__cell) { color:#4E5969; }
</style>
