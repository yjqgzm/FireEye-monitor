<template>
  <div class="register-container">
    <div class="register-bg">
      <div class="bg-gradient"></div>
      <div class="bg-grid"></div>
      <div class="bg-orb orb-1"></div>
      <div class="bg-orb orb-2"></div>
      <div class="scan-line"></div>
      <div class="particle-field">
        <div v-for="i in 15" :key="i" class="particle" :style="particleStyle(i)"></div>
      </div>
    </div>

    <div class="register-wrapper">
      <div class="brand-section">
        <div class="brand-name">
          <h1 class="brand-title">火睛智控中心</h1>
          <p class="brand-subtitle">FireGuard Intelligent Control Center</p>
        </div>
        <div class="brand-desc">
          <h2>创建您的账户</h2>
          <p>注册即可体验消防资讯浏览功能，输入邀请码可解锁全部智能监控能力</p>
        </div>
        <div class="tier-list">
          <div class="tier-item">
            <div class="tier-badge free">基础</div>
            <div class="tier-info">
              <span class="tier-name">免费注册</span>
              <span class="tier-desc">消防资讯 · 消防知识</span>
            </div>
          </div>
          <div class="tier-item">
            <div class="tier-badge invited">邀请</div>
            <div class="tier-info">
              <span class="tier-name">邀请用户</span>
              <span class="tier-desc">全部功能 · 实时监控 · AI预警</span>
            </div>
          </div>
        </div>
      </div>

      <div class="register-card">
        <div class="card-glow"></div>
        <div class="card-inner">
          <div class="card-header">
            <h3>注册账户</h3>
            <p>填写信息完成注册</p>
          </div>
          <el-form ref="formRef" :model="form" :rules="rules" @submit.prevent="handleRegister">
            <el-form-item prop="username">
              <el-input v-model="form.username" placeholder="用户名（至少3个字符）" size="large" :prefix-icon="User" />
            </el-form-item>
            <el-form-item prop="email">
              <el-input v-model="form.email" placeholder="邮箱（必填，用于登录）" size="large" :prefix-icon="Message" />
            </el-form-item>
            <el-form-item prop="password">
              <el-input v-model="form.password" type="password" placeholder="密码（至少6个字符）" size="large" :prefix-icon="Lock" show-password />
            </el-form-item>
            <el-form-item prop="confirmPassword">
              <el-input v-model="form.confirmPassword" type="password" placeholder="确认密码" size="large" :prefix-icon="Lock" show-password />
            </el-form-item>
            <div class="invite-section">
              <div class="invite-header">
                <span class="invite-label">邀请码</span>
                <span class="invite-optional">选填 · 填写后解锁全部功能</span>
              </div>
              <el-form-item prop="invite_code">
                <el-input v-model="form.invite_code" placeholder="FHQJ-XXXXXXXX" size="large" :prefix-icon="Ticket" />
              </el-form-item>
            </div>
            <el-form-item>
              <el-button type="primary" size="large" :loading="loading" @click="handleRegister" class="register-btn">
                {{ loading ? '注册中...' : '注 册' }}
              </el-button>
            </el-form-item>
          </el-form>
          <div class="card-footer">
            <span class="footer-text">已有账户？</span>
            <router-link to="/login" class="footer-link">立即登录</router-link>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-bar">
      <span>火睛智控中心 V10.0</span>
      <span class="sep">·</span>
      <span>Powered by AI</span>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { User, Lock, Message, Ticket } from '@element-plus/icons-vue'
import { useUserStore } from '@/stores/user'
import { ElMessage } from 'element-plus'

const router = useRouter()
const userStore = useUserStore()
const formRef = ref(null)
const loading = ref(false)

const form = reactive({
  username: '',
  email: '',
  password: '',
  confirmPassword: '',
  invite_code: ''
})

const validateConfirmPassword = (rule, value, callback) => {
  if (value !== form.password) {
    callback(new Error('两次输入的密码不一致'))
  } else {
    callback()
  }
}

const rules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' },
    { min: 3, message: '用户名至少3个字符', trigger: 'blur' }
  ],
  email: [
    { required: true, message: '请输入邮箱', trigger: 'blur' },
    { type: 'email', message: '请输入有效的邮箱地址', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, message: '密码至少6个字符', trigger: 'blur' }
  ],
  confirmPassword: [
    { required: true, message: '请确认密码', trigger: 'blur' },
    { validator: validateConfirmPassword, trigger: 'blur' }
  ]
}

function particleStyle(i) {
  const x = Math.random() * 100
  const y = Math.random() * 100
  const size = 1 + Math.random() * 2
  const dur = 8 + Math.random() * 12
  const delay = Math.random() * -20
  return { left: `${x}%`, top: `${y}%`, width: `${size}px`, height: `${size}px`, animationDuration: `${dur}s`, animationDelay: `${delay}s` }
}

async function handleRegister() {
  if (!formRef.value) return
  await formRef.value.validate(async (valid) => {
    if (!valid) return
    loading.value = true
    try {
      await userStore.register(form.username, form.password, form.email, form.invite_code || undefined)
      ElMessage.success('注册成功')
      router.push('/')
    } catch (e) {
      const msg = e.response?.data?.detail || '注册失败，请重试'
      ElMessage.error(msg)
    } finally {
      loading.value = false
    }
  })
}
</script>

<style scoped>
.register-container {
  width: 100%;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
}

.register-bg {
  position: absolute;
  inset: 0;
  z-index: 0;
}

.bg-gradient {
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, #030712 0%, #0a1628 25%, #0c1a36 50%, #091428 75%, #030712 100%);
}

.bg-grid {
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient(rgba(99, 102, 241, 0.03) 1px, transparent 1px),
    linear-gradient(90deg, rgba(99, 102, 241, 0.03) 1px, transparent 1px);
  background-size: 60px 60px;
  animation: gridShift 30s linear infinite;
}

@keyframes gridShift {
  0% { transform: translate(0, 0); }
  100% { transform: translate(60px, 60px); }
}

.bg-orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(100px);
  animation: orbFloat 15s ease-in-out infinite;
}

.orb-1 {
  width: 500px;
  height: 500px;
  background: radial-gradient(circle, rgba(99, 102, 241, 0.12), transparent 70%);
  top: -15%;
  right: -10%;
}

.orb-2 {
  width: 400px;
  height: 400px;
  background: radial-gradient(circle, rgba(6, 182, 212, 0.1), transparent 70%);
  bottom: -10%;
  left: -8%;
  animation-delay: -5s;
}

@keyframes orbFloat {
  0%, 100% { transform: translate(0, 0) scale(1); }
  25% { transform: translate(40px, -30px) scale(1.08); }
  50% { transform: translate(-20px, 20px) scale(0.95); }
  75% { transform: translate(30px, 10px) scale(1.03); }
}

.scan-line {
  position: absolute;
  width: 100%;
  height: 1px;
  background: linear-gradient(90deg, transparent 10%, rgba(99, 102, 241, 0.4) 50%, transparent 90%);
  animation: scanMove 8s linear infinite;
}

@keyframes scanMove {
  0% { top: -2px; opacity: 0; }
  5% { opacity: 1; }
  95% { opacity: 1; }
  100% { top: 100%; opacity: 0; }
}

.particle-field { position: absolute; inset: 0; overflow: hidden; }

.particle {
  position: absolute;
  border-radius: 50%;
  background: rgba(99, 102, 241, 0.4);
  animation: particleDrift linear infinite;
}

@keyframes particleDrift {
  0% { transform: translateY(0) translateX(0); opacity: 0; }
  10% { opacity: 1; }
  90% { opacity: 1; }
  100% { transform: translateY(-100vh) translateX(30px); opacity: 0; }
}

.register-wrapper {
  position: relative;
  z-index: 1;
  display: flex;
  align-items: center;
  gap: 80px;
  max-width: 1100px;
  width: 100%;
  padding: 0 40px;
}

.brand-section { flex: 1; max-width: 460px; }

.brand-name { margin-bottom: 32px; }

.brand-title {
  font-size: 36px;
  font-weight: 800;
  background: linear-gradient(135deg, #e0e7ff 0%, #a5b4fc 25%, #818cf8 50%, #22d3ee 80%, #06b6d4 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin: 0;
  line-height: 1.2;
  letter-spacing: 6px;
  animation: titleShimmer 4s ease-in-out infinite;
  background-size: 200% 100%;
}

@keyframes titleShimmer {
  0%, 100% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
}

.brand-subtitle {
  font-size: 12px;
  color: rgba(148, 163, 184, 0.45);
  letter-spacing: 4px;
  margin-top: 8px;
}

.brand-desc { margin-bottom: 28px; }

.brand-desc h2 {
  font-size: 20px;
  font-weight: 600;
  color: #e2e8f0;
  margin: 0 0 10px 0;
}

.brand-desc p {
  font-size: 14px;
  color: rgba(148, 163, 184, 0.6);
  line-height: 1.7;
  margin: 0;
}

.tier-list { display: flex; flex-direction: column; gap: 12px; }

.tier-item {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 14px 18px;
  border-radius: 12px;
  background: rgba(99, 102, 241, 0.04);
  border: 1px solid rgba(99, 102, 241, 0.08);
  transition: all 0.2s ease;
}

.tier-item:hover { border-color: rgba(99, 102, 241, 0.15); background: rgba(99, 102, 241, 0.06); }

.tier-badge {
  font-size: 11px;
  font-weight: 700;
  padding: 4px 10px;
  border-radius: 6px;
  letter-spacing: 1px;
  flex-shrink: 0;
}

.tier-badge.free { background: rgba(148, 163, 184, 0.12); color: #94a3b8; }
.tier-badge.invited { background: linear-gradient(135deg, rgba(99, 102, 241, 0.2), rgba(6, 182, 212, 0.15)); color: #818cf8; }

.tier-info { display: flex; flex-direction: column; gap: 2px; }

.tier-name { font-size: 14px; font-weight: 600; color: #e2e8f0; }
.tier-desc { font-size: 12px; color: rgba(148, 163, 184, 0.5); }

.register-card {
  width: 420px;
  flex-shrink: 0;
  position: relative;
}

.card-glow {
  position: absolute;
  inset: -1px;
  border-radius: 20px;
  background: linear-gradient(135deg, rgba(99, 102, 241, 0.3), rgba(6, 182, 212, 0.15), rgba(244, 63, 94, 0.1));
  z-index: 0;
  opacity: 0.5;
  filter: blur(1px);
  animation: glowPulse 4s ease-in-out infinite;
}

@keyframes glowPulse {
  0%, 100% { opacity: 0.4; }
  50% { opacity: 0.7; }
}

.card-inner {
  position: relative;
  z-index: 1;
  background: rgba(10, 15, 30, 0.88);
  backdrop-filter: blur(24px);
  border-radius: 20px;
  padding: 36px 32px;
  border: 1px solid rgba(99, 102, 241, 0.1);
}

.card-header { margin-bottom: 24px; }

.card-header h3 { font-size: 22px; font-weight: 600; color: #f1f5f9; margin: 0 0 6px 0; }
.card-header p { font-size: 14px; color: rgba(148, 163, 184, 0.5); margin: 0; }

.invite-section {
  margin-bottom: 8px;
  padding: 14px 16px;
  border-radius: 10px;
  background: rgba(99, 102, 241, 0.04);
  border: 1px dashed rgba(99, 102, 241, 0.15);
}

.invite-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.invite-label { font-size: 13px; font-weight: 600; color: #818cf8; }
.invite-optional { font-size: 11px; color: rgba(148, 163, 184, 0.4); }

.register-btn {
  width: 100%;
  height: 48px;
  font-size: 16px;
  font-weight: 600;
  letter-spacing: 4px;
  border-radius: 12px;
  background: linear-gradient(135deg, #6366f1, #4f46e5);
  border: none;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
}

.register-btn::after {
  content: '';
  position: absolute;
  top: -50%;
  left: -50%;
  width: 200%;
  height: 200%;
  background: linear-gradient(45deg, transparent 40%, rgba(255,255,255,0.1) 50%, transparent 60%);
  animation: btnShine 3s ease-in-out infinite;
}

@keyframes btnShine {
  0% { transform: translateX(-100%) rotate(45deg); }
  100% { transform: translateX(100%) rotate(45deg); }
}

.register-btn:hover {
  background: linear-gradient(135deg, #818cf8, #6366f1);
  transform: translateY(-2px);
  box-shadow: 0 8px 30px rgba(99, 102, 241, 0.4);
}

.card-footer {
  margin-top: 20px;
  padding-top: 16px;
  border-top: 1px solid rgba(99, 102, 241, 0.06);
  text-align: center;
}

.footer-text { font-size: 13px; color: rgba(148, 163, 184, 0.5); }

.footer-link {
  font-size: 13px;
  color: #818cf8;
  text-decoration: none;
  font-weight: 600;
  margin-left: 4px;
  transition: color 0.2s;
}

.footer-link:hover { color: #a5b4fc; }

.footer-bar {
  position: absolute;
  bottom: 24px;
  left: 0;
  right: 0;
  text-align: center;
  font-size: 12px;
  color: rgba(148, 163, 184, 0.25);
  letter-spacing: 1px;
  z-index: 1;
}

.footer-bar .sep { margin: 0 8px; opacity: 0.4; }

:deep(.el-input__wrapper) {
  padding: 8px 14px;
  background: rgba(10, 15, 30, 0.7) !important;
  border: 1px solid rgba(99, 102, 241, 0.1) !important;
  border-radius: 10px !important;
  box-shadow: none !important;
  transition: all 0.25s ease;
}

:deep(.el-input__wrapper:hover) { border-color: rgba(99, 102, 241, 0.2) !important; }
:deep(.el-input__wrapper.is-focus) { border-color: rgba(99, 102, 241, 0.45) !important; box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.08) !important; }
:deep(.el-input__inner) { color: #e2e8f0 !important; }
:deep(.el-input__inner::placeholder) { color: rgba(148, 163, 184, 0.35) !important; }
:deep(.el-input__prefix .el-icon) { color: rgba(99, 102, 241, 0.45); }
:deep(.el-form-item) { margin-bottom: 16px; }

@media (max-width: 900px) {
  .register-wrapper { flex-direction: column; gap: 40px; align-items: center; }
  .brand-section { text-align: center; max-width: 400px; }
  .register-card { width: 100%; max-width: 420px; }
  .brand-title { font-size: 28px; }
}
</style>
