<template>
  <div :class="['app-layout', { 'light-mode': isLightMode, 'fullscreen-mode': isFullscreen, 'high-alert-active': hasHighAlert }]" tabindex="0" @keydown="handleKeydown">
    <transition name="alert-banner">
      <div class="alert-banner" v-if="hasHighAlert && !bannerDismissed">
        <div class="banner-edge"></div>
        <div class="banner-content">
          <el-icon class="banner-icon"><WarningFilled /></el-icon>
          <span class="banner-text">高风险预警：{{ highAlertDevice }} 温度异常，请立即处置</span>
          <el-button size="small" type="danger" @click="goToAlerts" class="banner-action">立即处理</el-button>
          <el-button size="small" text @click="bannerDismissed = true" class="banner-dismiss">
            <el-icon><Close /></el-icon>
          </el-button>
        </div>
      </div>
    </transition>

    <aside class="sidebar" v-show="!isFullscreen">
      <div class="sidebar-header">
        <div class="logo">
          <span class="logo-text">火睛智控中心</span>
        </div>
      </div>
      <el-menu :default-active="activeMenu" class="sidebar-menu">
        <el-menu-item index="/" @click="navigateTo('/')">
          <el-icon><DataAnalysis /></el-icon>
          <span>实时监控</span>
          <el-tag v-if="!userStore.isInvited" size="small" type="info" class="lock-tag">锁定</el-tag>
        </el-menu-item>
        <el-menu-item index="/devices" @click="navigateTo('/devices')">
          <el-icon><Monitor /></el-icon>
          <span>设备管理</span>
          <el-tag v-if="!userStore.isInvited" size="small" type="info" class="lock-tag">锁定</el-tag>
        </el-menu-item>
        <el-menu-item index="/history" @click="navigateTo('/history')">
          <el-icon><Clock /></el-icon>
          <span>历史数据</span>
          <el-tag v-if="!userStore.isInvited" size="small" type="info" class="lock-tag">锁定</el-tag>
        </el-menu-item>
        <el-menu-item index="/alerts" @click="navigateTo('/alerts')">
          <el-icon><WarningFilled /></el-icon>
          <span>预警记录</span>
          <el-badge v-if="pendingAlertCount > 0" :value="pendingAlertCount" :max="99" class="alert-badge" />
          <el-tag v-if="!userStore.isInvited" size="small" type="info" class="lock-tag">锁定</el-tag>
        </el-menu-item>
        <el-menu-item index="/news" @click="navigateTo('/news')">
          <el-icon><Document /></el-icon>
          <span>消防资讯</span>
        </el-menu-item>
        <el-menu-item index="/twin" @click="navigateTo('/twin')">
          <el-icon><View /></el-icon>
          <span>3D孪生</span>
        </el-menu-item>
        <el-menu-item index="/system" v-if="userStore.isAdmin" @click="navigateTo('/system')">
          <el-icon><Setting /></el-icon>
          <span>系统管理</span>
        </el-menu-item>
        <el-menu-item index="/profile" @click="navigateTo('/profile')">
          <el-icon><User /></el-icon>
          <span>个人中心</span>
        </el-menu-item>
      </el-menu>
      <div class="sidebar-footer">
        <div class="invite-status" v-if="!userStore.isInvited && userStore.isLoggedIn">
          <div class="status-dot"></div>
          <span>基础用户</span>
        </div>
        <div class="member-status" v-else-if="userStore.isInvited && !userStore.isAdmin && userStore.isLoggedIn">
          <div class="member-dot"></div>
          <span>普通会员</span>
        </div>
        <div class="version-info">火睛智控中心 V10.0</div>
      </div>
    </aside>

    <main class="main-wrapper">
      <header class="header-bar" v-show="!isFullscreen">
        <div class="header-left">
          <h2 class="page-title">{{ pageTitle }}</h2>
          <el-tag v-if="!userStore.isInvited && userStore.isLoggedIn" size="small" type="warning" effect="dark" class="user-tier-tag">基础用户</el-tag>
          <el-tag v-else-if="userStore.isInvited && !userStore.isAdmin && userStore.isLoggedIn" size="small" effect="dark" class="user-tier-tag member-tier">普通会员</el-tag>
        </div>
        <div class="header-right">
          <div class="header-stats">
            <div class="stat-item">
              <span class="stat-label">在线</span>
              <span class="stat-value success">{{ stats.online_devices }}</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">离线</span>
              <span class="stat-value danger">{{ stats.offline_devices }}</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">预警</span>
              <span class="stat-value warning">{{ stats.today_alerts }}</span>
            </div>
          </div>
          <el-button :icon="isFullscreen ? 'Close' : 'FullScreen'" circle @click="toggleFullscreen" title="全屏演示" size="small" />
          <el-switch v-model="isLightMode" active-text="浅色" inactive-text="深色" class="theme-switch" />
          <el-dropdown @command="handleCommand">
            <span class="user-info">
              <el-avatar :size="28">{{ userStore.user?.username?.[0]?.toUpperCase() }}</el-avatar>
              <span class="username">{{ userStore.user?.username }}</span>
              <el-icon size="12"><ArrowDown /></el-icon>
            </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="profile">个人中心</el-dropdown-item>
                <el-dropdown-item command="logout" divided>退出登录</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </header>

      <div class="main-content">
        <router-view v-slot="{ Component, route }">
          <transition name="content-fade" mode="out-in">
            <keep-alive include="Profile">
              <component :is="Component" :key="route.path" />
            </keep-alive>
          </transition>
        </router-view>
      </div>
    </main>

    <el-dialog v-model="showInviteDialog" title="" width="440px" :close-on-click-modal="true" class="invite-dialog" align-center>
      <div class="invite-dialog-content">
        <div class="dialog-icon">
          <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
            <rect x="8" y="16" width="32" height="24" rx="4" stroke="#165DFF" stroke-width="2"/>
            <path d="M8 24h32" stroke="#165DFF" stroke-width="2"/>
            <circle cx="16" cy="32" r="3" fill="#165DFF"/>
            <path d="M30 8v8M26 12h8" stroke="#0FC6C2" stroke-width="2" stroke-linecap="round"/>
          </svg>
        </div>
        <h3 class="dialog-title">功能已锁定</h3>
        <p class="dialog-desc">该功能仅对邀请用户开放，请输入邀请码解锁全部功能</p>
        <el-input v-model="inviteCodeInput" placeholder="请输入邀请码 FHQJ-XXXXXXXX" size="large" class="invite-input" />
        <div class="dialog-actions">
          <el-button @click="showInviteDialog = false" class="cancel-btn">稍后再说</el-button>
          <el-button type="primary" @click="handleActivateInvite" :loading="activating" class="activate-btn">激活并解锁</el-button>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, watch, inject } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import api from '@/api'
import { ElMessage, ElMessageBox } from 'element-plus'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const isLightMode = ref(false)
const appLightMode = inject('isLightMode', ref(false))
const isFullscreen = ref(false)
const showInviteDialog = ref(false)
const inviteCodeInput = ref('')
const activating = ref(false)
const pendingRoute = ref(null)
const bannerDismissed = ref(false)
const hasHighAlert = ref(false)
const highAlertDevice = ref('')
const pendingAlertCount = ref(0)
const stats = ref({ online_devices: 0, offline_devices: 0, today_alerts: 0 })

const activeMenu = computed(() => route.path)
const restrictedRoutes = ['/', '/devices', '/history', '/alerts']

const pageTitle = computed(() => {
  const titles = { '/': '实时监控大屏', '/devices': '设备管理', '/history': '历史数据', '/alerts': '预警记录', '/news': '消防资讯', '/twin': '3D数字孪生', '/system': '系统管理', '/profile': '个人中心' }
  return titles[route.path] || '监控中心'
})

let statsTimer = null

function handleKeydown(e) {
  if (e.key === 'Escape' && isFullscreen.value) isFullscreen.value = false
}

function navigateTo(path) {
  if (restrictedRoutes.includes(path) && !userStore.isInvited) {
    pendingRoute.value = path
    showInviteDialog.value = true
    return
  }
  router.push(path)
}

async function handleActivateInvite() {
  if (!inviteCodeInput.value.trim()) { ElMessage.warning('请输入邀请码'); return }
  activating.value = true
  try {
    await userStore.activateInvite(inviteCodeInput.value.trim())
    ElMessage.success('邀请码激活成功，已解锁全部功能！')
    showInviteDialog.value = false
    inviteCodeInput.value = ''
    if (pendingRoute.value) { router.push(pendingRoute.value); pendingRoute.value = null }
  } catch (e) {
    ElMessage.error(e.response?.data?.detail || '邀请码无效')
  } finally { activating.value = false }
}

async function fetchStats() {
  try {
    const res = await api.get('/api/stats/overview')
    stats.value = res
  } catch (e) { console.error(e) }
}

async function checkHighAlert() {
  try {
    const res = await api.get('/api/alerts?limit=5')
    const highAlerts = res.filter(a => a.alert_level === 3 && a.status === 'pending')
    hasHighAlert.value = highAlerts.length > 0
    if (highAlerts.length > 0) {
      highAlertDevice.value = highAlerts[0].device_name || '未知设备'
      bannerDismissed.value = false
    }
    pendingAlertCount.value = res.filter(a => a.status === 'pending').length
  } catch (e) { console.error(e) }
}

function goToAlerts() {
  router.push('/alerts')
  bannerDismissed.value = true
}

function toggleFullscreen() { isFullscreen.value = !isFullscreen.value }

function handleCommand(command) {
  if (command === 'logout') {
    ElMessageBox.confirm('确定要退出登录吗？', '提示', { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' })
      .then(() => { userStore.logout(); router.push('/login'); ElMessage.success('已退出登录') }).catch(() => {})
  } else if (command === 'profile') { router.push('/profile') }
}

onMounted(() => {
  const savedTheme = localStorage.getItem('themeMode')
  if (savedTheme === 'light') { isLightMode.value = true; appLightMode.value = true }
  fetchStats()
  checkHighAlert()
  statsTimer = setInterval(() => { fetchStats(); checkHighAlert() }, 5000)
})

watch(isLightMode, (val) => {
  appLightMode.value = val
  localStorage.setItem('themeMode', val ? 'light' : 'dark')
})

onUnmounted(() => { if (statsTimer) clearInterval(statsTimer) })
</script>

<style scoped>
.app-layout {
  display:flex; width:100%; height:100vh;
  background:var(--bg-base); position:relative;
}

.app-layout.high-alert-active::before {
  content:''; position:fixed; inset:0; z-index:0;
  pointer-events:none; animation:edge-red-pulse 2s ease-in-out infinite;
}

.alert-banner {
  position:fixed; top:0; left:0; right:0; z-index:100;
  background:linear-gradient(90deg, rgba(245,63,63,0.12), rgba(245,63,63,0.06), rgba(245,63,63,0.12));
  border-bottom:1px solid rgba(245,63,63,0.2);
  backdrop-filter:blur(8px);
}

.banner-edge {
  position:absolute; bottom:0; left:0; right:0; height:1px;
  background:linear-gradient(90deg, transparent, var(--accent-red), transparent);
  animation:bannerEdgePulse 2s ease-in-out infinite;
}

@keyframes bannerEdgePulse {
  0%,100% { opacity:0.3; }
  50% { opacity:1; }
}

.banner-content {
  display:flex; align-items:center; justify-content:center;
  gap:10px; padding:8px 24px;
}

.banner-icon { color:var(--accent-red); font-size:16px; animation:breathe-high 2s ease-in-out infinite; }
.banner-text { font-size:13px; color:var(--text-primary); font-weight:500; }
.banner-action { border-radius:var(--radius-sm); animation:btn-breathe 1.5s ease-in-out infinite; }

@keyframes btn-breathe {
  0%,100% { box-shadow:0 0 0 0 rgba(245,63,63,0); }
  50% { box-shadow:0 0 8px rgba(245,63,63,0.3); }
}

.banner-dismiss { color:var(--text-muted) !important; }

.alert-banner-enter-active { transition:all 0.3s var(--ease-out); }
.alert-banner-leave-active { transition:all 0.2s var(--ease-in-out); }
.alert-banner-enter-from { transform:translateY(-100%); opacity:0; }
.alert-banner-leave-to { transform:translateY(-100%); opacity:0; }

.sidebar {
  width:210px; height:100%;
  background:var(--bg-surface);
  border-right:1px solid var(--border-subtle);
  display:flex; flex-direction:column;
  transition:width 0.3s var(--ease-in-out);
}

.sidebar-header {
  padding:22px 18px;
  border-bottom:1px solid var(--border-subtle);
}

.logo { display:flex; align-items:center; gap:10px; }

.logo-text {
  font-size:16px; font-weight:700; letter-spacing:3px;
  color:var(--text-primary); white-space:nowrap;
}

.sidebar-menu { flex:1; padding:8px 0; }

.sidebar-menu .el-menu-item {
  height:44px; line-height:44px; margin:2px 8px;
  border-radius:var(--radius-sm); color:var(--text-muted);
  transition:all var(--dur-fast) var(--ease-in-out);
  position:relative; display:flex; align-items:center; font-size:13px;
}

.sidebar-menu .el-menu-item:hover {
  color:var(--text-secondary); background:var(--bg-hover);
}

.sidebar-menu .el-menu-item.is-active {
  color:var(--accent-blue-light); background:var(--accent-blue-dim);
}

.sidebar-menu .el-menu-item.is-active::before {
  content:''; position:absolute; left:0; top:50%;
  transform:translateY(-50%); width:3px; height:18px;
  border-radius:0 2px 2px 0; background:var(--accent-blue);
  animation:active-indicator var(--dur-fast) var(--ease-out) both;
}

@keyframes active-indicator {
  from { height:0; opacity:0; }
  to { height:18px; opacity:1; }
}

.sidebar-menu .el-menu-item .el-icon { color:inherit; }

.lock-tag {
  margin-left:auto; font-size:10px; padding:0 5px;
  height:16px; line-height:16px; border-radius:3px; opacity:0.5;
}

.alert-badge { margin-left:auto; }

.sidebar-footer {
  padding:14px; border-top:1px solid var(--border-subtle);
}

.invite-status {
  display:flex; align-items:center; justify-content:center;
  gap:6px; font-size:11px; color:var(--accent-orange); margin-bottom:6px;
}

.status-dot {
  width:5px; height:5px; border-radius:50%;
  background:var(--accent-orange);
}

.member-status {
  display:flex; align-items:center; justify-content:center;
  gap:6px; font-size:11px; color:var(--accent-blue); margin-bottom:6px;
}

.member-dot {
  width:5px; height:5px; border-radius:50%;
  background:var(--accent-blue);
}

.member-tier {
  background:var(--accent-blue-dim) !important;
  border-color:rgba(22,93,255,0.2) !important;
  color:var(--accent-blue) !important;
}

.version-info {
  text-align:center; font-size:10px; color:var(--text-faint); letter-spacing:1px;
}

.main-wrapper {
  flex:1; display:flex; flex-direction:column; overflow:hidden;
}

.header-bar {
  height:54px; padding:0 24px;
  background:var(--bg-surface);
  border-bottom:1px solid var(--border-subtle);
  display:flex; align-items:center; justify-content:space-between;
}

.header-left { display:flex; align-items:center; gap:10px; }

.page-title {
  font-size:16px; font-weight:600; color:var(--text-primary); letter-spacing:0.5px;
}

.user-tier-tag { font-size:10px; letter-spacing:0.5px; }

.header-right { display:flex; align-items:center; gap:16px; }

.header-stats { display:flex; gap:20px; }

.stat-item { display:flex; flex-direction:column; align-items:center; }

.stat-label { font-size:10px; color:var(--text-faint); letter-spacing:0.5px; text-transform:uppercase; }

.stat-value {
  font-size:16px; font-weight:700;
  font-variant-numeric:tabular-nums; font-family:var(--font-num);
}

.stat-value.success { color:var(--accent-green); }
.stat-value.warning { color:var(--accent-orange); }
.stat-value.danger { color:var(--accent-red); }

.theme-switch { margin:0 6px; }

.user-info {
  display:flex; align-items:center; gap:8px;
  cursor:pointer; color:var(--text-primary);
  transition:opacity var(--dur-fast);
}

.user-info:hover { opacity:0.8; }
.username { font-size:13px; color:var(--text-secondary); }

.main-content {
  flex:1; padding:20px; overflow-y:auto;
  background:var(--bg-base);
}

.content-fade-enter-active { transition:opacity 0.25s var(--ease-out), transform 0.25s var(--ease-out); }
.content-fade-leave-active { transition:opacity 0.15s var(--ease-in-out); }
.content-fade-enter-from { opacity:0; transform:translateY(8px); }
.content-fade-leave-to { opacity:0; }

.invite-dialog-content {
  display:flex; flex-direction:column; align-items:center;
  padding:10px 0 20px; text-align:center;
}

.dialog-icon { margin-bottom:20px; }
.dialog-title { font-size:18px; font-weight:700; color:var(--text-primary); margin:0 0 8px 0; }
.dialog-desc { font-size:14px; color:var(--text-secondary); margin:0 0 24px 0; line-height:1.6; }
.invite-input { width:100%; margin-bottom:20px; }
.dialog-actions { display:flex; gap:12px; width:100%; }
.cancel-btn { flex:1; border-radius:var(--radius-sm); }
.activate-btn { flex:2; border-radius:var(--radius-sm); background:var(--accent-blue); border:none; font-weight:600; letter-spacing:1px; }
.activate-btn:hover { background:var(--accent-blue-light); }

.light-mode .sidebar { background:#FFFFFF; border-right-color:#E5E6EB; }
.light-mode .logo-text { color:#1D2129; }
.light-mode .sidebar-menu .el-menu-item { color:#4E5969; }
.light-mode .sidebar-menu .el-menu-item:hover { color:#1D2129; background:#F2F3F5; }
.light-mode .sidebar-menu .el-menu-item.is-active { color:#165DFF; background:rgba(22,93,255,0.06); }
.light-mode .header-bar { background:#FFFFFF; border-bottom-color:#E5E6EB; }
.light-mode .stat-label { color:#86909C; }
.light-mode .stat-value { color:#1D2129; }
.light-mode .stat-value.success { color:#00B42A; }
.light-mode .stat-value.warning { color:#FF7D00; }
.light-mode .stat-value.danger { color:#F53F3F; }
.light-mode .version-info { color:#86909C; }
.light-mode .main-content { background:#F7F8FA; }
.light-mode .el-avatar { background:#165DFF !important; color:#fff !important; }
.light-mode .username { color:#272E3B; }
.light-mode .user-info { color:#1D2129; }
.light-mode .invite-status { color:#FF7D00; }
.light-mode .member-status { color:#165DFF; }
.light-mode .sidebar-footer { border-top-color:#E5E6EB; }
.light-mode .sidebar-header { border-bottom-color:#E5E6EB; }
.light-mode .page-title { color:#1D2129; }

@media (max-width:768px) {
  .sidebar { width:60px; }
  .sidebar-header { padding:16px 8px; }
  .logo-text { display:none; }
  .sidebar-menu .el-menu-item span { display:none; }
  .sidebar-menu .el-menu-item .lock-tag { display:none; }
  .sidebar-menu .el-menu-item .alert-badge { display:none; }
  .sidebar-footer .invite-status, .sidebar-footer .member-status, .sidebar-footer .version-info { display:none; }
  .header-stats { display:none; }
  .main-content { padding:12px; }
}
</style>
