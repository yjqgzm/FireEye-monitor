<template>
  <div class="profile-page">
    <div class="profile-hero">
      <div class="hero-pattern"></div>
      <div class="hero-content">
        <div class="hero-left">
          <el-avatar :size="64" class="hero-avatar">{{ userStore.user?.username?.[0]?.toUpperCase() }}</el-avatar>
          <div class="hero-info">
            <h2>{{ userStore.user?.username }}</h2>
            <div class="hero-tags">
              <el-tag size="small" :type="userStore.isAdmin ? 'danger' : userStore.isInvited ? 'success' : 'info'" effect="dark">
                {{ userStore.isAdmin ? '管理员' : userStore.isInvited ? '普通会员' : '基础用户' }}
              </el-tag>
              <span class="hero-email">{{ userStore.user?.email || '未绑定邮箱' }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="profile-tabs">
      <button
        v-for="tab in tabs"
        :key="tab.key"
        :class="['tab-btn', { active: activeTab === tab.key }]"
        @click="activeTab = tab.key"
      >
        <el-icon :size="15"><component :is="tab.icon" /></el-icon>
        {{ tab.label }}
      </button>
    </div>

    <Transition name="fade" mode="out-in">
      <div :key="activeTab">

        <div v-if="activeTab === 'account'" class="section-card glass-card">
          <div class="card-header">
            <el-icon :size="18" color="#22d3ee"><User /></el-icon>
            <h3>账号信息</h3>
          </div>
          <div class="card-body">
            <div class="info-grid">
              <div class="info-item">
                <span class="info-label">用户名</span>
                <span class="info-value">{{ userStore.user?.username }}</span>
              </div>
              <div class="info-item">
                <span class="info-label">角色</span>
                <el-tag size="small" :type="userStore.isAdmin ? 'danger' : userStore.isInvited ? 'success' : 'info'">
                  {{ userStore.isAdmin ? '管理员' : userStore.isInvited ? '普通会员' : '基础用户' }}
                </el-tag>
              </div>
              <div class="info-item">
                <span class="info-label">邮箱</span>
                <span class="info-value">{{ userStore.user?.email || '未绑定' }}</span>
              </div>
              <div class="info-item">
                <span class="info-label">最后登录</span>
                <span class="info-value">{{ formatTime(userStore.user?.last_login) }}</span>
              </div>
            </div>
            <div class="invite-section" v-if="!userStore.isInvited && !userStore.isAdmin">
              <el-divider />
              <div class="invite-row">
                <div>
                  <div class="invite-title">激活会员</div>
                  <div class="invite-desc">输入邀请码解锁全部功能</div>
                </div>
                <div class="invite-action">
                  <el-input v-model="inviteCode" placeholder="输入邀请码" size="small" style="width: 160px; margin-right: 8px" />
                  <el-button type="primary" size="small" @click="activateInvite" :loading="loading">激活</el-button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div v-if="activeTab === 'security'" class="section-card glass-card">
          <div class="card-header">
            <el-icon :size="18" color="#f87171"><Lock /></el-icon>
            <h3>安全设置</h3>
          </div>
          <div class="card-body">
            <div class="setting-item">
              <div class="setting-left">
                <div class="setting-icon-wrap" style="background: rgba(248,113,113,0.08); color: #f87171;">
                  <el-icon :size="16"><Lock /></el-icon>
                </div>
                <div class="setting-text">
                  <span class="setting-name">修改密码</span>
                  <span class="setting-desc">定期修改密码保障账号安全</span>
                </div>
              </div>
              <el-button type="primary" size="small" @click="showPasswordDialog = true">修改</el-button>
            </div>
            <div class="setting-item">
              <div class="setting-left">
                <div class="setting-icon-wrap" style="background: rgba(34,211,238,0.08); color: #22d3ee;">
                  <el-icon :size="16"><Message /></el-icon>
                </div>
                <div class="setting-text">
                  <span class="setting-name">绑定邮箱</span>
                  <span class="setting-desc">当前: {{ userStore.user?.email || '未绑定' }}</span>
                </div>
              </div>
              <el-button type="primary" size="small" @click="showEmailDialog = true">修改</el-button>
            </div>
          </div>
        </div>

        <div v-if="activeTab === 'display'" class="section-card glass-card">
          <div class="card-header">
            <el-icon :size="18" color="#818cf8"><Monitor /></el-icon>
            <h3>显示设置</h3>
          </div>
          <div class="card-body">
            <div class="setting-item" style="flex-direction: column; align-items: stretch;">
              <div class="setting-row-top">
                <div class="setting-left">
                  <div class="setting-icon-wrap" style="background: rgba(129,140,248,0.08); color: #818cf8;">
                    <el-icon :size="16"><EditPen /></el-icon>
                  </div>
                  <div class="setting-text">
                    <span class="setting-name">字体大小</span>
                    <span class="setting-desc">调整全局界面文字大小，当前 {{ fontSize }}px</span>
                  </div>
                </div>
              </div>
              <div class="font-slider-row">
                <span class="font-label-sm">A</span>
                <el-slider
                  v-model="fontSize"
                  :min="12"
                  :max="20"
                  :step="1"
                  :format-tooltip="v => v + 'px'"
                  style="flex: 1; margin: 0 16px"
                  @change="applyFontSize"
                />
                <span class="font-label-lg">A</span>
              </div>
              <div class="preview-box" :style="{ fontSize: fontSize + 'px' }">
                火睛智控中心 — 实时监控温度 36.5°C，设备运行正常
              </div>
            </div>
          </div>
        </div>

        <div v-if="activeTab === 'snapshot' && userStore.isAdmin" class="section-card glass-card">
          <div class="card-header">
            <el-icon :size="18" color="#f87171"><FolderOpened /></el-icon>
            <h3>数据镜像</h3>
            <el-button type="primary" size="small" style="margin-left: auto;" @click="showSnapshotDialog = true">创建镜像</el-button>
          </div>
          <div class="card-body">
            <div class="snapshot-tip">
              <el-icon :size="14"><InfoFilled /></el-icon>
              <span>数据镜像可对当前数据库创建完整快照，当数据丢失时可通过镜像回溯恢复</span>
            </div>
            <div class="snapshot-list" v-if="snapshots.length > 0">
              <div class="snapshot-item" v-for="snap in snapshots" :key="snap.id">
                <div class="snap-left">
                  <div class="snap-icon" :class="{ 'auto-snap': snap.snapshot_type !== 'manual' }">
                    <el-icon :size="16"><FolderOpened /></el-icon>
                  </div>
                  <div class="snap-info">
                    <div class="snap-name">{{ snap.name }}</div>
                    <div class="snap-meta">
                      {{ formatTime(snap.created_at) }} · {{ formatSize(snap.db_size) }}
                      <span v-if="snap.device_count"> · {{ snap.device_count }}设备</span>
                      <span v-if="snap.alert_count"> · {{ snap.alert_count }}预警</span>
                    </div>
                  </div>
                </div>
                <div class="snap-actions">
                  <el-tag v-if="!snap.file_exists" size="small" type="danger">文件丢失</el-tag>
                  <el-button v-if="snap.file_exists" type="warning" size="small" plain @click="confirmRestore(snap)">恢复</el-button>
                  <el-button type="danger" size="small" plain @click="deleteSnapshot(snap.id)">删除</el-button>
                </div>
              </div>
            </div>
            <el-empty v-else description="暂无数据镜像，点击上方按钮创建" :image-size="60">
              <template #description>
                <p>暂无数据镜像</p>
                <p style="font-size:11px;color:var(--text-muted);margin-top:4px;">点击上方「创建镜像」按钮新建</p>
              </template>
            </el-empty>
          </div>
        </div>

      </div>
    </Transition>

    <el-dialog v-model="showPasswordDialog" title="修改密码" width="420px" :close-on-click-modal="false">
      <el-form :model="passwordForm" label-width="80px">
        <el-form-item label="原密码">
          <el-input v-model="passwordForm.old_password" type="password" show-password placeholder="请输入原密码" />
        </el-form-item>
        <el-form-item label="新密码">
          <el-input v-model="passwordForm.new_password" type="password" show-password placeholder="至少6位" />
        </el-form-item>
        <el-form-item label="确认密码">
          <el-input v-model="passwordForm.confirm_password" type="password" show-password placeholder="再次输入新密码" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showPasswordDialog = false">取消</el-button>
        <el-button type="primary" @click="changePassword" :loading="loading">确认修改</el-button>
      </template>
    </el-dialog>

    <el-dialog v-model="showEmailDialog" title="修改绑定邮箱" width="420px" :close-on-click-modal="false">
      <el-form :model="emailForm" label-width="80px">
        <el-form-item label="新邮箱">
          <el-input v-model="emailForm.new_email" placeholder="请输入新邮箱地址" />
        </el-form-item>
        <el-form-item label="登录密码">
          <el-input v-model="emailForm.password" type="password" show-password placeholder="验证身份" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showEmailDialog = false">取消</el-button>
        <el-button type="primary" @click="changeEmail" :loading="loading">确认修改</el-button>
      </template>
    </el-dialog>

    <el-dialog v-model="showSnapshotDialog" title="创建数据镜像" width="420px" :close-on-click-modal="false">
      <el-form :model="snapshotForm" label-width="80px">
        <el-form-item label="镜像名称">
          <el-input v-model="snapshotForm.name" placeholder="如: 部署前备份" />
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="snapshotForm.description" type="textarea" :rows="2" placeholder="可选" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showSnapshotDialog = false">取消</el-button>
        <el-button type="primary" @click="createSnapshot" :loading="loading">创建镜像</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
defineOptions({ name: 'Profile' })
import { ref, computed, onMounted, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import api from '@/api'
import { useUserStore } from '@/stores/user'

const userStore = useUserStore()
const loading = ref(false)
const activeTab = ref('account')
const fontSize = ref(parseInt(localStorage.getItem('fontSize') || '14'))
const snapshots = ref([])
const inviteCode = ref('')

const tabs = computed(() => {
  const list = [
    { key: 'account', label: '账号信息', icon: 'User' },
    { key: 'security', label: '安全设置', icon: 'Lock' },
    { key: 'display', label: '显示设置', icon: 'Monitor' },
  ]
  if (userStore.isAdmin) {
    list.push({ key: 'snapshot', label: '数据镜像', icon: 'FolderOpened' })
  }
  return list
})

const showPasswordDialog = ref(false)
const showEmailDialog = ref(false)
const showSnapshotDialog = ref(false)

const passwordForm = ref({ old_password: '', new_password: '', confirm_password: '' })
const emailForm = ref({ new_email: '', password: '' })
const snapshotForm = ref({ name: '', description: '' })

function applyFontSize(val) {
  document.documentElement.style.setProperty('--app-font-size', val + 'px')
  document.documentElement.style.fontSize = val + 'px'
  const zoom = val / 14
  document.documentElement.style.setProperty('--app-zoom', zoom)
  const appRoot = document.querySelector('.app-root')
  if (appRoot) appRoot.style.zoom = zoom
  localStorage.setItem('fontSize', val)
}

function formatTime(timeStr) {
  if (!timeStr) return '从未'
  const d = new Date(timeStr)
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`
}

function formatSize(bytes) {
  if (!bytes) return '0B'
  if (bytes < 1024) return bytes + 'B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + 'KB'
  return (bytes / 1024 / 1024).toFixed(2) + 'MB'
}

async function activateInvite() {
  if (!inviteCode.value) return ElMessage.warning('请输入邀请码')
  loading.value = true
  try {
    await api.post('/api/auth/activate-invite', { invite_code: inviteCode.value })
    ElMessage.success('会员激活成功')
    inviteCode.value = ''
    userStore.fetchUserInfo()
  } catch (e) {
    ElMessage.error(e.response?.data?.detail || '激活失败')
  } finally {
    loading.value = false
  }
}

async function changePassword() {
  if (!passwordForm.value.old_password || !passwordForm.value.new_password) {
    return ElMessage.warning('请填写完整')
  }
  if (passwordForm.value.new_password !== passwordForm.value.confirm_password) {
    return ElMessage.warning('两次密码输入不一致')
  }
  if (passwordForm.value.new_password.length < 6) {
    return ElMessage.warning('新密码长度不能少于6位')
  }
  loading.value = true
  try {
    await api.put('/api/settings/password', {
      old_password: passwordForm.value.old_password,
      new_password: passwordForm.value.new_password
    })
    ElMessage.success('密码修改成功')
    showPasswordDialog.value = false
    passwordForm.value = { old_password: '', new_password: '', confirm_password: '' }
  } catch (e) {
    ElMessage.error(e.response?.data?.detail || '修改失败')
  } finally {
    loading.value = false
  }
}

async function changeEmail() {
  if (!emailForm.value.new_email || !emailForm.value.password) {
    return ElMessage.warning('请填写完整')
  }
  if (!emailForm.value.new_email.includes('@')) {
    return ElMessage.warning('请输入有效的邮箱地址')
  }
  loading.value = true
  try {
    await api.put('/api/settings/email', {
      new_email: emailForm.value.new_email,
      password: emailForm.value.password
    })
    ElMessage.success('邮箱修改成功')
    showEmailDialog.value = false
    emailForm.value = { new_email: '', password: '' }
    userStore.fetchUserInfo()
  } catch (e) {
    ElMessage.error(e.response?.data?.detail || '修改失败')
  } finally {
    loading.value = false
  }
}

async function fetchSnapshots() {
  if (!userStore.isAdmin) {
    if (!userStore.user) {
      console.log('[镜像] 用户信息未加载，等待中...')
      await userStore.fetchUserInfo()
    }
    if (!userStore.isAdmin) {
      console.log('[镜像] 非管理员，跳过加载. role=', userStore.user?.role)
      return
    }
  }
  try {
    console.log('[镜像] 开始请求 /api/snapshots...')
    const res = await api.get('/api/snapshots')
    console.log('[镜像] API原始响应:', JSON.stringify(res), '类型:', typeof res, '是否数组:', Array.isArray(res))
    let data = []
    if (Array.isArray(res)) {
      data = res
    } else if (res && Array.isArray(res.data)) {
      data = res.data
    } else if (res && typeof res === 'object') {
      const possibleKeys = Object.keys(res)
      for (const key of possibleKeys) {
        if (Array.isArray(res[key])) {
          data = res[key]
          break
        }
      }
    }
    console.log('[镜像] 解析后数据:', data.length, '条')
    snapshots.value = data
  } catch (e) {
    console.error('[镜像] 获取失败详情:', e)
    console.error('[镜像] 响应状态:', e.response?.status)
    console.error('[镜像] 响应数据:', e.response?.data)
    if (e.response?.status === 404) {
      snapshots.value = []
      console.warn('[镜像] 接口返回404，后端可能未加载新代码')
    } else if (e.response?.status === 403) {
      ElMessage.warning('权限不足：需要管理员账号')
      snapshots.value = []
    } else {
      snapshots.value = []
    }
  }
}

async function createSnapshot() {
  if (!snapshotForm.value.name) return ElMessage.warning('请输入镜像名称')
  loading.value = true
  try {
    const res = await api.post('/api/snapshots', {
      name: snapshotForm.value.name,
      description: snapshotForm.value.description
    })
    ElMessage.success('数据镜像创建成功')
    showSnapshotDialog.value = false
    snapshotForm.value = { name: '', description: '' }
    if (res && res.snapshot) {
      snapshots.value.unshift({
        id: res.snapshot.id,
        name: res.snapshot.name,
        description: snapshotForm.value.description,
        snapshot_type: 'manual',
        db_size: res.snapshot.db_size,
        device_count: res.snapshot.device_count,
        alert_count: res.snapshot.alert_count,
        sensor_data_count: res.snapshot.sensor_data_count,
        file_exists: true,
        created_at: res.snapshot.created_at
      })
    } else {
      await fetchSnapshots()
    }
  } catch (e) {
    console.error('[镜像] 创建失败:', e)
    ElMessage.error(e.response?.data?.detail || '创建失败: ' + (e.message || '未知错误'))
  } finally {
    loading.value = false
  }
}

async function confirmRestore(snap) {
  try {
    await ElMessageBox.confirm(
      `确定要从镜像 "${snap.name}" 恢复数据吗？\n\n• 恢复后当前运行数据将被覆盖\n• 系统会自动备份当前数据为"恢复前自动备份"\n• 原镜像不会被删除，可继续使用\n• 恢复后需要重启后端服务使更改生效`,
      '确认恢复数据',
      { confirmButtonText: '确认恢复', cancelButtonText: '取消', type: 'warning' }
    )
    loading.value = true
    const res = await api.post(`/api/snapshots/${snap.id}/restore`)
    ElMessage.success(res.message || '恢复成功，请重启后端服务')
    fetchSnapshots()
  } catch (e) {
    if (e !== 'cancel') ElMessage.error(e.response?.data?.detail || '恢复失败')
  } finally {
    loading.value = false
  }
}

async function deleteSnapshot(id) {
  try {
    await ElMessageBox.confirm(
      '确定要删除此镜像吗？删除后镜像文件和数据将永久丢失，无法恢复。此操作不影响当前运行数据。',
      '确认删除镜像',
      { confirmButtonText: '确认删除', cancelButtonText: '取消', type: 'warning' }
    )
    await api.delete(`/api/snapshots/${id}`)
    ElMessage.success('镜像已删除')
    fetchSnapshots()
  } catch (e) {
    if (e !== 'cancel') ElMessage.error(e.response?.data?.detail || '删除失败')
  }
}

onMounted(async () => {
  applyFontSize(fontSize.value)
  if (userStore.token && !userStore.user) {
    await userStore.fetchUserInfo()
  }
  await fetchSnapshots()
})

watch(() => userStore.isAdmin, (val) => {
  if (val && snapshots.value.length === 0) {
    fetchSnapshots()
  }
})
</script>

<style scoped>
.profile-page { height: 100%; overflow-y: auto; padding-right: 4px; }

.profile-hero {
  position: relative;
  height: 140px;
  border-radius: 20px;
  overflow: hidden;
  margin-bottom: 20px;
  background: linear-gradient(135deg, #030712, #1e1b4b, #312e81);
}

.hero-pattern {
  position: absolute;
  inset: 0;
  background-image:
    radial-gradient(circle at 20% 80%, rgba(99, 102, 241, 0.15) 0%, transparent 50%),
    radial-gradient(circle at 80% 20%, rgba(6, 182, 212, 0.1) 0%, transparent 50%);
}

.hero-content {
  position: relative;
  z-index: 1;
  padding: 28px 32px;
  height: 100%;
  display: flex;
  align-items: center;
}

.hero-left { display: flex; align-items: center; gap: 20px; }

.hero-avatar {
  background: linear-gradient(135deg, #6366f1, #8b5cf6) !important;
  font-size: 28px !important;
  font-weight: 700;
  border: 3px solid rgba(255,255,255,0.15);
}

.hero-info h2 {
  font-size: 22px;
  font-weight: 700;
  color: #f1f5f9;
  margin: 0 0 6px 0;
}

.hero-tags { display: flex; align-items: center; gap: 10px; }

.hero-email { font-size: 13px; color: rgba(203, 213, 225, 0.6); }

.profile-tabs {
  display: flex;
  gap: 6px;
  margin-bottom: 20px;
  background: rgba(99, 102, 241, 0.04);
  padding: 4px;
  border-radius: 12px;
  border: 1px solid var(--border-light);
}

.tab-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 10px 18px;
  border: none;
  border-radius: 9px;
  background: transparent;
  color: var(--text-secondary);
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.25s ease;
}

.tab-btn:hover { color: var(--primary-light); background: rgba(99, 102, 241, 0.06); }

.tab-btn.active {
  background: linear-gradient(135deg, rgba(99, 102, 241, 0.18), rgba(6, 182, 212, 0.08));
  color: var(--primary-light);
  box-shadow: 0 2px 8px rgba(99, 102, 241, 0.12);
}

.section-card { border-radius: 16px; padding: 0; overflow: hidden; }

.card-header {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 20px 24px 0;
}

.card-header h3 { font-size: 16px; font-weight: 600; color: var(--text-primary); margin: 0; }

.card-body { padding: 16px 24px 24px; }

.info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }

.info-item { display: flex; flex-direction: column; gap: 4px; }

.info-label { font-size: 12px; color: var(--text-muted); }

.info-value { font-size: 14px; font-weight: 500; color: var(--text-primary); }

.invite-section { margin-top: 0; }

.invite-row { display: flex; justify-content: space-between; align-items: center; }

.invite-title { font-size: 14px; font-weight: 500; color: var(--text-primary); }

.invite-desc { font-size: 12px; color: var(--text-muted); margin-top: 2px; }

.invite-action { display: flex; align-items: center; }

.setting-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 0;
  border-bottom: 1px solid var(--border-light);
}

.setting-item:last-child { border-bottom: none; }

.setting-left { display: flex; align-items: center; gap: 14px; }

.setting-icon-wrap {
  width: 38px;
  height: 38px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.setting-text { display: flex; flex-direction: column; gap: 2px; }

.setting-name { font-size: 14px; font-weight: 500; color: var(--text-primary); }

.setting-desc { font-size: 12px; color: var(--text-muted); }

.setting-row-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }

.font-slider-row { display: flex; align-items: center; margin-bottom: 14px; }

.font-label-sm { font-size: 12px; color: var(--text-muted); }

.font-label-lg { font-size: 20px; font-weight: 700; color: var(--text-muted); }

.preview-box {
  padding: 14px 18px;
  border-radius: 10px;
  background: rgba(99, 102, 241, 0.04);
  border: 1px solid var(--border-light);
  color: var(--text-secondary);
  line-height: 1.6;
  transition: font-size 0.2s ease;
}

.snapshot-tip {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: var(--text-muted);
  padding: 10px 14px;
  border-radius: 8px;
  background: rgba(99, 102, 241, 0.03);
  border: 1px solid var(--border-light);
  margin-bottom: 14px;
}

.snapshot-list { display: flex; flex-direction: column; }

.snapshot-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 14px 0;
  border-bottom: 1px solid var(--border-light);
}

.snapshot-item:last-child { border-bottom: none; }

.snap-left { display: flex; align-items: center; gap: 12px; }

.snap-icon {
  width: 38px;
  height: 38px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(248, 113, 113, 0.08);
  color: #f87171;
  flex-shrink: 0;
}

.snap-icon.auto-snap {
  background: rgba(99, 102, 241, 0.08);
  color: #818cf8;
}

.snap-info { display: flex; flex-direction: column; gap: 3px; }

.snap-name { font-size: 14px; font-weight: 500; color: var(--text-primary); }

.snap-meta { font-size: 11px; color: var(--text-muted); }

.snap-actions { display: flex; align-items: center; gap: 6px; }

.fade-enter-active { transition: all 0.2s ease-out; }
.fade-leave-active { transition: all 0.15s ease-in; }
.fade-enter-from { opacity: 0; transform: translateY(8px); }
.fade-leave-to { opacity: 0; transform: translateY(-8px); }

@media (max-width: 768px) {
  .info-grid { grid-template-columns: 1fr; }
  .invite-row { flex-direction: column; gap: 10px; align-items: flex-start; }
}
</style>
