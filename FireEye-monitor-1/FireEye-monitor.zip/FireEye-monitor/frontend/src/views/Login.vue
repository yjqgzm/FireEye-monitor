<template>
  <div :class="['login-page', { 'light-mode': isLightMode }]">
    <div class="login-left">
      <div class="left-bg">
        <div class="bg-base"></div>
        <div class="bg-glow bg-glow-a"></div>
        <div class="bg-glow bg-glow-b"></div>

        <div class="building-grid">
          <svg class="building-svg" viewBox="0 0 800 600" preserveAspectRatio="xMidYMid slice">
            <defs>
              <linearGradient id="gridGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#165DFF" stop-opacity="0.03" />
                <stop offset="100%" stop-color="#0FC6C2" stop-opacity="0.015" />
              </linearGradient>
            </defs>
            <g stroke="url(#gridGrad)" stroke-width="0.5" fill="none">
              <line v-for="i in 17" :key="'gh'+i" :x1="0" :y1="i*36" :x2="800" :y2="i*36" />
              <line v-for="i in 21" :key="'gv'+i" :x1="i*40" :y1="0" :x2="i*40" :y2="600" />
            </g>
            <g stroke="rgba(22,93,255,0.08)" stroke-width="1" fill="none">
              <rect x="120" y="180" width="200" height="240" rx="2" />
              <rect x="140" y="200" width="40" height="50" rx="1" />
              <rect x="200" y="200" width="40" height="50" rx="1" />
              <rect x="260" y="200" width="40" height="50" rx="1" />
              <rect x="140" y="280" width="40" height="50" rx="1" />
              <rect x="200" y="280" width="40" height="50" rx="1" />
              <rect x="260" y="280" width="40" height="50" rx="1" />
              <rect x="140" y="360" width="40" height="50" rx="1" />
              <rect x="200" y="360" width="40" height="50" rx="1" />
              <rect x="260" y="360" width="40" height="50" rx="1" />
              <rect x="440" y="120" width="160" height="300" rx="2" />
              <rect x="460" y="140" width="30" height="40" rx="1" />
              <rect x="510" y="140" width="30" height="40" rx="1" />
              <rect x="560" y="140" width="30" height="40" rx="1" />
              <rect x="460" y="210" width="30" height="40" rx="1" />
              <rect x="510" y="210" width="30" height="40" rx="1" />
              <rect x="560" y="210" width="30" height="40" rx="1" />
              <rect x="460" y="280" width="30" height="40" rx="1" />
              <rect x="510" y="280" width="30" height="40" rx="1" />
              <rect x="560" y="280" width="30" height="40" rx="1" />
              <rect x="460" y="350" width="30" height="40" rx="1" />
              <rect x="510" y="350" width="30" height="40" rx="1" />
              <rect x="560" y="350" width="30" height="40" rx="1" />
              <rect x="660" y="240" width="100" height="180" rx="2" />
              <rect x="675" y="260" width="25" height="35" rx="1" />
              <rect x="720" y="260" width="25" height="35" rx="1" />
              <rect x="675" y="320" width="25" height="35" rx="1" />
              <rect x="720" y="320" width="25" height="35" rx="1" />
            </g>
            <circle cx="160" cy="225" r="2" fill="#165DFF" opacity="0.25" />
            <circle cx="220" cy="305" r="2" fill="#0FC6C2" opacity="0.2" />
            <circle cx="475" cy="160" r="2" fill="#165DFF" opacity="0.25" />
            <circle cx="525" cy="230" r="2" fill="#FF7D00" opacity="0.2" />
            <circle cx="690" cy="278" r="2" fill="#165DFF" opacity="0.2" />
          </svg>
        </div>

        <div class="scan-line"></div>
        <div class="bottom-line"></div>
      </div>

      <div class="brand-content">
        <div class="brand-badge">
          <span class="badge-dot"></span>
          <span class="badge-text">AI FIRE RISK EARLY WARNING</span>
        </div>
        <h1 class="brand-title">火睛智控中心</h1>
        <div class="title-underline"></div>
        <p class="brand-en">FireGuard Intelligent Control Center</p>
        <p class="brand-desc">集成温度、湿度、烟雾、气体与多源环境数据的<br/>智能火灾风险感知与预警平台</p>
        <div class="feature-grid">
          <div class="feat" v-for="(f, i) in features" :key="i" :style="{ animationDelay: `${0.8 + i * 0.12}s` }">
            <div class="feat-icon-wrap">
              <svg class="feat-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" v-html="f.svg"></svg>
            </div>
            <span class="feat-text">{{ f.text }}</span>
          </div>
        </div>
      </div>
    </div>

    <div class="login-right">
      <button class="theme-toggle" @click="toggleTheme" :title="isLightMode ? '切换深色模式' : '切换浅色模式'">
        <svg v-if="isLightMode" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/></svg>
        <svg v-else viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
      </button>

      <div class="login-card">
        <div class="card-inner">
          <div class="card-top">
            <h3>登录系统</h3>
            <p>访问智能预警平台</p>
          </div>
          <el-form ref="formRef" :model="form" :rules="rules" @submit.prevent="handleLogin" class="login-form">
            <el-form-item prop="username">
              <div class="input-wrap" :class="{ 'is-focus': focusState.username, 'is-error': errorState.username }">
                <div class="input-icon">
                  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2" y="4" width="20" height="16" rx="3"/><path d="M22 7l-10 6L2 7"/></svg>
                </div>
                <input
                  v-model="form.username"
                  type="email"
                  placeholder="请输入邮箱"
                  class="custom-input"
                  @focus="focusState.username = true"
                  @blur="focusState.username = false; validateField('username')"
                  @input="clearError('username')"
                />
              </div>
              <transition name="error-slide">
                <span v-if="errorState.username" class="field-error">{{ errorState.username }}</span>
              </transition>
            </el-form-item>
            <el-form-item prop="password">
              <div class="input-wrap" :class="{ 'is-focus': focusState.password, 'is-error': errorState.password }">
                <div class="input-icon">
                  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="11" width="18" height="11" rx="3"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
                </div>
                <input
                  v-model="form.password"
                  :type="showPassword ? 'text' : 'password'"
                  placeholder="请输入密码"
                  class="custom-input"
                  @focus="focusState.password = true"
                  @blur="focusState.password = false; validateField('password')"
                  @input="clearError('password')"
                  @keyup.enter="handleLogin"
                />
                <button type="button" class="pwd-toggle" @click="showPassword = !showPassword" tabindex="-1">
                  <svg v-if="showPassword" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                  <svg v-else viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                </button>
              </div>
              <transition name="error-slide">
                <span v-if="errorState.password" class="field-error">{{ errorState.password }}</span>
              </transition>
            </el-form-item>

            <div v-if="captchaEnabled" class="captcha-row">
              <div class="input-wrap captcha-input" :class="{ 'is-focus': focusState.captcha, 'is-error': errorState.captcha }">
                <div class="input-icon">
                  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                </div>
                <input
                  v-model="form.captcha"
                  type="text"
                  placeholder="请输入验证码"
                  class="custom-input"
                  maxlength="4"
                  @focus="focusState.captcha = true"
                  @blur="focusState.captcha = false"
                  @input="clearError('captcha')"
                />
              </div>
              <div class="captcha-img" @click="refreshCaptcha" title="点击刷新验证码">
                <canvas ref="captchaCanvas" width="100" height="42"></canvas>
              </div>
            </div>

            <div class="form-row">
              <label class="custom-checkbox" :class="{ 'is-checked': form.remember }">
                <input type="checkbox" v-model="form.remember" class="checkbox-hidden" />
                <span class="checkbox-box">
                  <svg viewBox="0 0 12 12" width="10" height="10" fill="none" stroke="#fff" stroke-width="2"><path d="M2 6l3 3 5-5"/></svg>
                </span>
                <span class="checkbox-label">记住密码</span>
              </label>
              <a class="forgot-link" @click="showForgotTip">忘记密码？</a>
            </div>

            <button type="button" class="login-btn" :class="{ 'is-loading': loading, 'is-success': loginSuccess }" :disabled="loading || loginSuccess" @click="handleLogin">
              <span v-if="loginSuccess" class="btn-content">
                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 6L9 17l-5-5"/></svg>
                登录成功
              </span>
              <span v-else-if="loading" class="btn-content"><span class="btn-spinner"></span>登录中...</span>
              <span v-else class="btn-content">登 录</span>
            </button>

            <transition name="security-tip">
              <div v-if="securityTip" class="security-tip" :class="securityTipType">
                <svg v-if="securityTipType === 'warning'" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                <svg v-else viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                {{ securityTip }}
              </div>
            </transition>
          </el-form>

          <div class="card-bottom">
            <div class="demo-line">
              <span class="demo-label">演示账号</span>
              <code>admin@example.com</code>
              <span class="demo-sep">/</span>
              <code>123456</code>
              <button class="fill-btn" @click="fillDemo">一键填充</button>
            </div>
            <div class="reg-line">
              <span>没有账户？</span>
              <router-link to="/register" class="reg-link">立即注册</router-link>
            </div>
          </div>
        </div>
      </div>

      <div class="footer-text">
        <span>火睛智控中心 V10.0 · Powered by AI · 合规安全认证</span>
        <span class="footer-links">
          <a href="javascript:void(0)" @click="showPolicy('privacy')">隐私政策</a>
          <span class="footer-sep">|</span>
          <a href="javascript:void(0)" @click="showPolicy('terms')">用户协议</a>
        </span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, inject, onMounted, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { ElMessage } from 'element-plus'

const router = useRouter()
const userStore = useUserStore()
const formRef = ref(null)
const loading = ref(false)
const loginSuccess = ref(false)
const isLightMode = inject('isLightMode', ref(false))
const showPassword = ref(false)
const captchaEnabled = ref(true)
const captchaCanvas = ref(null)
const captchaCode = ref('')
const loginFailCount = ref(0)
const securityTip = ref('')
const securityTipType = ref('info')

const focusState = reactive({ username: false, password: false, captcha: false })
const errorState = reactive({ username: '', password: '', captcha: '' })

const form = reactive({ username: '', password: '', remember: false, captcha: '' })
const rules = {
  username: [{ required: true, message: '请输入邮箱', trigger: 'blur' }, { type: 'email', message: '请输入有效的邮箱地址', trigger: 'blur' }],
  password: [{ required: true, message: '请输入密码', trigger: 'blur' }]
}

const features = [
  { text: '实时温度监测', svg: '<path d="M14 14.76V3.5a2.5 2.5 0 00-5 0v11.26a4.5 4.5 0 105 0z"/>' },
  { text: '烟雾气体检测', svg: '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z"/><circle cx="12" cy="12" r="3"/>' },
  { text: 'AI风险研判', svg: '<path d="M12 2a10 10 0 1010 10A10 10 0 0012 2zm0 18a8 8 0 118-8 8 8 0 01-8 8z"/><path d="M12 6v6l4 2"/>' },
  { text: '多源数据融合', svg: '<path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>' }
]

function generateCaptcha() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  let code = ''
  for (let i = 0; i < 4; i++) code += chars[Math.floor(Math.random() * chars.length)]
  return code
}

function drawCaptcha() {
  if (!captchaCanvas.value) return
  const canvas = captchaCanvas.value
  const ctx = canvas.getContext('2d')
  const w = canvas.width
  const h = canvas.height
  ctx.clearRect(0, 0, w, h)

  const bgColor = isLightMode.value ? '#F2F3F5' : '#0F172A'
  ctx.fillStyle = bgColor
  ctx.fillRect(0, 0, w, h)

  for (let i = 0; i < 4; i++) {
    ctx.strokeStyle = isLightMode.value ? 'rgba(22,93,255,0.08)' : 'rgba(22,93,255,0.06)'
    ctx.beginPath()
    ctx.moveTo(Math.random() * w, Math.random() * h)
    ctx.lineTo(Math.random() * w, Math.random() * h)
    ctx.stroke()
  }

  for (let i = 0; i < 30; i++) {
    ctx.fillStyle = isLightMode.value ? 'rgba(22,93,255,0.15)' : 'rgba(22,93,255,0.1)'
    ctx.beginPath()
    ctx.arc(Math.random() * w, Math.random() * h, 1, 0, 2 * Math.PI)
    ctx.fill()
  }

  captchaCode.value = generateCaptcha()
  const colors = ['#165DFF', '#0FC6C2', '#FF7D00', '#00B42A']
  for (let i = 0; i < captchaCode.value.length; i++) {
    ctx.save()
    ctx.font = `bold ${17 + Math.random() * 5}px 'SF Mono','Fira Code','Consolas',monospace`
    ctx.fillStyle = colors[i % colors.length]
    const x = 12 + i * 22
    const y = 27 + Math.random() * 8
    ctx.translate(x, y)
    ctx.rotate((Math.random() - 0.5) * 0.4)
    ctx.fillText(captchaCode.value[i], 0, 0)
    ctx.restore()
  }
}

function refreshCaptcha() {
  form.captcha = ''
  nextTick(() => drawCaptcha())
}

function validateField(field) {
  if (field === 'username') {
    if (!form.username) errorState.username = '请输入邮箱'
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.username)) errorState.username = '请输入有效的邮箱地址'
    else errorState.username = ''
  } else if (field === 'password') {
    if (!form.password) errorState.password = '请输入密码'
    else if (form.password.length < 6) errorState.password = '密码长度不能少于6位'
    else errorState.password = ''
  }
}

function clearError(field) {
  errorState[field] = ''
}

function fillDemo() {
  form.username = 'admin@example.com'
  form.password = '123456'
  errorState.username = ''
  errorState.password = ''
}

function showForgotTip() {
  ElMessage.info('请联系系统管理员重置密码')
}

function showPolicy(type) {
  const title = type === 'privacy' ? '隐私政策' : '用户协议'
  ElMessage.info(`${title}页面正在建设中`)
}

function toggleTheme() {
  isLightMode.value = !isLightMode.value
  localStorage.setItem('themeMode', isLightMode.value ? 'light' : 'dark')
  nextTick(() => drawCaptcha())
}

function showSecurityTip(msg, type = 'warning') {
  securityTip.value = msg
  securityTipType.value = type
  setTimeout(() => { securityTip.value = '' }, 5000)
}

async function handleLogin() {
  let hasError = false
  if (!form.username) { errorState.username = '请输入邮箱'; hasError = true }
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.username)) { errorState.username = '请输入有效的邮箱地址'; hasError = true }
  if (!form.password) { errorState.password = '请输入密码'; hasError = true }
  else if (form.password.length < 6) { errorState.password = '密码长度不能少于6位'; hasError = true }

  if (captchaEnabled.value && form.captcha.toUpperCase() !== captchaCode.value.toUpperCase()) {
    errorState.captcha = '验证码错误'
    refreshCaptcha()
    hasError = true
  }

  if (hasError) return

  loading.value = true
  try {
    await userStore.login(form.username, form.password)
    loginSuccess.value = true
    ElMessage.success('登录成功')
    setTimeout(() => { router.push('/') }, 600)
  } catch (e) {
    loginFailCount.value++
    refreshCaptcha()
    form.captcha = ''
    if (loginFailCount.value >= 3) {
      showSecurityTip('连续登录失败次数过多，请确认账号安全', 'warning')
    } else if (loginFailCount.value >= 2) {
      showSecurityTip('密码错误，请仔细核对后重试', 'info')
    }
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  nextTick(() => {
    if (captchaEnabled.value) drawCaptcha()
  })
})
</script>

<style scoped>
.login-page {
  width: 100%;
  height: 100vh;
  display: flex;
  overflow: hidden;
  background: var(--bg-base);
}

.login-left {
  flex: 1;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  animation: leftFadeIn 0.8s ease-out both;
}

@keyframes leftFadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

.left-bg {
  position: absolute;
  inset: 0;
}

.bg-base {
  position: absolute;
  inset: 0;
  background: linear-gradient(160deg, #070B14 0%, #0F172A 40%, #111827 70%, #070B14 100%);
}

.bg-glow {
  position: absolute;
  border-radius: 50%;
  filter: blur(140px);
  pointer-events: none;
}

.bg-glow-a {
  width: 600px;
  height: 600px;
  background: rgba(22, 93, 255, 0.05);
  top: -15%;
  right: -10%;
  animation: glowDriftA 25s ease-in-out infinite alternate;
}

.bg-glow-b {
  width: 500px;
  height: 500px;
  background: rgba(15, 198, 194, 0.03);
  bottom: -10%;
  left: 5%;
  animation: glowDriftB 30s ease-in-out infinite alternate;
}

@keyframes glowDriftA {
  0% { transform: translate(0, 0); }
  100% { transform: translate(20px, -15px); }
}

@keyframes glowDriftB {
  0% { transform: translate(0, 0); }
  100% { transform: translate(-15px, 12px); }
}

.building-grid {
  position: absolute;
  inset: 0;
  opacity: 0.45;
}

.building-svg {
  width: 100%;
  height: 100%;
}

.scan-line {
  position: absolute;
  inset: 0;
  pointer-events: none;
  overflow: hidden;
}

.scan-line::before {
  content: '';
  position: absolute;
  left: 0;
  right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent 0%, rgba(22,93,255,0) 10%, rgba(22,93,255,0.06) 40%, rgba(22,93,255,0.1) 50%, rgba(22,93,255,0.06) 60%, rgba(22,93,255,0) 90%, transparent 100%);
  animation: scanDown 20s linear infinite;
}

@keyframes scanDown {
  0% { top: -2px; opacity: 0; }
  2% { opacity: 1; }
  98% { opacity: 1; }
  100% { top: 100%; opacity: 0; }
}

.bottom-line {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent 5%, rgba(22,93,255,0.15) 30%, rgba(15,198,194,0.1) 70%, transparent 95%);
}

.brand-content {
  position: relative;
  z-index: 1;
  padding: 60px;
  max-width: 540px;
}

.brand-badge {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 3px;
  color: #165DFF;
  background: rgba(22,93,255,0.04);
  border: 1px solid rgba(22,93,255,0.12);
  padding: 7px 18px;
  border-radius: 4px;
  margin-bottom: 28px;
  animation: fadeSlideUp 0.6s ease-out both;
  position: relative;
}

.brand-badge::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(22,93,255,0.25), transparent);
}

.badge-dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: #165DFF;
  box-shadow: 0 0 6px rgba(22,93,255,0.4);
  flex-shrink: 0;
}

.brand-title {
  font-size: 42px;
  font-weight: 700;
  color: #FFFFFF;
  letter-spacing: 8px;
  line-height: 1.2;
  margin: 0 0 10px 0;
  text-shadow: 0 0 60px rgba(22,93,255,0.15);
  animation: fadeSlideUp 0.6s ease-out 0.1s both;
}

.title-underline {
  width: 100%;
  height: 2px;
  background: linear-gradient(90deg, #165DFF, #0FC6C2, transparent);
  border-radius: 1px;
  margin-bottom: 14px;
  animation: underlineGrow 1s ease-out 0.3s both;
}

@keyframes underlineGrow {
  from { width: 0; opacity: 0; }
  to { width: 100%; opacity: 1; }
}

.brand-en {
  font-size: 17px;
  font-weight: 500;
  color: rgba(255,255,255,0.45);
  letter-spacing: 2px;
  margin: 0 0 28px 0;
  animation: fadeSlideUp 0.6s ease-out 0.2s both;
}

.brand-desc {
  font-size: 15px;
  color: rgba(255,255,255,0.35);
  line-height: 1.7;
  margin: 0 0 36px 0;
  animation: fadeSlideUp 0.6s ease-out 0.4s both;
}

.feature-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
}

.feat {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 16px;
  background: rgba(255,255,255,0.02);
  border: 1px solid rgba(255,255,255,0.04);
  border-radius: 8px;
  transition: all 0.4s cubic-bezier(0.4,0,0.2,1);
  animation: fadeSlideUp 0.5s ease-out both;
  cursor: default;
  position: relative;
  overflow: hidden;
}

.feat::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: 8px;
  border: 1px solid transparent;
  background: linear-gradient(135deg, rgba(22,93,255,0.08), rgba(15,198,194,0.04)) border-box;
  -webkit-mask: linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask-composite: exclude;
  opacity: 0;
  transition: opacity 0.4s;
}

.feat:hover {
  background: rgba(22,93,255,0.04);
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(22,93,255,0.06);
}

.feat:hover::before {
  opacity: 1;
}

.feat:hover .feat-icon-wrap {
  transform: scale(1.1);
}

.feat-icon-wrap {
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  border-radius: 6px;
  background: linear-gradient(135deg, rgba(22,93,255,0.1), rgba(15,198,194,0.05));
  transition: all 0.4s cubic-bezier(0.4,0,0.2,1);
}

.feat-svg {
  width: 20px;
  height: 20px;
  color: #165DFF;
}

.feat-text {
  font-size: 14px;
  color: rgba(255,255,255,0.8);
  font-weight: 500;
}

@keyframes fadeSlideUp {
  from { opacity: 0; transform: translateY(16px); }
  to { opacity: 1; transform: translateY(0); }
}

.login-right {
  width: 480px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: #FFFFFF;
  border-left: 1px solid #E5E6EB;
  padding: 40px;
  position: relative;
  animation: rightFadeIn 0.8s ease-out both;
}

@keyframes rightFadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

.theme-toggle {
  position: absolute;
  top: 24px;
  right: 24px;
  width: 36px;
  height: 36px;
  border: 1px solid #E5E6EB;
  border-radius: 8px;
  background: #F7F8FA;
  color: #4E5969;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s;
}

.theme-toggle:hover {
  background: #E8E9EB;
  color: #1D2129;
}

.login-card {
  width: 100%;
  max-width: 420px;
  position: relative;
  border-radius: 14px;
  padding: 1px;
  background: linear-gradient(135deg, rgba(22,93,255,0.15), rgba(15,198,194,0.08), rgba(22,93,255,0.12));
  box-shadow: 0 8px 40px rgba(22,93,255,0.05), 0 2px 12px rgba(0,0,0,0.03);
  animation: cardFadeIn 0.8s ease-out 0.2s both;
}

.card-inner {
  background: rgba(255,255,255,0.95);
  backdrop-filter: blur(20px);
  border-radius: 13px;
  padding: 44px 38px;
}

@keyframes cardFadeIn {
  from { opacity: 0; transform: translateY(16px); }
  to { opacity: 1; transform: translateY(0); }
}

.card-top {
  margin-bottom: 32px;
  text-align: center;
}

.card-top h3 {
  font-size: 26px;
  font-weight: 700;
  color: #165DFF;
  margin: 0 0 6px 0;
  letter-spacing: 3px;
}

.card-top p {
  font-size: 14px;
  color: #86909C;
  margin: 0;
}

.login-form :deep(.el-form-item) {
  margin-bottom: 20px;
}

.input-wrap {
  display: flex;
  align-items: center;
  height: 48px;
  background: #F7F8FA;
  border: 1.5px solid #E5E6EB;
  border-radius: 10px;
  padding: 0 14px;
  transition: all 0.3s cubic-bezier(0.4,0,0.2,1);
  position: relative;
}

.input-wrap.is-focus {
  border-color: #165DFF;
  box-shadow: 0 0 0 3px rgba(22,93,255,0.06);
  background: #FFFFFF;
}

.input-wrap.is-focus .input-icon {
  color: #165DFF;
}

.input-wrap.is-error {
  border-color: #F53F3F;
  box-shadow: 0 0 0 3px rgba(245,63,63,0.05);
}

.input-wrap.is-error .input-icon {
  color: #F53F3F;
}

.input-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  color: #C9CDD4;
  margin-right: 10px;
  flex-shrink: 0;
  transition: color 0.3s;
}

.custom-input {
  flex: 1;
  height: 100%;
  border: none;
  outline: none;
  background: transparent;
  font-size: 14px;
  color: #1D2129;
  font-family: var(--font-sans);
}

.custom-input::placeholder {
  color: #C9CDD4;
}

.pwd-toggle {
  display: flex;
  align-items: center;
  justify-content: center;
  background: none;
  border: none;
  color: #C9CDD4;
  cursor: pointer;
  padding: 4px;
  border-radius: 4px;
  transition: all 0.2s;
  flex-shrink: 0;
}

.pwd-toggle:hover {
  color: #86909C;
  background: rgba(0,0,0,0.04);
}

.field-error {
  display: block;
  font-size: 12px;
  color: #F53F3F;
  margin-top: 4px;
  padding-left: 2px;
}

.error-slide-enter-active { transition: all 0.25s ease-out; }
.error-slide-leave-active { transition: all 0.2s ease-in; }
.error-slide-enter-from { opacity: 0; transform: translateY(-6px); }
.error-slide-leave-to { opacity: 0; transform: translateY(-4px); }

.captcha-row {
  display: flex;
  gap: 12px;
  margin-bottom: 20px;
}

.captcha-input { flex: 1; }

.captcha-img {
  width: 100px;
  height: 42px;
  border-radius: 8px;
  overflow: hidden;
  cursor: pointer;
  border: 1.5px solid #E5E6EB;
  flex-shrink: 0;
  transition: all 0.3s;
}

.captcha-img:hover {
  border-color: #165DFF;
}

.captcha-img canvas {
  display: block;
  width: 100%;
  height: 100%;
}

.form-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.custom-checkbox {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  user-select: none;
}

.checkbox-hidden {
  position: absolute;
  opacity: 0;
  width: 0;
  height: 0;
}

.checkbox-box {
  width: 16px;
  height: 16px;
  border-radius: 4px;
  border: 1.5px solid #C9CDD4;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s cubic-bezier(0.4,0,0.2,1);
  flex-shrink: 0;
}

.checkbox-box svg {
  opacity: 0;
  transform: scale(0.5);
  transition: all 0.2s;
}

.custom-checkbox.is-checked .checkbox-box {
  background: #165DFF;
  border-color: #165DFF;
}

.custom-checkbox.is-checked .checkbox-box svg {
  opacity: 1;
  transform: scale(1);
}

.custom-checkbox:hover .checkbox-box {
  border-color: #165DFF;
}

.checkbox-label {
  font-size: 14px;
  color: #86909C;
}

.forgot-link {
  font-size: 13px;
  color: #165DFF;
  cursor: pointer;
  transition: all 0.2s;
}

.forgot-link:hover {
  text-decoration: underline;
  color: #4080FF;
}

.login-btn {
  width: 100%;
  height: 48px;
  font-size: 16px;
  font-weight: 600;
  letter-spacing: 4px;
  border-radius: 10px;
  background: linear-gradient(135deg, #165DFF, #4080FF);
  border: none;
  color: #FFFFFF;
  cursor: pointer;
  transition: all 0.4s cubic-bezier(0.4,0,0.2,1);
  position: relative;
  overflow: hidden;
}

.login-btn::after {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.08), transparent);
  transition: left 0.6s ease;
}

.login-btn:hover:not(:disabled) {
  box-shadow: 0 8px 28px rgba(22,93,255,0.35);
  transform: translateY(-2px);
}

.login-btn:hover:not(:disabled)::after {
  left: 100%;
}

.login-btn:active:not(:disabled) {
  transform: translateY(0);
  box-shadow: 0 2px 8px rgba(22,93,255,0.2);
}

.login-btn.is-loading {
  opacity: 0.85;
  cursor: not-allowed;
  letter-spacing: 2px;
}

.login-btn.is-success {
  background: linear-gradient(135deg, #00B42A, #23C343);
  letter-spacing: 2px;
  cursor: default;
}

.btn-content {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  position: relative;
  z-index: 1;
}

.btn-spinner {
  width: 16px;
  height: 16px;
  border: 2px solid rgba(255,255,255,0.3);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin { to { transform: rotate(360deg); } }

.security-tip {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 12px;
  padding: 8px 12px;
  border-radius: 6px;
  font-size: 12px;
  line-height: 1.5;
}

.security-tip.warning {
  background: rgba(255,125,0,0.08);
  color: #FF7D00;
  border: 1px solid rgba(255,125,0,0.15);
}

.security-tip.info {
  background: rgba(22,93,255,0.06);
  color: #165DFF;
  border: 1px solid rgba(22,93,255,0.12);
}

.security-tip-enter-active { transition: all 0.3s ease-out; }
.security-tip-leave-active { transition: all 0.2s ease-in; }
.security-tip-enter-from { opacity: 0; transform: translateY(-8px); }
.security-tip-leave-to { opacity: 0; transform: translateY(-4px); }

.card-bottom {
  margin-top: 28px;
  padding-top: 20px;
  border-top: 1px solid #E5E6EB;
}

.demo-line {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  font-size: 12px;
  color: #86909C;
  flex-wrap: wrap;
}

.demo-line code {
  color: #165DFF;
  font-family: 'SF Mono','Fira Code','Consolas',monospace;
  font-size: 12px;
  font-weight: 600;
}

.demo-label { color: #C9CDD4; }
.demo-sep { color: #C9CDD4; }

.fill-btn {
  font-size: 11px;
  color: #165DFF;
  background: rgba(22,93,255,0.06);
  border: 1px solid rgba(22,93,255,0.15);
  border-radius: 4px;
  padding: 2px 8px;
  cursor: pointer;
  transition: all 0.2s;
}

.fill-btn:hover {
  background: rgba(22,93,255,0.12);
  border-color: rgba(22,93,255,0.3);
}

.reg-line {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  font-size: 14px;
  color: #86909C;
  margin-top: 16px;
}

.reg-link {
  color: #165DFF;
  text-decoration: none;
  font-weight: 600;
  transition: all 0.2s;
}

.reg-link:hover {
  text-decoration: underline;
  color: #4080FF;
}

.footer-text {
  position: absolute;
  bottom: 24px;
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 12px;
  color: #C9CDD4;
  letter-spacing: 0.5px;
}

.footer-links {
  display: flex;
  align-items: center;
  gap: 6px;
}

.footer-links a {
  color: #86909C;
  text-decoration: none;
  transition: color 0.2s;
}

.footer-links a:hover {
  color: #165DFF;
  text-decoration: underline;
}

.footer-sep { color: #E5E6EB; }

.login-page:not(.light-mode) .login-right {
  background: #111827;
  border-left-color: rgba(148,163,184,0.06);
}

.login-page:not(.light-mode) .login-card {
  background: linear-gradient(135deg, rgba(22,93,255,0.12), rgba(15,198,194,0.06), rgba(22,93,255,0.1));
  box-shadow: 0 8px 40px rgba(22,93,255,0.06), 0 2px 12px rgba(0,0,0,0.3);
}

.login-page:not(.light-mode) .card-inner {
  background: rgba(17,24,39,0.95);
}

.login-page:not(.light-mode) .card-top h3 { color: #FFFFFF; }
.login-page:not(.light-mode) .card-top p { color: #94a3b8; }

.login-page:not(.light-mode) .input-wrap {
  background: rgba(15,23,42,0.5);
  border-color: rgba(148,163,184,0.08);
}

.login-page:not(.light-mode) .input-wrap.is-focus {
  border-color: #165DFF;
  box-shadow: 0 0 0 3px rgba(22,93,255,0.1);
  background: rgba(15,23,42,0.7);
}

.login-page:not(.light-mode) .input-wrap.is-focus .input-icon { color: #165DFF; }
.login-page:not(.light-mode) .input-wrap.is-error { border-color: #F53F3F; box-shadow: 0 0 0 3px rgba(245,63,63,0.06); }
.login-page:not(.light-mode) .input-wrap.is-error .input-icon { color: #F53F3F; }
.login-page:not(.light-mode) .input-icon { color: #475569; }
.login-page:not(.light-mode) .custom-input { color: #F2F3F5; }
.login-page:not(.light-mode) .custom-input::placeholder { color: #475569; }
.login-page:not(.light-mode) .pwd-toggle { color: #475569; }
.login-page:not(.light-mode) .pwd-toggle:hover { color: #94a3b8; background: rgba(148,163,184,0.06); }
.login-page:not(.light-mode) .checkbox-box { border-color: #475569; }
.login-page:not(.light-mode) .checkbox-label { color: #94a3b8; }
.login-page:not(.light-mode) .forgot-link { color: #4080FF; }
.login-page:not(.light-mode) .card-bottom { border-top-color: rgba(148,163,184,0.06); }
.login-page:not(.light-mode) .demo-line { color: #64748b; }
.login-page:not(.light-mode) .demo-line code { color: #4080FF; }
.login-page:not(.light-mode) .reg-line { color: #64748b; }
.login-page:not(.light-mode) .reg-link { color: #4080FF; }
.login-page:not(.light-mode) .fill-btn { color: #4080FF; background: rgba(22,93,255,0.06); border-color: rgba(22,93,255,0.12); }
.login-page:not(.light-mode) .footer-text { color: #475569; }
.login-page:not(.light-mode) .footer-links a { color: #64748b; }
.login-page:not(.light-mode) .footer-links a:hover { color: #4080FF; }
.login-page:not(.light-mode) .footer-sep { color: rgba(148,163,184,0.1); }
.login-page:not(.light-mode) .theme-toggle { background: rgba(148,163,184,0.06); border-color: rgba(148,163,184,0.08); color: #94a3b8; }
.login-page:not(.light-mode) .theme-toggle:hover { background: rgba(148,163,184,0.12); color: #F2F3F5; }
.login-page:not(.light-mode) .captcha-img { border-color: rgba(148,163,184,0.08); }
.login-page:not(.light-mode) .captcha-img:hover { border-color: #165DFF; }
.login-page:not(.light-mode) .security-tip.warning { background: rgba(255,125,0,0.04); border-color: rgba(255,125,0,0.08); color: #FF7D00; }
.login-page:not(.light-mode) .security-tip.info { background: rgba(22,93,255,0.04); border-color: rgba(22,93,255,0.08); color: #4080FF; }
.login-page:not(.light-mode) .field-error { color: #F53F3F; }

@media (max-width: 1200px) {
  .login-left { display: none; }
  .login-right { width: 100%; border-left: none; }
}

@media (max-width: 768px) {
  .card-inner { padding: 32px 24px; }
  .login-right { padding: 24px; }
  .brand-content { padding: 32px; }
  .brand-title { font-size: 32px; }
  .captcha-row { flex-direction: column; }
  .captcha-img { width: 100%; height: 48px; }
}
</style>
