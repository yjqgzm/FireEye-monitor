<template>
  <div :class="['news-page', { 'light-mode': isLightMode }]">
    <div class="page-hero">
      <div class="hero-pattern"></div>
      <div class="hero-content">
        <h1>消防资讯</h1>
        <p>实时掌握消防动态，学习安全知识，守护安全防线</p>
      </div>
    </div>

    <div class="page-header">
      <div class="header-tabs">
        <button
          v-for="tab in tabs"
          :key="tab.key"
          :class="['tab-btn', { active: activeTab === tab.key }]"
          @click="activeTab = tab.key"
        >
          <span class="tab-icon">{{ tab.icon }}</span>
          {{ tab.label }}
        </button>
      </div>
    </div>

    <Transition name="slide-fade" mode="out-in">
      <div :key="activeTab" class="news-content">
        <template v-if="activeTab === 'policy'">
          <div class="featured-card" @click="openLink(filteredNews[0])" v-if="filteredNews.length > 0">
            <div class="featured-img" :class="'scene-' + filteredNews[0].scene" :style="{ background: filteredNews[0].coverBg }">
              <div class="scene-pattern"></div>
              <div class="scene-decor">
                <div class="decor-circle decor-c1"></div>
                <div class="decor-circle decor-c2"></div>
                <div class="decor-line decor-l1"></div>
                <div class="decor-line decor-l2"></div>
              </div>
              <span class="cover-icon-lg">{{ filteredNews[0].coverIcon }}</span>
              <div class="scene-label">{{ filteredNews[0].sceneLabel }}</div>
            </div>
            <div class="featured-content">
              <div class="featured-badge">政策要闻</div>
              <h2 class="featured-title">{{ filteredNews[0].title }}</h2>
              <p class="featured-desc">{{ filteredNews[0].summary }}</p>
              <div class="featured-meta">
                <span class="meta-source">{{ filteredNews[0].source }}</span>
                <span class="meta-date">{{ filteredNews[0].date }}</span>
              </div>
            </div>
          </div>
          <div class="news-grid">
            <div
              v-for="(item, index) in filteredNews.slice(1)"
              :key="index"
              class="news-card"
              @click="openLink(item)"
            >
              <div class="news-card-cover" :class="'scene-' + item.scene" :style="{ background: item.coverBg }">
                <div class="scene-pattern"></div>
                <div class="scene-decor-sm">
                  <div class="decor-circle decor-c1"></div>
                  <div class="decor-circle decor-c2"></div>
                </div>
                <span class="cover-icon-md">{{ item.coverIcon }}</span>
                <div class="scene-label-sm">{{ item.sceneLabel }}</div>
              </div>
              <div class="news-card-body">
                <div class="card-top">
                  <div class="card-tag" :class="item.tagType">{{ item.tag }}</div>
                  <span class="card-date">{{ item.date }}</span>
                </div>
                <h3 class="news-title">{{ item.title }}</h3>
                <p class="news-summary">{{ item.summary }}</p>
                <div class="card-bottom">
                  <span class="news-source">{{ item.source }}</span>
                  <span class="card-link">查看详情 →</span>
                </div>
              </div>
            </div>
          </div>
        </template>

        <template v-if="activeTab === 'incident'">
          <div class="incident-list">
            <div
              v-for="(item, index) in filteredNews"
              :key="index"
              :class="['incident-card', { 'incident-major': item.tagType === 'tag-major' }]"
              @click="openLink(item)"
            >
              <div class="incident-img" :class="'scene-' + item.scene" :style="{ background: item.coverBg }">
                <div class="scene-pattern"></div>
                <span class="cover-icon-sm">{{ item.coverIcon }}</span>
              </div>
              <div class="incident-left">
                <div class="incident-indicator" :class="item.tagType"></div>
                <div class="incident-timeline" v-if="index < filteredNews.length - 1"></div>
              </div>
              <div class="incident-body">
                <div class="incident-header">
                  <div class="card-tag" :class="item.tagType">{{ item.tag }}</div>
                  <span class="incident-date">{{ item.date }}</span>
                </div>
                <h3 class="incident-title">{{ item.title }}</h3>
                <p class="incident-summary">{{ item.summary }}</p>
                <div class="incident-footer">
                  <span class="news-source">{{ item.source }}</span>
                  <span class="card-link">查看详情 →</span>
                </div>
              </div>
            </div>
          </div>
        </template>

        <template v-if="activeTab === 'data'">
          <div class="data-section">
            <div class="data-hero">
              <div class="data-hero-pattern"></div>
              <div class="data-hero-content">
                <h3>2025年全国火灾数据概览</h3>
                <p>数据来源：国家消防救援局 2026年3月新闻发布会</p>
              </div>
            </div>
            <div class="stats-grid">
              <div class="stat-block">
                <div class="stat-icon-wrap fire-icon">🔥</div>
                <div class="stat-info">
                  <div class="stat-number">84.1<span class="unit">万起</span></div>
                  <div class="stat-desc">2025年全国火灾起数</div>
                  <div class="stat-trend down">↓ 7.6%</div>
                </div>
              </div>
              <div class="stat-block">
                <div class="stat-icon-wrap death-icon">💀</div>
                <div class="stat-info">
                  <div class="stat-number">1,827<span class="unit">人</span></div>
                  <div class="stat-desc">2025年火灾亡人数</div>
                  <div class="stat-trend down">↓ 9.5%</div>
                </div>
              </div>
              <div class="stat-block">
                <div class="stat-icon-wrap loss-icon">💰</div>
                <div class="stat-info">
                  <div class="stat-number">85.3<span class="unit">亿元</span></div>
                  <div class="stat-desc">2025年直接财产损失</div>
                  <div class="stat-trend up">↑ 1.8%</div>
                </div>
              </div>
              <div class="stat-block">
                <div class="stat-icon-wrap injury-icon">🏥</div>
                <div class="stat-info">
                  <div class="stat-number">2,161<span class="unit">人</span></div>
                  <div class="stat-desc">2025年火灾伤人数</div>
                  <div class="stat-trend down">↓ 19.6%</div>
                </div>
              </div>
            </div>
            <div class="data-insight">
              <h4>关键洞察</h4>
              <div class="insight-grid">
                <div class="insight-item">
                  <div class="insight-num">44%</div>
                  <div class="insight-label">居住场所火灾因电气故障引发</div>
                </div>
                <div class="insight-item">
                  <div class="insight-num">65.1%</div>
                  <div class="insight-label">火灾死亡因窒息中毒所致</div>
                </div>
                <div class="insight-item">
                  <div class="insight-num">78.4%</div>
                  <div class="insight-label">建构筑物火灾发生在居住场所</div>
                </div>
                <div class="insight-item">
                  <div class="insight-num">32.5%</div>
                  <div class="insight-label">居住场所火灾发生在厨房</div>
                </div>
              </div>
            </div>
            <div class="data-note">
              <el-icon><InfoFilled /></el-icon>
              <span>数据来源：国家消防救援局 2026年3月17日例行新闻发布会</span>
            </div>
          </div>
        </template>

        <template v-if="activeTab === 'knowledge'">
          <div class="knowledge-grid">
            <div
              v-for="(item, index) in filteredNews"
              :key="index"
              class="knowledge-card"
              @click="openLink(item)"
            >
              <div class="knowledge-cover" :class="'scene-' + item.scene" :style="{ background: item.coverBg }">
                <div class="scene-pattern"></div>
                <div class="scene-decor-sm">
                  <div class="decor-circle decor-c1"></div>
                  <div class="decor-circle decor-c2"></div>
                </div>
                <div class="knowledge-icon-float">{{ item.icon }}</div>
                <div class="scene-label-sm">{{ item.sceneLabel }}</div>
              </div>
              <div class="knowledge-body">
                <div class="card-tag" :class="item.tagType">{{ item.tag }}</div>
                <h3 class="knowledge-title">{{ item.title }}</h3>
                <p class="knowledge-summary">{{ item.summary }}</p>
                <div class="knowledge-footer">
                  <span class="news-source">{{ item.source }}</span>
                  <span class="card-link">了解更多 →</span>
                </div>
              </div>
            </div>
          </div>
        </template>

        <template v-if="activeTab === 'guide'">
          <div class="knowledge-grid">
            <div
              v-for="(item, index) in filteredNews"
              :key="index"
              class="knowledge-card"
              @click="openLink(item)"
            >
              <div class="knowledge-cover" :style="{ background: item.coverBg }">
                <div class="scene-pattern"></div>
                <div class="knowledge-icon-float">{{ item.icon }}</div>
                <div class="scene-label-sm">{{ item.sceneLabel }}</div>
              </div>
              <div class="knowledge-body">
                <div class="card-tag" :class="item.tagType">{{ item.tag }}</div>
                <h3 class="knowledge-title">{{ item.title }}</h3>
                <p class="knowledge-summary">{{ item.summary }}</p>
                <div class="knowledge-footer">
                  <span class="news-source">{{ item.source }}</span>
                  <span class="card-link">查看教程 →</span>
                </div>
              </div>
            </div>
          </div>
        </template>

        <template v-if="activeTab === 'emergency'">
          <div class="knowledge-grid">
            <div
              v-for="(item, index) in filteredNews"
              :key="index"
              class="knowledge-card"
              @click="openLink(item)"
            >
              <div class="knowledge-cover" :style="{ background: item.coverBg }">
                <div class="scene-pattern"></div>
                <div class="knowledge-icon-float">{{ item.icon }}</div>
                <div class="scene-label-sm">{{ item.sceneLabel }}</div>
              </div>
              <div class="knowledge-body">
                <div class="card-tag" :class="item.tagType">{{ item.tag }}</div>
                <h3 class="knowledge-title">{{ item.title }}</h3>
                <p class="knowledge-summary">{{ item.summary }}</p>
                <div class="knowledge-footer">
                  <span class="news-source">{{ item.source }}</span>
                  <span class="card-link">查看教程 →</span>
                </div>
              </div>
            </div>
          </div>
        </template>

        <template v-if="activeTab === 'review'">
          <div class="incident-list">
            <div
              v-for="(item, index) in filteredNews"
              :key="index"
              :class="['incident-card', { 'incident-major': item.tagType === 'tag-major' }]"
              @click="openLink(item)"
            >
              <div class="incident-img" :style="{ background: item.coverBg }">
                <div class="scene-pattern"></div>
                <span class="cover-icon-sm">{{ item.icon }}</span>
              </div>
              <div class="incident-left">
                <div class="incident-indicator" :class="item.tagType"></div>
                <div class="incident-timeline" v-if="index < filteredNews.length - 1"></div>
              </div>
              <div class="incident-body">
                <div class="incident-header">
                  <div class="card-tag" :class="item.tagType">{{ item.tag }}</div>
                  <span class="incident-date">{{ item.date }}</span>
                </div>
                <h3 class="incident-title">{{ item.title }}</h3>
                <p class="incident-summary">{{ item.summary }}</p>
                <div class="incident-footer">
                  <span class="news-source">{{ item.source }}</span>
                  <span class="card-link">查看复盘 →</span>
                </div>
              </div>
            </div>
          </div>
        </template>

        <el-empty v-if="filteredNews.length === 0 && activeTab !== 'data'" description="暂无资讯" :image-size="80" />
      </div>
    </Transition>

    <Teleport to="body">
      <div v-if="showDetail" class="detail-overlay" @click.self="closeDetail">
        <div class="detail-modal">
          <div class="detail-modal-header">
            <h3 class="detail-modal-title">{{ currentDetail?.title }}</h3>
            <button class="detail-modal-close" @click="closeDetail">✕</button>
          </div>
          <div class="detail-modal-body">
            <div v-if="currentDetail?.detailContent" class="detail-body">
              <div class="detail-meta">
                <span class="detail-tag" :class="currentDetail.tagType">{{ currentDetail.tag }}</span>
                <span class="detail-source">{{ currentDetail.source }}</span>
                <span class="detail-date">{{ currentDetail.date }}</span>
              </div>

              <div v-for="(section, idx) in currentDetail.detailContent.sections" :key="idx" class="detail-section">
                <h4 class="section-title">{{ section.title }}</h4>
                <p class="section-content" style="white-space:pre-line;">{{ section.content }}</p>
              </div>

              <div v-if="currentDetail.detailContent.tips" class="detail-tips">
                <div class="tips-header">💡 要点提示</div>
                <ul class="tips-list">
                  <li v-for="(tip, i) in currentDetail.detailContent.tips" :key="i">{{ tip }}</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup>
import { ref, computed, inject, onBeforeUnmount } from 'vue'
import { ElMessage } from 'element-plus'

const isLightMode = inject('isLightMode', ref(false))
const activeTab = ref('policy')
const showDetail = ref(false)
const currentDetail = ref(null)

const tabs = [
  { key: 'policy', label: '国家政策', icon: '📋' },
  { key: 'incident', label: '火灾案例', icon: '🔥' },
  { key: 'data', label: '消防数据', icon: '📊' },
  { key: 'knowledge', label: '消防知识', icon: '📖' },
  { key: 'guide', label: '系统操作指南', icon: '🖥️' },
  { key: 'emergency', label: '应急处置教程', icon: '🚨' },
  { key: 'review', label: '火灾案例复盘', icon: '🔍' }
]

const newsData = ref([
  {
    type: 'policy',
    title: '国务院安委会发布《小型餐饮场所防火技术要点》',
    summary: '为吸取辽宁辽阳"4·29"重大火灾教训，国务院安委会专门制定小型餐饮场所防火技术要点，鼓励设置2个安全出口，强化消防安全管理，严防小场所大灾难。',
    source: '中国政府网',
    date: '2025-06',
    tag: '新规',
    tagType: 'tag-new',
    scene: 'gov',
    sceneLabel: '国务院',
    coverBg: "url('/images/policy-gov.svg') center/cover no-repeat",
    coverIcon: '🏛️',
    url: 'https://www.gov.cn/'
  },
  {
    type: 'policy',
    title: '国家消防救援局推进智慧消防建设指导意见',
    summary: '应急管理部发布推进智慧消防建设指导意见，鼓励采用物联网、AI、红外测温等新技术提升火灾预警能力，推动消防工作智能化升级。',
    source: '应急管理部',
    date: '2025-03',
    tag: '政策',
    tagType: 'tag-policy',
    scene: 'iot',
    sceneLabel: '智慧消防',
    coverBg: "url('/images/policy-iot.svg') center/cover no-repeat",
    coverIcon: '📡',
    url: 'https://www.mem.gov.cn/'
  },
  {
    type: 'policy',
    title: '《中华人民共和国消防法》最新修订版实施',
    summary: '全国人大常委会通过最新修订的消防法，强化单位消防安全主体责任，新增智慧消防相关条款，推动消防工作数字化转型。',
    source: '全国人大网',
    date: '2025-01',
    tag: '法律',
    tagType: 'tag-law',
    scene: 'law',
    sceneLabel: '消防法',
    coverBg: "url('/images/policy-law.svg') center/cover no-repeat",
    coverIcon: '⚖️',
    url: 'https://www.npc.gov.cn/'
  },
  {
    type: 'policy',
    title: '《建筑消防设施检测技术规程》新标准实施',
    summary: '住建部发布新版建筑消防设施检测技术规程，对红外测温等早期预警技术提出明确检测要求和标准规范。',
    source: '住建部',
    date: '2024-10',
    tag: '标准',
    tagType: 'tag-standard',
    scene: 'building',
    sceneLabel: '建筑消防',
    coverBg: "url('/images/policy-building.svg') center/cover no-repeat",
    coverIcon: '🏗️',
    url: 'https://www.mohurd.gov.cn/'
  },
  {
    type: 'incident',
    title: '辽宁辽阳"4·29"小餐馆重大火灾 — 22人死亡',
    summary: '2025年4月29日，辽阳市白塔区三里厨娘饭店发生重大火灾。顾客丢弃未熄灭烟头被大风吹入杂物间引发火灾，外墙违规使用易燃铝塑板加速蔓延，安全出口不足、消防设施长期瘫痪，造成22人死亡、3人受伤。',
    source: '新华网',
    date: '2025-04-29',
    tag: '重大火灾',
    tagType: 'tag-major',
    scene: 'fire',
    sceneLabel: '餐馆火灾',
    coverBg: "url('/images/incident-fire.svg') center/cover no-repeat",
    coverIcon: '🔥',
    url: 'https://www.news.cn/'
  },
  {
    type: 'incident',
    title: '河北承德"4·8"养老院重大火灾 — 20名老人遇难',
    summary: '2025年4月8日，承德市隆化县国恩老年公寓发生重大火灾。不合格移动插排电线短路引发，养老院违规扩建、违规关闭消防喷淋系统，消防控制室无人值守，造成20名失能老人遇难。',
    source: '央视新闻',
    date: '2025-04-08',
    tag: '重大火灾',
    tagType: 'tag-major',
    scene: 'fire',
    sceneLabel: '养老院火灾',
    coverBg: "url('/images/incident-nursing.svg') center/cover no-repeat",
    coverIcon: '⚠️',
    url: 'https://news.cctv.com/'
  },
  {
    type: 'incident',
    title: '广东汕头"12·9"自建房火灾 — 一家12口遇难',
    summary: '2025年12月9日，广东汕头一经营性自建房因店主使用蚊香不慎引发火灾。一层五金店违规存放大量易燃易爆物品，楼梯如"烟囱"，造成一家12口罹难。',
    source: '澎湃新闻',
    date: '2025-12-09',
    tag: '重大火灾',
    tagType: 'tag-major',
    scene: 'fire',
    sceneLabel: '自建房火灾',
    coverBg: "url('/images/incident-house.svg') center/cover no-repeat",
    coverIcon: '🏚️',
    url: 'https://www.thepaper.cn/'
  },
  {
    type: 'incident',
    title: '昆明"4·12"商铺较大火灾 — 8人死亡',
    summary: '2025年4月12日，昆明市呈贡区一商铺因电动自行车入户充电引发火灾，蓄电池短路起火。涉事商铺违规住人、违规改装超标电动车，造成8人死亡。',
    source: '云南网',
    date: '2025-04-12',
    tag: '较大火灾',
    tagType: 'tag-fire',
    scene: 'ebike',
    sceneLabel: '电动车火灾',
    coverBg: "url('/images/incident-ebike.svg') center/cover no-repeat",
    coverIcon: '🛵',
    url: 'https://www.yunnan.cn/'
  },
  {
    type: 'knowledge',
    title: '红外测温技术在电气火灾预警中的应用',
    summary: '电气火灾占火灾总数44%以上，红外测温技术可在温度异常初期提前发现隐患，实现事前预警，有效降低电气火灾发生率。',
    source: '消防科学与技术',
    date: '2025-06',
    tag: '技术',
    tagType: 'tag-tech',
    scene: 'thermal',
    sceneLabel: '红外测温',
    icon: '🌡️',
    coverBg: "url('/images/knowledge-thermal.svg') center/cover no-repeat",
    url: 'https://www.fire-safety.cn/'
  },
  {
    type: 'knowledge',
    title: '冬季防火安全知识：家庭用电安全指南',
    summary: '冬季是电气火灾高发期，大功率电器集中使用易导致线路过载。了解安全用电常识，定期检查线路，安装漏电保护装置是预防关键。',
    source: '中国消防在线',
    date: '2025-12',
    tag: '科普',
    tagType: 'tag-science',
    scene: 'electric',
    sceneLabel: '用电安全',
    icon: '⚡',
    coverBg: "url('/images/knowledge-electric.svg') center/cover no-repeat",
    url: 'https://www.119.gov.cn/'
  },
  {
    type: 'knowledge',
    title: '高层建筑火灾逃生自救指南',
    summary: '高层建筑火灾蔓延快、疏散难，掌握正确的逃生方法至关重要。切勿乘坐电梯，低姿捂鼻沿墙撤离，遇浓烟应退守待援。',
    source: '应急管理部',
    date: '2025-09',
    tag: '科普',
    tagType: 'tag-science',
    scene: 'highrise',
    sceneLabel: '高层逃生',
    icon: '🏢',
    coverBg: "url('/images/knowledge-highrise.svg') center/cover no-repeat",
    url: 'https://www.mem.gov.cn/'
  },
  {
    type: 'knowledge',
    title: '电动自行车消防安全管理新规解读',
    summary: '针对电动自行车火灾频发问题，多地出台新规严禁电动车进楼入户充电。了解最新法规要求和安全充电知识，避免悲剧发生。',
    source: '中国消防在线',
    date: '2025-05',
    tag: '法规',
    tagType: 'tag-law',
    scene: 'ebike',
    sceneLabel: '电动车消防',
    icon: '🛵',
    coverBg: "url('/images/knowledge-ebike.svg') center/cover no-repeat",
    url: 'https://www.119.gov.cn/'
  },
  {
    type: 'guide',
    title: '测温设备添加与接入分步教程',
    summary: '详细说明如何将WiFi红外测温传感器接入火睛智控中心，从设备注册、网络配置、点位绑定到数据上报验证的全流程操作指引，含分步截图说明。',
    source: '系统文档',
    date: '2026-04',
    tag: '教程',
    tagType: 'tag-guide',
    icon: '📡',
    sceneLabel: '设备接入',
    coverBg: '#0f1923 linear-gradient(135deg, #0f2847 0%, #0a1628 50%, #163a6a 100%)',
    url: '#',
    detailContent: {
      sections: [
        { title: '一、设备硬件准备', content: '确保您的WiFi红外测温传感器已正确供电并处于配网状态。推荐使用支持2.4GHz WiFi频段的传感器设备，确认设备固件版本兼容HTTP/HTTPS数据上报协议。首次使用前请检查设备的MAC地址或序列号，用于后续在系统中唯一标识该设备。' },
        { title: '二、登录系统进入设备管理', content: '使用管理员账号登录火睛智控中心，点击左侧导航栏「设备管理」菜单，进入设备管理页面。页面顶部显示当前所有已接入的设备列表，点击右上角「+ 添加设备」按钮开始新设备接入流程。' },
        { title: '三、填写设备基本信息', content: '在弹出的添加设备表单中，依次填写：\n• 设备名称：如「实验室A区-01号测温点」，建议包含位置信息便于识别\n• 设备编号：输入传感器的唯一标识码（SN/MAC地址）\n• 安装位置：详细描述设备安装的具体位置，如「三楼实验室东南角配电柜上方」\n• 场景类型：从下拉菜单选择（实验室/仓库/宿舍/配电房/厨房/商铺等），不同场景自动匹配不同的预警阈值\n• 预警阈值：可自定义，也可使用场景默认值' },
        { title: '四、配置网络连接参数', content: '设备添加后需要配置网络上报参数：\n• 上报地址：填写火睛智控中心的API接口地址\n• 上报间隔：建议60秒一次（可根据需要调整30-300秒）\n• 数据格式：JSON格式，包含temperature（物体温度）、ambient_temp（环境温度）、humidity（湿度）等字段\n• 认证Token：每个设备会生成唯一的认证令牌，用于安全验证' },
        { title: '五、点位绑定与区域关联', content: '设备信息保存后，系统会自动分配一个内部设备ID。您可以在3D数字孪生模块中查看该设备对应的监测点位。如果需要将设备与特定建筑楼层/房间绑定，可在设备详情页中设置「关联空间」参数。' },
        { title: '六、验证数据上报', content: '完成上述步骤后，设备应开始向系统上报温度数据。您可以：\n1. 在实时监控大屏（Dashboard）查看该设备的实时温度数值是否正常显示\n2. 在历史数据页筛选该设备，确认温度曲线图有数据记录\n3. 查看设备卡片上的「最后上报时间」是否持续更新\n4. 如果数据未正常上报，请检查网络连接和设备日志' }
      ],
      tips: ['建议先在测试环境完成设备接入验证后再部署到生产环境', '同一区域内多个设备建议按顺序编号命名，便于批量管理', '设备离线超过10分钟系统会自动标记为异常状态并发送通知']
    }
  },
  {
    type: 'guide',
    title: '预警阈值配置操作指南',
    summary: '介绍如何根据不同监测场景（实验室、宿舍、仓库、配电房等）配置合理的温度预警阈值，包括一级提示45°C、二级警告60°C、三级紧急80°C的分级设置方法。',
    source: '系统文档',
    date: '2026-04',
    tag: '配置',
    tagType: 'tag-guide',
    icon: '⚙️',
    sceneLabel: '阈值配置',
    coverBg: "url('/images/guide-system.svg') center/cover no-repeat",
    url: '#',
    detailContent: {
      sections: [
        { title: '一、预警阈值体系概述', content: '火睛智控中心采用三级预警阈值体系，对应不同的风险等级和响应要求。合理配置预警阈值是系统有效运行的核心前提，阈值设置过高会漏报风险，过低则会产生大量误报干扰正常工作。' },
        { title: '二、一级提示预警（≥45°C）', content: '当监测点温度达到或超过45°C时，系统触发蓝色「提示」级预警。\n• 适用场景：温度偏高但尚未达到危险水平\n• 典型原因：设备正常运行升温、环境温度较高、阳光直射等\n• 建议操作：关注温度变化趋势，记录数据，无需立即处置\n• 默认通知方式：系统内消息提醒，不推送外部通知' },
        { title: '三、二级警告预警（≥60°C）', content: '当监测点温度达到或超过60°C时，系统触发橙色「警告」级预警。\n• 适用场景：温度明显异常，存在潜在火灾风险\n• 典型原因：电气线路过载、设备故障发热、可燃物靠近热源\n• 建议操作：派人现场核实情况，准备应急物资，排查异常原因\n• 默认通知方式：系统内消息 + 站内弹窗提示' },
        { title: '四、三级紧急预警（≥80°C）', content: '当监测点温度达到或超过80°C时，系统触发红色「紧急」级预警。\n• 适用场景：温度已接近或达到引燃临界值，火灾风险极高\n• 典型原因：电气短路前兆、明火初期、严重过热\n• 建议操作：立即启动应急预案，组织人员疏散，拨打119报警\n• 默认通知方式：全部通知渠道（站内+声音+外部推送），页面边缘红色警示' },
        { title: '五、按场景类型自定义阈值', content: '不同场景的合理阈值有所不同：\n• 实验室/机房：默认45/60/80°C（电子设备散热正常范围较高）\n• 仓库/库房：建议降低至40/55/70°C（可燃物多，需更敏感）\n• 配电房/电井：建议降低至40/55/75°C（电气火灾高发区域）\n• 厨房/餐饮：建议提高至50/65/85°C（烹饪过程正常高温）\n• 宿舍/办公区：默认45/60/80°C即可\n管理员可在设备管理页单独调整每个设备的阈值参数。' }
      ],
      tips: ['温升速率预警独立于绝对温度阈值，即使温度未达阈值但上升过快也会触发报警', '烟雾传感器报警不受温度阈值影响，检测到烟雾即触发最高级别预警', '建议根据实际使用情况在运行1-2周后微调阈值参数']
    }
  },
  {
    type: 'guide',
    title: '3D数字孪生功能使用手册',
    summary: '全面介绍3D数字孪生模块的操作方法，包括场景浏览、镜头预设切换、图层开关、传感器点位查看、消防设施档案、火灾蔓延模拟、历史回溯回放等功能。',
    source: '系统文档',
    date: '2026-04',
    tag: '手册',
    tagType: 'tag-guide',
    icon: '🏗️',
    sceneLabel: '3D孪生',
    coverBg: "url('/images/guide-emergency.svg') center/cover no-repeat",
    url: '#',
    detailContent: {
      sections: [
        { title: '一、模块入口与基础操作', content: '点击左侧导航栏「3D孪生」菜单进入数字孪生监控模块。进入后您将看到一个三维建筑场景，包含监测点位（彩色球体）、消防设施标识和疏散路线。基础操作：鼠标左键拖拽旋转视角，滚轮缩放，右键平移。' },
        { title: '二、镜头预设快速切换', content: '工具栏提供5种预设镜头视角：\n• 总览：俯瞰整个建筑全貌，适合全局监控\n• 正面：正面平视建筑，查看正门和主要入口\n• 俯视：从正上方垂直向下，便于观察平面布局\n• 风险聚焦：自动定位到当前有预警的设备点位\n• 第一人称：以第一人称视角在场景中漫游巡检\n点击对应按钮即可一键切换镜头。' },
        { title: '三、图层开关控制', content: '通过图层开关可以控制场景中不同元素的显示/隐藏：\n• 传感器层：显示/隐藏所有测温传感器点位\n• 消防设施层：显示/隐藏灭火器、消火栓等设施标记\n• 疏散通道层：显示/隐藏安全出口和疏散路线\n• 标识层：显示/隐藏文字标签\n可根据需要组合显示，例如只看传感器点位时关闭其他图层减少视觉干扰。' },
        { title: '四、设备点位交互', content: '直接点击场景中的传感器球体可查看该设备的详细信息：实时温度、环境温度、湿度、在线状态、最后上报时间等。预警状态的点位会显示红色脉冲环效果，紧急预警时点位会高亮发光。点击后可在右侧面板查看完整数据。' },
        { title: '五、火灾蔓延模拟', content: '点击工具栏「火灾蔓延模拟」按钮启动模拟功能。系统将在指定位置生成火焰粒子和烟雾粒子，模拟火势沿建筑空间的蔓延过程。可通过滑块调节模拟速度。此功能用于应急演练培训和预案验证。' },
        { title: '六、历史数据回溯', content: '点击「历史回溯」按钮加载历史预警记录。播放器会按时间顺序重现历史预警事件的发生过程，3D场景中的点位会同步显示当时的温度状态。可用于事后复盘分析和培训教学。' }
      ],
      tips: ['首次加载3D场景可能需要几秒钟，请耐心等待', '建议使用Chrome或Edge浏览器以获得最佳WebGL性能', '夜间模式可在工具栏切换，适合暗光环境下长时间监控']
    }
  },
  {
    type: 'guide',
    title: '历史数据导出与查看教程',
    summary: '说明如何在历史数据页面按设备、时间段筛选查看温度趋势与环境变化记录，以及如何导出CSV/Excel格式的数据报告用于分析和存档。',
    source: '系统文档',
    date: '2026-04',
    tag: '教程',
    tagType: 'tag-guide',
    icon: '📊',
    sceneLabel: '数据导出',
    coverBg: "url('/images/guide-system.svg') center/cover no-repeat",
    url: '#',
    detailContent: {
      sections: [
        { title: '一、进入历史数据页面', content: '点击左侧导航栏「历史数据」菜单，进入历史数据查询页面。页面顶部为筛选操作栏，中间为核心统计指标卡片，下方为温度趋势图和环境趋势图，底部为历史记录数据表格。' },
        { title: '二、设备筛选与时间范围选择', content: '在筛选区可以：\n• 设备选择器：下拉选择单个设备或多个设备进行对比分析\n• 时间范围：自定义起止日期时间\n• 快捷选项：一键选择今天/昨天/近7天/近30天等常用时间段\n• 点击「查询」按钮加载对应时段的数据' },
        { title: '三、核心统计指标解读', content: '筛选后页面顶部显示7项核心统计：\n• 最高/最低物体温度：所选时段内的极值\n• 平均温度：所有采样点的算术平均值\n• 最高烟雾浓度：烟雾传感器峰值\n• 温度超标次数：超过一级预警阈值的次数\n• 烟雾超标次数：烟雾浓度超阈值次数\n• 预警触发次数：系统实际发出预警的次数\n异常指标会自动标红高亮。' },
        { title: '四、图表数据分析', content: '两张核心图表提供可视化分析：\n• 温度趋势图（上）：双Y轴展示物体温度曲线和烟雾浓度柱状图，包含预警黄线(45°C)和报警红线(60°C)，超标区域红色渐变填充\n• 环境趋势图（下）：环境温度和环境湿度的变化曲线\n支持鼠标悬停查看详细数值、框选缩放、拖拽平移、双击复位。' },
        { title: '五、数据导出操作', content: '点击筛选区的「导出数据」下拉按钮：\n• CSV格式：通用表格格式，可用Excel/WPS打开\n• Excel格式：.xlsx格式，带格式化的表格样式\n导出的数据包含每条记录的时间戳、设备名称、物体温度、环境温度、湿度、烟雾浓度等完整字段。' }
      ],
      tips: ['数据量较大时建议缩小时间范围以提高查询速度', '导出的Excel文件可直接用于月度安全报告或审计存档', '图表中红色标记点表示该时刻触发了预警事件']
    }
  },
  {
    type: 'guide',
    title: '预警事件处置闭环操作流程',
    summary: '详细说明预警触发后的标准处置流程：预警确认→现场核实→应急处置→结果记录→闭环确认，以及如何在系统中完成预警状态变更和处置备注填写。',
    source: '系统文档',
    date: '2026-04',
    tag: '流程',
    tagType: 'tag-guide',
    icon: '✅',
    sceneLabel: '处置闭环',
    coverBg: '#0f1923 linear-gradient(135deg, #3a2a10 0%, #1a1208 50%, #5a3a0a 100%)',
    url: '#',
    detailContent: {
      sections: [
        { title: '一、预警处置五步法总览', content: '火睛智控中心的预警处置采用标准化的「确认→核实→处置→记录→闭环」五步流程，确保每条预警信息得到及时有效的处理，形成完整的处置记录链，满足消防安全管理的可追溯要求。' },
        { title: '第一步：预警确认', content: '当系统触发预警时，值班人员首先在实时监控大屏或预警记录页看到预警信息。点击预警卡片查看详情，确认预警的设备名称、位置、当前温度、温升速率等关键数据。判断是否为真实异常还是误报（如设备重启、环境温度波动等）。' },
        { title: '第二步：现场核实', content: '对于二级及以上预警，必须安排人员到现场进行实地核查。携带便携式测温仪对比验证系统读数，检查设备运行状态、周边环境是否有明火/烟雾/异味等异常迹象。将核实结果记录在案。' },
        { title: '第三步：分级应急处置', content: '根据核实结果和预警等级采取对应措施：\n• 一级提示：记录观察，持续监测\n• 二级警告：排查原因，消除隐患，必要时断电检修\n• 三级紧急：立即启动疏散预案，切断相关电源，使用灭火器材初期扑救，同时拨打119\n所有操作需在系统中通过「一键处置」按钮记录。' },
        { title: '第四步：结果记录', content: '在预警详情弹窗中填写处置结果：选择处置状态（已处理/转交/误报）、填写处置说明（采取了什么措施、现场情况如何）、上传现场照片（可选）。这些记录将永久保存在系统中，支持后续审计查询。' },
        { title: '第五步：闭环确认', content: '处置完成后，管理员应在预警记录页面确认该条预警的状态变更为「已处理」。系统会自动更新统计数据（待处理数-1，已处理数+1），并计算处置及时率。未在30分钟内处理的紧急预警会被标记为超时。' }
      ],
      tips: ['所有处置操作都会记录操作人ID和时间戳，确保责任可追溯', '建议制定值班表明确每班次的预警处置责任人', '定期导出处置记录用于安全例会复盘分析']
    }
  },
  {
    type: 'guide',
    title: '用户权限与角色分配指南',
    summary: '介绍系统的三级权限体系：管理员（全功能+系统管理）、普通会员（日常功能+设备只读）、基础用户（受限功能），以及邀请码激活和角色分配操作。',
    source: '系统文档',
    date: '2026-04',
    tag: '权限',
    tagType: 'tag-guide',
    icon: '👤',
    sceneLabel: '权限管理',
    coverBg: '#0f1923 linear-gradient(135deg, #1a2744 0%, #0c1426 50%, #1e3a5f 100%)',
    url: '#',
    detailContent: {
      sections: [
        { title: '一、三级权限体系概述', content: '火睛智控中心采用三级用户权限模型，不同角色拥有不同的功能访问范围：\n• 管理员(admin)：全部功能权限 + 系统管理（设备增删改、阈值配置、邀请码生成、数据镜像）\n• 普通会员(member)：日常使用权限 + 设备只读（查看数据、查看预警、导出报告，但不能修改配置）\n• 基础用户(user)：受限权限（仅可浏览消防资讯，核心功能锁定）' },
        { title: '二、管理员权限详解', content: '管理员拥有系统的最高操作权限，具体包括：\n• 设备管理：添加、编辑、删除、批量操作所有设备\n• 阈值配置：修改任意设备的温度预警阈值\n• 用户管理：查看所有用户、生成邀请码、调整用户角色\n• 系统设置：修改密码策略、数据镜像备份恢复\n• 全部页面访问：Dashboard、设备、历史、预警、资讯、3D孪生等全部模块\n建议仅1-2名核心管理人员持有管理员账号。' },
        { title: '三、普通会员权限说明', content: '普通会员通过邀请码激活后获得，适合一线值班人员和部门负责人：\n• 可查看实时监控大屏的所有数据和图表\n• 可查看历史数据和导出报告\n• 可查看和处置预警事件（填写处置结果）\n• 不能添加/删除/修改设备和阈值\n• 不能访问系统设置和数据镜像功能\n此角色设计用于防止非授权人员误操作关键配置。' },
        { title: '四、邀请码激活流程', content: '管理员在「个人中心→账号信息」页面可以生成邀请码。将邀请码发送给需要升级的用户，用户在登录后进入个人中心，输入邀请码即可激活为普通会员。每个邀请码只能使用一次，管理员可在邀请码列表中查看使用状态。' },
        { title: '五、角色变更与权限回收', content: '如需调整某用户的角色，管理员可以在后台直接修改其role字段。对于离职人员或不再需要系统访问的用户，建议及时禁用或删除账号，防止未授权访问。系统会记录所有角色变更操作到审计日志。' }
      ],
      tips: ['管理员账号建议启用双因素认证提高安全性', '定期审查普通会员列表，清理不再需要的账号', '重要操作（如删除设备）建议二次确认机制']
    }
  },
  {
    type: 'guide',
    title: '系统日志查看与审计操作说明',
    summary: '说明管理员如何查看系统操作日志、设备连接日志、预警处置日志，进行安全审计和操作追溯，确保系统运行可监控、可追溯。',
    source: '系统文档',
    date: '2026-04',
    tag: '审计',
    tagType: 'tag-guide',
    icon: '📋',
    sceneLabel: '日志审计',
    coverBg: "url('/images/guide-system.svg') center/cover no-repeat",
    url: '#',
    detailContent: {
      sections: [
        { title: '一、日志体系概述', content: '火睛智控中心自动记录三类关键日志，为安全审计和问题追溯提供完整数据支撑：\n• 操作日志：记录用户在系统中的所有操作行为\n• 设备日志：记录传感器设备的连接、断线、数据上报等事件\n• 预警日志：记录每条预警的触发、处置、闭环全过程' },
        { title: '二、操作日志查看', content: '操作日志记录以下事件类型：用户登录/登出、设备添加/编辑/删除、阈值修改、预警处置、邀请码生成、数据镜像操作等。每条日志包含：操作时间、操作人账号、操作类型、操作对象、操作结果（成功/失败）、客户端IP地址。管理员可在个人中心的系统管理区域查看。' },
        { title: '三、设备连接日志', content: '每当传感器设备上线或离线时，系统自动记录一条连接日志。通过分析连接日志可以：\n• 发现频繁离线的设备（可能存在网络问题）\n• 统计各设备的在线率\n• 排查设备长时间未上报的原因\n• 为设备维保计划提供数据依据' },
        { title: '四、预警处置审计', content: '每条预警从触发到闭环的完整生命周期都被详细记录：\n• 触发时刻：精确到秒的预警产生时间\n• 触发数据：当时的温度值、温升速率、烟雾浓度\n• 处置过程：谁处理的、何时处理的、采取了什么措施\n• 闭环确认：最终状态变更时间和确认人\n这些记录支持导出，可用于月度消防安全报告和外部审计。' },
        { title: '五、日志保留与合规要求', content: '系统日志默认长期保存在数据库中。建议定期（每月/每季度）导出重要日志进行异地备份。根据《网络安全法》和消防法规要求，关键安全日志的保存期限不少于180天。数据镜像功能可创建系统快照用于长期归档。' }
      ],
      tips: ['建议每月导出一次预警处置日志用于安全例会分析', '异常登录尝试（错误密码多次）会记录在操作日志中', '可通过日志回溯定位某次误操作的责任人']
    }
  },
  {
    type: 'guide',
    title: '深浅色模式与个性化显示设置教程',
    summary: '介绍如何切换深色/浅色显示模式，调整字体大小，设置动效静音，以及主题偏好自动记忆功能的使用方法，适配不同监控环境需求。',
    source: '系统文档',
    date: '2026-04',
    tag: '设置',
    tagType: 'tag-guide',
    icon: '🎨',
    sceneLabel: '显示设置',
    coverBg: '#0f1923 linear-gradient(135deg, #0f2847 0%, #0a1628 50%, #163a6a 100%)',
    url: '#',
    detailContent: {
      sections: [
        { title: '一、深色/浅色模式切换', content: '系统支持深色和浅色两种显示主题。切换方式：在页面顶部导航栏右侧找到「深色/浅色」切换开关，点击即可切换。切换后所有页面的背景、文字、卡片颜色会同步变化。\n• 深色模式：适合夜间监控室、长时间盯屏场景\n• 浅色模式：适合白天办公环境、明亮场所\n切换后系统自动保存您的偏好，下次登录自动恢复。' },
        { title: '二、字体大小调节', content: '进入「个人中心→显示设置」页面，拖动字体大小滑块可在12px-20px范围内调整全局字体大小。调整实时预览效果，点击「保存」后生效。' },
        { title: '三、动效静音开关', content: '页面右下角有一个动效静音按钮。点击后可一键关闭所有动画效果，包括预警呼吸动效、数值滚动动画、页面切换过渡等。再次点击恢复动效。' },
        { title: '四、主题偏好持久化', content: '所有的显示设置偏好都保存在浏览器本地存储中，刷新页面后设置不会丢失。' }
      ],
      tips: ['长时间值班建议使用深色模式+较大字体+关闭动效的组合', '如果发现页面显示异常，可尝试刷新页面或清除浏览器缓存']
    }
  },
  {
    type: 'guide',
    title: 'AI智能分析功能使用指南',
    summary: '详细介绍如何配置AI服务（智谱GLM/通义千问/DeepSeek/文心一言/OpenAI）、测试连接、以及在预警事件中手动触发AI分析获取专业风险评估和应急处置建议。',
    source: '系统文档',
    date: '2026-04',
    tag: 'AI',
    tagType: 'tag-guide',
    icon: '🤖',
    sceneLabel: 'AI分析',
    coverBg: '#0f1923 linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)',
    url: '#',
    detailContent: {
      sections: [
        { title: '一、AI服务配置', content: '管理员登录后，进入「系统设置→AI服务」页面进行配置：\n\n1. 选择AI服务商：点击对应卡片（推荐智谱GLM，有免费额度）\n2. 选择模型：从下拉列表选择模型（如GLM-4-Flash免费快速、GLM-4旗舰）\n3. 填写API Key：在对应平台获取API Key后填入\n4. 点击「测试连接」验证配置是否正确\n5. 点击「保存配置」完成设置\n\n获取API Key地址：\n• 智谱GLM：open.bigmodel.cn → API Keys\n• 通义千问：dashscope.aliyun.com → API-KEY\n• DeepSeek：platform.deepseek.com → API Keys\n• 文心一言：qianfan.baidubce.com → AK/SK\n• OpenAI：platform.openai.com → API Keys' },
        { title: '二、触发AI分析', content: 'AI分析采用手动触发模式，不会自动调用：\n\n1. 在「实时监控」或「预警记录」页面，找到预警等级≥2的预警卡片\n2. 点击卡片上的「AI分析」按钮\n3. 系统调用AI服务进行分析（约3-10秒）\n4. 分析完成后自动弹出结果弹窗\n\nAI分析内容包括：\n• 🔥 风险分析：结合温度、温升速率、烟雾数据综合判断\n• 📊 火灾概率：0-100%的概率评估\n• ⚡ 应急建议：3-6条专业处置建议' },
        { title: '三、注意事项', content: '• AI分析仅在手动点击时触发，不会自动消耗API额度\n• 每次分析会消耗对应平台的API调用次数\n• 如果分析失败，请检查：API Key是否正确、模型名称是否有效、网络是否畅通\n• 已有AI分析结果的预警，点击「AI分析」可直接查看，不会重复调用' }
      ],
      tips: ['推荐使用智谱GLM的GLM-4-Flash模型，免费且响应快', 'API Key保存后显示为脱敏格式（***开头），留空不会覆盖已有Key', '测试连接功能可验证配置是否正确，建议保存前先测试']
    }
  },
  {
    type: 'guide',
    title: '数据镜像创建与恢复操作教程',
    summary: '介绍管理员如何创建数据库镜像（完整备份）、查看镜像列表、从镜像恢复数据，以及恢复前的自动安全备份机制，确保系统数据安全可追溯。',
    source: '系统文档',
    date: '2026-04',
    tag: '备份',
    tagType: 'tag-guide',
    icon: '💾',
    sceneLabel: '数据镜像',
    coverBg: '#0f1923 linear-gradient(135deg, #1a2332 0%, #1e3a5f 50%, #0d2137 100%)',
    url: '#',
    detailContent: {
      sections: [
        { title: '一、创建数据镜像', content: '管理员进入「个人中心→数据镜像」区域：\n\n1. 点击「创建镜像」按钮\n2. 填写镜像名称（如"部署前备份"、"月度备份"）\n3. 填写描述信息（可选）\n4. 点击确认，系统将复制当前数据库文件为镜像\n\n镜像内容包括：设备数据、传感器历史、预警记录、用户信息、系统配置等全部数据。' },
        { title: '二、查看镜像列表', content: '创建成功后，镜像列表自动刷新显示新镜像，包含以下信息：\n• 镜像名称和描述\n• 创建时间\n• 数据库大小\n• 设备数量、预警数量、传感器数据条数\n\n可对镜像进行恢复或删除操作。' },
        { title: '三、从镜像恢复数据', content: '1. 在镜像列表中找到目标镜像\n2. 点击「恢复」按钮\n3. 系统自动创建恢复前备份（安全机制）\n4. 确认恢复操作\n5. 恢复完成后需重启后端服务使更改生效\n\n⚠️ 恢复操作会覆盖当前数据库，请谨慎操作。系统会在恢复前自动创建备份镜像。' },
        { title: '四、安全机制', content: '• 恢复前自动备份：系统在执行恢复前会自动创建当前数据库的备份镜像\n• 镜像文件独立存储：镜像文件保存在snapshots目录下，不影响运行中的数据库\n• 仅管理员可操作：创建、恢复、删除镜像均需管理员权限' }
      ],
      tips: ['建议在系统重大变更前创建镜像', '定期清理不需要的旧镜像以节省磁盘空间', '恢复操作后必须重启后端服务']
    }
  },
  {
    type: 'emergency',
    title: '测温预警触发后的标准应急处置流程',
    summary: '当火睛智控中心触发温度预警时，值班人员应按"确认预警→查看详情→现场核实→分级处置→结果上报"五步法操作，确保每条预警得到及时有效处置。',
    source: '应急管理部',
    date: '2026-03',
    tag: '流程',
    tagType: 'tag-emergency',
    icon: '🚨',
    sceneLabel: '处置流程',
    coverBg: '#1a1208 linear-gradient(135deg, #3a2a10 0%, #1a1208 50%, #5a3a0a 100%)',
    url: '#',
    detailContent: {
      sections: [
        { title: '一、预警信号识别', content: '当火睛智控中心监测到温度异常时，会通过以下方式发出预警：\n• 实时监控大屏：对应设备卡片变为橙色/红色，数值高亮闪烁\n• 预警记录页：新增一条预警记录，按等级排序\n• 页面边缘：紧急预警时页面四周出现红色呼吸警示\n• 系统通知：站内消息推送（可配置外部通知）' },
        { title: '二、第一步：确认预警信息', content: '值班人员收到预警后应立即：\n1. 点击预警卡片查看详情，获取设备名称、安装位置、当前温度\n2. 查看温升速率数据——快速上升说明风险正在加剧\n3. 检查该设备的历史温度趋势，判断是突发异常还是持续升温\n4. 确认预警等级：一级提示(≥45°C)/二级警告(≥60°C)/三级紧急(≥80°C)' },
        { title: '三、第二步：初步判断与通报', content: '根据预警等级做出初步判断：\n• 一级提示：记录在案，继续观察，无需立即出动\n• 二级警告：通知就近人员前往查看，准备应急物资\n• 三级紧急：立即通知全员，启动应急预案，准备疏散\n同时通过电话/对讲机向现场人员通报预警位置和当前温度。' },
        { title: '四、第三步：现场核实处置', content: '现场人员到达后执行以下操作：\n1. 使用便携式测温仪对比验证系统读数是否准确\n2. 目视检查设备状态及周边环境（有无烟雾、异味、明火）\n3. 如确认真实火情：切断相关电源，使用灭火器材初期扑救\n4. 如为误报（如阳光直射导致升温）：记录原因，恢复监控\n5. 所有操作通过系统「一键处置」按钮记录' },
        { title: '五、第四步：结果上报与闭环', content: '处置完成后：\n1. 在系统预警详情中填写处置结果和备注说明\n2. 上传现场照片（如有）作为处置凭证\n3. 管理员审核确认后标记预警为「已处理」状态\n4. 对于未能在30分钟内处理的紧急预警，系统自动标记超时并升级提醒\n5. 定期复盘分析预警处置数据，优化响应流程' }
      ],
      tips: ['建议制定24小时值班表确保预警及时响应', '每次预警处置后进行简短复盘总结经验教训', '定期组织应急演练使团队熟悉处置流程']
    }
  },
  {
    type: 'emergency',
    title: '不同等级预警的分级处置规范',
    summary: '一级提示预警：关注监测，记录数据变化；二级警告预警：派人现场核实，准备应急物资；三级紧急预警：立即启动应急预案，组织疏散，拨打119。不同等级对应不同响应力度。',
    source: '消防安全网',
    date: '2026-03',
    tag: '分级',
    tagType: 'tag-emergency',
    icon: '⚡',
    sceneLabel: '分级处置',
    coverBg: '#1a1008 linear-gradient(135deg, #3a2a10 0%, #1a1208 50%, #5a3a0a 100%)',
    url: '#',
    detailContent: {
      sections: [
        { title: '一级提示预警（蓝色）处置规范', content: '触发条件：监测点温度≥45°C但<60°C\n风险等级：低风险，属于关注级别\n处置要求：\n• 值班人员记录预警信息，标记为「已关注」\n• 持续观察温度变化趋势（上升/下降/稳定）\n• 如温度持续上升接近60°C，提前做好二级响应准备\n• 无需现场出动，无需通知外部\n响应时限：24小时内完成观察记录' },
        { title: '二级警告预警（橙色）处置规范', content: '触发条件：监测点温度≥60°C但<80°C\n风险等级：中风险，存在潜在火灾隐患\n处置要求：\n• 立即安排1-2名人员携带测温仪前往现场核实\n• 准备好灭火器、灭火毯等基础消防器材\n• 排查原因：设备故障？线路过载？外部热源？\n• 根据现场情况决定是否需要断电或撤离周边物品\n• 在系统中填写初步核查结果\n响应时限：15分钟内到达现场，30分钟内完成初步处置' },
        { title: '三级紧急预警（红色）处置规范', content: '触发条件：监测点温度≥80°C 或 烟雾传感器报警\n风险等级：高风险，火灾临界状态\n处置要求：\n• 立即启动应急预案，全员进入应急状态\n• 第一时间切断相关区域电源\n• 组织人员有序疏散至安全集合点\n• 使用现有消防器材进行初期扑救（确保自身安全前提下）\n• 同时拨打119报警，说明准确位置和当前情况\n• 安排专人在路口引导消防车进场\n• 在系统中实时更新处置进展\n响应时限：立即响应，黄金3分钟内启动疏散' },
        { title: '温升速率紧急升级规则', content: '即使绝对温度未达阈值，以下情况自动升级：\n• 温升速率>5°C/分钟：直接按二级预警处置\n• 温升速率>10°C/分钟：直接按三级预警处置\n• 连续3次一级预警未消除：升级为二级预警\n• 烟雾浓度>300ppm：无论温度如何，立即按三级处置\n这些智能判断由系统AI分析引擎自动执行。' }
      ],
      tips: ['不同场所可根据实际情况微调阈值参数', '建议每季度组织一次分级响应演练', '处置完成后必须进行事后复盘总结']
    }
  },
  {
    type: 'emergency',
    title: '家庭/小型商铺初期火灾扑救实操教程',
    summary: '针对家庭厨房、小型商铺等场所的初期火灾，讲解如何使用灭火器、灭火毯进行扑救，何时应该放弃扑救转为逃生，以及"提、拔、握、压"灭火器使用四步法。',
    source: '消防救援局',
    date: '2026-02',
    tag: '实操',
    tagType: 'tag-emergency',
    icon: '🧯',
    sceneLabel: '初期扑救',
    coverBg: '#1a0c08 linear-gradient(135deg, #3a2a10 0%, #1a1208 50%, #5a3a0a 100%)',
    url: '#',
    detailContent: {
      sections: [
        { title: '一、初期火灾的黄金扑救时间', content: '火灾发生后最初3-5分钟是扑救初期火灾的「黄金时间」。此时火势较小、烟气较少，使用手边灭火器材即可有效控制。超过此时间窗口后，火势会迅速扩大，烟气充满空间，扑救难度急剧增加。本系统的温度预警功能正是为了在阴燃阶段就发现异常，最大化这个黄金时间窗口。' },
        { title: '二、判断是否可以安全扑救', content: '在决定自行扑救前必须快速评估：\n• 火势大小：火焰高度是否超过膝盖？烟雾是否已充满头顶？\n• 灭火器材：身边是否有可用灭火器或灭火毯？压力是否正常？\n• 逃生路线：身后是否有安全的撤离通道？\n• 自身能力：是否接受过灭火器使用培训？\n如果以上任何一项答案为否，应立即放弃扑救，优先逃生并拨打119。' },
        { title: '三、灭火器「提拔握压」四步法', content: '标准操作步骤（以干粉灭火器为例）：\n1. 提：提起灭火器，检查压力表指针是否在绿色区域\n2. 拔：拔掉保险销（金属环）\n3. 握：一只手握住喷管根部（防止后坐力伤人）\n4. 压：另一只手用力压下把手，对准火焰根部扫射\n注意：站在上风向，距离火源2-3米，由近及远扫射。' },
        { title: '四、不同场景的初期扑救要点', content: '• 厨房油锅起火：切勿用水！用锅盖盖住窒息火焰，或倒入切好的蔬菜降温\n• 电气设备起火：先切断电源！使用CO2或干粉灭火器，禁止用水基灭火器\n• 垃圾桶/纸篓起火：用大量水浇灭或用脚踩踏熄灭\n• 窗帘/衣物起火：迅速扯下扔到地面踩灭，或用灭火毯包裹窒息\n• 小型商铺初期火：优先疏散人员，有条件时用灭火器控制火势蔓延' }
      ],
      tips: ['生命安全永远高于财产保护', '定期检查灭火器压力表确保处于有效状态', '建议每个家庭和办公场所至少配备2具灭火器']
    }
  },
  {
    type: 'emergency',
    title: '常用灭火器选型与使用分步教程',
    summary: '详解ABC干粉灭火器、CO2灭火器、水基灭火器的适用场景与使用方法。实验室电气设备优先选用CO2灭火器，仓库可燃物选用ABC干粉灭火器，厨房油火选用水基灭火器。',
    source: '消防安全网',
    date: '2026-02',
    tag: '教程',
    tagType: 'tag-emergency',
    icon: '🔴',
    sceneLabel: '灭火器',
    coverBg: '#1a0808 linear-gradient(135deg, #3a2a10 0%, #1a1208 50%, #5a3a0a 100%)',
    url: '#',
    detailContent: {
      sections: [
        { title: '一、ABC干粉灭火器（通用型）', content: '适用场景：A类固体火灾（木材/纸张）、B类液体火灾（油品/溶剂）、C类气体火灾（天然气/煤气）。\n优点：适用范围广、价格低廉、有效期长\n缺点：喷射后残留粉末需清理、对精密电子设备可能造成二次损害\n推荐场所：仓库、车间、配电房、一般办公区域\n使用方法：提拔握压四步法，对准火焰根部扫射。' },
        { title: '二、CO2灭火器（电气专用型）', content: '适用场景：电气设备火灾、精密仪器火灾、档案室火灾。\n优点：无残留污染、不导电、对设备损伤最小\n缺点：灭火能力相对较弱、在通风不良空间有窒息风险\n推荐场所：机房/服务器室、实验室、配电柜旁、档案室\n注意：CO2灭火器喷出时温度极低(-78°C)，避免冻伤皮肤。' },
        { title: '三、水基灭火器（环保型）', content: '适用场景：A类固体火灾、初期油类火灾。\n优点：环保无毒、可降温阻燃、对人体无害\n缺点：不适用于电气火灾（导电）、不适用于活泼金属火灾\n推荐场所：家庭、学校、办公室、厨房\n特别适合油锅起火——喷射后可在油面形成隔热膜隔绝氧气。' },
        { title: '四、灭火器配置建议', content: '根据火睛智控中心监测的场所类型配置对应灭火器：\n• 实验室/机房：CO2灭火器 + ABC干粉备用\n• 仓库/库房：ABC干粉灭火器（4kg以上大容量）\n• 配电房/电井：CO2灭火器为主\n• 厨房/餐饮：水基灭火器 + 灭火毯\n• 办公区/宿舍：水基或ABC干粉均可\n所有灭火器应每月检查压力表，每年专业维保。' }
      ],
      tips: ['不同类型灭火器不可混用，根据起火物质选择正确类型', '灭火器放置位置应在显眼且易于取用的位置', '过期或压力不足的灭火器必须立即更换']
    }
  },
  {
    type: 'emergency',
    title: '火灾现场人员疏散逃生指南',
    summary: '讲解火灾疏散逃生的核心原则：低姿前行、湿巾捂口鼻、不乘电梯、沿疏散指示标志撤离。配合3D孪生系统的疏散路线标识，提前熟悉安全出口位置和疏散路径。',
    source: '消防救援局',
    date: '2026-01',
    tag: '逃生',
    tagType: 'tag-emergency',
    icon: '🏃',
    sceneLabel: '疏散逃生',
    coverBg: '#0c0c1a linear-gradient(135deg, #1a1a3a 0%, #0c0c1a 50%, #2a2a4a 100%)',
    url: '#',
    detailContent: {
      sections: [
        { title: '一、火灾逃生的核心原则', content: '火灾中烟气是致死主因（占火灾死亡人数的80%以上）。烟气温度可达600°C以上，含有一氧化碳、氰化氢等剧毒气体，吸入数口即可致人昏迷。因此所有逃生动作的核心原则是：尽量减少烟气吸入。' },
        { title: '二、低姿前行法', content: '烟气因密度较小会聚集在空间上部，贴近地面的空气相对清新安全。\n• 弯腰或匍匐前进，使头部保持在烟气层以下\n• 用手背试探前方地面温度，避免烫伤\n• 沿墙角或扶手移动，防止迷失方向\n• 如有条件，用湿毛巾捂住口鼻过滤烟尘' },
        { title: '三、绝对禁止的行为', content: '以下行为在火灾中极度危险：\n✗ 乘坐电梯：电梯可能断电停运，电梯井成为烟气通道\n✗ 返回取物：贪恋财物是最常见的致命错误\n✗ 躲入密闭空间：如卫生间无窗则成为死亡陷阱\n✗ 盲目跳楼：除非在低楼层且有缓冲条件\n✗ 逆流而行：永远朝与烟气相反的方向撤离' },
        { title: '四、利用火睛智控中心3D孪生系统', content: '本系统的3D数字孪生模块标注了建筑内所有安全出口位置和疏散路线：\n• 平时应在3D场景中熟悉自己所在区域的最近出口\n• 疏散路线以绿色标线显示，方向箭头指示撤离方向\n• 安全出口标识在夜间模式下自动发光\n• 建议每季度在系统中进行一次虚拟疏散演练' }
      ],
      tips: ['平时应熟记至少2条不同的疏散路线', '建议家中/办公室常备一条湿毛巾用于应急', '高层建筑火灾切勿盲目跳楼，等待消防员救援']
    }
  },
  {
    type: 'emergency',
    title: '消防设施日常巡检与维护教程',
    summary: '介绍灭火器压力表检查、消火栓水压测试、喷淋头外观检查、疏散指示标志亮度检查等日常巡检要点，确保消防设施始终处于有效状态，配合系统设备在线监测功能。',
    source: '消防安全网',
    date: '2026-01',
    tag: '巡检',
    tagType: 'tag-emergency',
    icon: '🔍',
    sceneLabel: '日常巡检',
    coverBg: '#0c1a0c linear-gradient(135deg, #3a2a10 0%, #1a1208 50%, #5a3a0a 100%)',
    url: '#',
    detailContent: {
      sections: [
        { title: '一、灭火器月度检查清单', content: '每月至少进行一次全面检查：\n• 压力表指针是否在绿色区域（正常压力范围）\n• 保险销是否完好未脱落\n• 筒体是否有锈蚀、变形或机械损伤\n• 喷管/喷嘴是否畅通无堵塞\n• 生产日期和有效期标签是否清晰可见\n• 放置位置是否显眼且无遮挡\n发现任何异常应立即更换或报修。' },
        { title: '二、消火栓系统检查', content: '每季度重点检查：\n• 消火栓箱门是否可正常开启（不被杂物阻挡）\n• 栓内配件齐全：水带、水枪接口完好\n• 阀门手轮转动灵活，无锈死卡滞\n• 有条件时测试出水压力和水流状态\n• 接口处有无漏水渗水痕迹\n消火栓是专业消防力量的主要水源保障，必须确保随时可用。' },
        { title: '三、自动喷淋与报警系统', content: '配合本系统设备监测功能进行联动检查：\n• 喷淋头外观无撞击损坏、油漆无脱落\n• 烟感/温感探测器指示灯正常（绿色=正常）\n• 本系统显示的传感器在线率应≥95%\n• 报警按钮按下后系统是否收到信号\n• 声光报警器是否能正常触发' },
        { title: '四、疏散设施检查', content: '安全出口和疏散通道是生命通道：\n• 安全出口标识灯常亮且亮度充足\n• 疏散指示箭头方向正确指向最近出口\n• 疏散通道无堆放杂物、无上锁门禁\n• 应急照明灯在断电后能否自动点亮\n• 防火门处于关闭状态（平时关闭，火灾时自动打开）' }
      ],
      tips: ['建议建立巡检台账记录每次检查结果', '结合本系统的设备在线监测功能实现线上+线下双重保障', '每年请专业消防机构进行一次全面检测']
    }
  },
  {
    type: 'review',
    title: '辽宁辽阳"4·29"小型餐饮场所火灾事故深度复盘',
    summary: '2025年4月29日辽阳一餐厅火灾致22人死亡。起火原因为厨房排烟道油垢积累引燃，火势沿吊顶迅速蔓延。本系统AI温升预警可在油垢阴燃阶段提前15分钟识别异常温升，为疏散争取黄金时间。',
    source: '事故调查报告',
    date: '2025-05',
    tag: '重大',
    tagType: 'tag-major',
    icon: '🔥',
    sceneLabel: '餐饮场所',
    coverBg: '#1a0808 linear-gradient(135deg, #4a1010 0%, #2a0808 50%, #6a1a0a 100%)',
    url: '#',
    detailContent: {
      sections: [
        { title: '事故概况', content: '2025年4月29日8时20分许，辽宁省辽阳市白塔区三里厨娘饭店发生重大火灾事故。该饭店为一栋二层建筑，一层为餐饮大厅，二层为包间和员工宿舍。火灾造成22人死亡、3人受伤，直接经济损失约1200万元。这是2025年以来全国伤亡最惨重的单起火灾事故。' },
        { title: '起火原因深度分析', content: '经事故调查组认定：直接原因为厨房排烟道内长期积累的食用油垢在高温烹饪时发生自燃引燃。排烟道油垢厚度达3-5cm，已远超安全标准（应不超过2mm）。间接原因包括：\n• 餐厅开业3年从未清洗过排烟道\n• 排烟道防火阀失效未关闭\n• 二层仅有一个安全出口且被杂物堵塞\n• 员工宿舍夜间无人值班\n• 未安装独立式烟雾报警器' },
        { title: '火睛智控中心的预警方案', content: '本系统可在以下环节提前预警：\n• 排烟道温度监测：在排烟口附近部署红外测温传感器，设定55°C预警阈值。油垢阴燃阶段排烟口温度会缓慢上升至60-80°C，系统将在明火出现前15-30分钟触发二级/三级预警\n• 温升速率分析：AI引擎识别「持续缓慢升温」模式（区别于正常烹饪的快速升温降温），自动提升预警等级\n• 3D孪生定位：预警触发后自动聚焦厨房区域，显示最近疏散路线\n• 多级通知：通过站内消息+声音+外部推送确保值班人员第一时间获知' },
        { title: '教训与启示', content: '1. 餐饮场所必须建立排烟道定期清洗制度（至少每季度一次）\n2. 安全出口必须保持畅通，严禁堆放任何物品\nn3. 安装独立的温感/烟感报警系统是最低要求\n4. 夜间营业场所必须有专人值守或联网报警\n5. 本系统的红外测温+AI趋势分析可有效弥补传统烟感报警的盲区——在阴燃阶段即发出预警' }
      ],
      tips: ['此事故推动多地出台餐饮场所强制安装温感报警的规定', '建议所有餐饮用户在本系统排烟区域增设测温点位', '定期组织全员消防演练熟悉疏散路线']
    }
  },
  {
    type: 'review',
    title: '北京丰台长峰医院火灾事故电气起火原因复盘与预警启示',
    summary: '2023年4月长峰医院火灾致29人死亡，起火原因为住院部东楼内部改造施工火花引燃可燃涂料挥发物。本系统可在施工区域部署临时测温点位，实时监测异常温升，预防施工引发火灾。',
    source: '事故调查报告',
    date: '2023-06',
    tag: '重大',
    tagType: 'tag-major',
    icon: '🏥',
    sceneLabel: '医院场所',
    coverBg: '#0c0c1a linear-gradient(135deg, #2a1a3a 0%, #0c0c1a 50%, #3a2a4a 100%)',
    url: '#',
    detailContent: {
      sections: [
        { title: '事故概况', content: '2023年4月18日12时57分，北京长峰医院住院部东楼发生火灾。该楼正在进行内部装修改造，施工现场违规使用明火作业。火花引燃了墙面涂刷的易燃涂料挥发物，火势迅速沿走廊蔓延。由于医院患者多为行动不便的老年人，疏散极为困难。最终造成29人死亡、12人受伤，是近年来最严重的医院火灾事故之一。' },
        { title: '起火原因深度分析', content: '直接原因：施工单位在室内进行焊接/切割等动火作业时产生的火花引燃了周围的可燃涂料（聚氨酯类防火涂料在未完全固化前仍具可燃性）。\n间接原因：\n• 施工现场无专人监护和灭火器材\n• 医院消防控制室值班人员脱岗\n• 自动喷淋系统部分喷头被施工遮挡\n• 疏散通道被施工材料堵塞\n• 未向消防部门报备动火作业' },
        { title: '火睛智控中心的预警方案', content: '针对此类施工场景，本系统的预警能力：\n• 临时测温点位：在施工区域部署便携式红外测温传感器，监测环境温度变化\n• 动火作业温度特征：焊接/切割瞬间局部温度可达300-500°C，即使短暂暴露也会被传感器捕获并触发高温预警\n• 持续温升检测：涂料阴燃阶段温度从常温缓慢升至60-100°C，AI趋势分析可在10-20分钟内识别异常\n• 多级预警推送：施工区域预警自动升级为紧急级别，同时通知安全负责人' },
        { title: '教训与启示', content: '1. 所有动火作业必须办理审批手续并配备监护人\n2. 施工期间必须保证消防设施不被遮挡\n3. 医院等特殊场所应安装独立的早期温度监测系统\n4. 本系统的红外测温可有效弥补传统烟感对「无烟燃烧」的盲区\n5. 建议将施工区域纳入日常测温监控范围' }
      ],
      tips: ['此事故后全国开展医疗机构消防安全专项检查', '动火作业前必须清理周边可燃物并准备灭火器材', '本系统支持临时设备快速接入，适合施工期短期监控']
    }
  },
  {
    type: 'review',
    title: '商铺电气线路过热起火事故复盘与温升预警方案',
    summary: '某临街商铺因电气线路老化过热引燃周围可燃物，从线路过热到明火约经历40分钟温升过程。本系统红外测温传感器可实时监测配电区域温度，在过热阶段即触发预警，远早于明火出现。',
    source: '消防安全网',
    date: '2025-08',
    tag: '电气',
    tagType: 'tag-review',
    icon: '⚡',
    sceneLabel: '电气线路',
    coverBg: '#1a1208 linear-gradient(135deg, #3a2a10 0%, #1a1008 50%, #4a3a0a 100%)',
    url: '#',
    detailContent: {
      sections: [
        { title: '事故概况', content: '2025年8月某市一临街商铺发生火灾，过火面积约45平方米。起火位置为商铺后方的配电箱区域。火灾造成商铺内货物全部烧毁，所幸发生在凌晨无人员伤亡。经调查，直接原因为配电箱内一根老化的铜导线因长期超负荷运行产生高温，绝缘层熔化后引燃周围堆放的纸箱和塑料包装材料。' },
        { title: '温升过程复盘（关键时间线）', content: '事后调取附近监控视频结合电气分析，还原了从线路过热到明火的完整温升过程：\n• T-40分钟：线路温度开始异常上升，从正常35°C升至50°C\n• T-30分钟：温度达到60°C，绝缘层开始软化变形\n• T-20分钟：温度突破80°C，绝缘层局部碳化冒烟\n• T-10分钟：温度超过120°C，出现间歇性电火花\n• T-0：绝缘完全击穿，电弧引燃周边可燃物\n整个过程持续约40分钟，如果在此期间有温度监测手段完全可以提前预警。' },
        { title: '火睛智控中心的预警方案', content: '本系统针对此类场景的完整解决方案：\n• 配电区域部署红外测温传感器，覆盖所有关键接线端子和开关设备\n• 设定阈值：一级提示50°C / 二级警告65°C / 三级紧急85°C\n• 温升速率预警：当检测到>3°C/分钟的持续升温时自动提升预警级别\n• 历史趋势对比：系统记录每日同一时段的温度基线，异常偏离即触发关注\n• 联动处置：二级预警时自动通知电工检查，三级预警时建议切断相关回路' },
        { title: '教训与启示', content: '1. 老旧线路必须定期检测电阻值和绝缘性能\n2. 商铺配电箱周围严禁堆放任何可燃物\n3. 安装过载保护器是最低要求，加装温度监测才是主动防御\n4. 本系统的「缓慢升温」AI识别模式正是为此类场景设计\n5. 建议每半年对配电设施进行一次热成像检测' }
      ],
      tips: ['此类事故在夏季用电高峰期高发', '建议在配电柜内部署贴片式测温传感器', '定期清理配电箱灰尘防止散热不良']
    }
  },
  {
    type: 'review',
    title: '家庭锂电池充电起火事故复盘与早期预警要点',
    summary: '锂电池热失控从异常温升到爆燃仅需数分钟，但前期温升阶段可被红外测温捕获。本系统支持对充电区域部署测温点位，设定55°C预警阈值，在热失控早期触发预警，为人员撤离争取时间。',
    source: '消防安全网',
    date: '2025-06',
    tag: '电池',
    tagType: 'tag-review',
    icon: '🔋',
    sceneLabel: '锂电池',
    coverBg: '#1a0c08 linear-gradient(135deg, #3a2a10 0%, #1a1008 50%, #4a3a0a 100%)',
    url: '#',
    detailContent: {
      sections: [
        { title: '事故概况', content: '2025年6月某小区住户在客厅给电动自行车锂电池充电时发生火灾。据当事人描述：凌晨2点左右听到充电器发出「滋滋」异响，起床查看时发现电池已冒白烟，仅数秒后即发生爆燃喷射火焰。由于事发深夜且反应迅速，人员及时撤离未造成伤亡，但客厅家具全部烧毁。' },
        { title: '锂电池热失控的温升特征', content: '锂电池从正常到热失控爆燃的典型温度变化过程（基于实验数据）：\n• 正常充电阶段：电池表面温度30-40°C\n• 异常升温前兆：温度开始缓慢上升至45-50°C（此时可能无明显外观异常）\n• 热失控启动：温度快速攀升至60-80°C，伴随鼓包变形\n• 喷射前瞬间：温度突破100°C以上，内部压力剧增\n• 爆燃：温度瞬间可达600-1000°C，喷射火焰和高温颗粒\n关键发现：从45°C到爆燃通常有5-15分钟的窗口期，足够预警和撤离。' },
        { title: '火睛智控中心的预警方案', content: '针对锂电池充电场景的本系统部署方案：\n• 在充电区域（阳台/车库/指定充电区）部署非接触式红外测温传感器\n• 设定保守阈值：一级提示45°C / 二级警告55°C / 三级紧急70°C\n• 温升速率超敏感模式：>2°C/分钟即触发警告\n• 充电时段重点关注：系统自动标记夜间充电时段的数据进行重点分析\n• 联动断电建议：三级预警时联动智能插座自动切断充电电源' },
        { title: '教训与启示', content: '1. 严禁将电动车电池带入室内或家中充电\n2. 使用原装充电器和正规品牌的电池产品\n3. 充电时不要覆盖任何物品保持散热\n4. 本系统的红外测温可在热失控前5-15分钟发出预警\n5. 建议在集中充电区域安装固定式温度监测设备' }
      ],
      tips: ['锂电池火灾是近年来家庭火灾的第一大原因', '夜间充电是最高风险场景，建议设置充电定时器', '本系统支持与智能插座联动实现自动断电保护']
    }
  },
    {
    type: 'review',
    title: '库房可燃物自燃事故复盘与温度监测方案',
    summary: '某仓库因存放的化工原料自燃引发火灾，自燃前数小时温度持续缓慢上升。本系统AI温升趋势分析功能可识别"缓慢持续升温"模式，在自燃临界点前触发预警，配合烟雾传感器双重保障。',
    source: '事故调查报告',
    date: '2025-03',
    tag: '自燃',
    tagType: 'tag-review',
    icon: '📦',
    sceneLabel: '仓储场所',
    coverBg: '#1a1008 linear-gradient(135deg, #3a2a10 0%, #1a1008 50%, #4a3a0a 100%)',
    url: '#',
    detailContent: {
      sections: [
        { title: '事故概况', content: '2025年3月某化工原料仓库发生自燃火灾，过火面积200余平方米。起火位置为仓库西北角存放硝化棉的区域。由于该类化学品具有自燃特性（自燃点约180°C），在环境温度较高且通风不良的情况下发生了自热反应。火灾造成直接经济损失约500万元，所幸夜间无人值守未造成人员伤亡。' },
        { title: '自燃的温升过程分析', content: '可燃物自燃是一个缓慢的热积累过程，典型时间线：\n• T-6小时：环境温度25°C，物料表面温度开始微幅上升\n• T-4小时：温度升至35-40°C，超出环境温度10°C以上\n• T-2小时：温度达到50-60°C，氧化反应加速，热量持续积累\n• T-1小时：温度突破80°C，出现肉眼可见的白烟\n• T-0：达到自燃点(180°C)，明火出现\n整个过程持续约6小时！如果在此期间有任何形式的温度监测，完全可以提前数小时预警。' },
        { title: '火睛智控中心的预警方案', content: '针对仓储自燃场景的系统部署方案：\n• 在仓库内按网格布局部署多个测温传感器（每50-100㎡一个点位）\n• 重点监测区域：化学品存放区、堆垛内部、角落死角、通风不良处\n• AI「缓慢升温」识别：系统自动学习各区域的正常温度波动范围，当检测到持续数小时的异常升温趋势时自动标记为高风险\n• 双重保障：温度传感器+烟雾传感器联动，任一指标超标即触发最高级别预警\n• 巡检提醒：当某区域温度持续高于基线5°C以上时自动生成巡检工单' },
        { title: '教训与启示', content: '1. 易自燃化学品必须存放在通风良好且有温控措施的专用仓库\n2. 定期翻堆检查防止热量在局部堆积\n3. 安装多点分布式温度监测是预防自燃最有效的手段\n4. 本系统的AI趋势分析可在自燃前2-4小时发出预警\n5. 建议对高自燃风险物品实行更密集的温度采样频率' }
      ],
      tips: ['自燃火灾多发生在夏季高温或冬季取暖设备附近', '建议仓库安装工业级红外测温阵列实现全覆盖监控', '本系统支持自定义温升趋势分析的灵敏度参数']
    }
  },
  {
    type: 'review',
    title: '高层建筑电缆井起火事故复盘与消防管控要点',
    summary: '高层建筑电缆井起火烟气沿竖井迅速扩散，极易造成重大伤亡。本系统可在电缆井关键节点部署测温传感器，实时监测电缆温度，配合3D孪生场景标注电缆井位置与疏散路径，提升应急响应效率。',
    source: '消防安全网',
    date: '2024-11',
    tag: '高层',
    tagType: 'tag-review',
    icon: '🏢',
    sceneLabel: '高层建筑',
    coverBg: '#0c0c1a linear-gradient(135deg, #1a1a3a 0%, #0c0c1a 50%, #2a2a4a 100%)',
    url: '#',
    detailContent: {
      sections: [
        { title: '事故概况', content: '2024年11月某市一栋28层住宅楼电缆井发生火灾。起火原因为地下室配电柜至17层的供电电缆因长期过载运行导致绝缘层老化发热，最终在15层电缆井处引燃周围可燃物。由于电缆井的「烟囱效应」，高温有毒烟气在数分钟内从起火点迅速蔓延至顶层，造成整栋楼充满浓烟。事故造成4人因吸入烟气中毒死亡、12人受伤。' },
        { title: '电缆井火灾的特殊危险性', content: '电缆井火灾是高层建筑中最危险的火灾类型之一：\n• 烟囱效应：竖向空间使烟气以3-5米/秒的速度向上蔓延\n• 隐蔽性强：起火初期在封闭的井道内发展，外部难以察觉\n• 扑救困难：消防员难以进入狭窄的电缆井内部灭火\n• 影响范围大：一旦起火可能切断整栋楼的电力供应\n• 疏散困难：烟气迅速充斥楼梯间和走廊，阻断逃生路线' },
        { title: '火睛智控中心的预警方案', content: '针对高层电缆井的系统部署方案：\n• 在每层电缆井检查口部署贴片式红外测温传感器（建议每3-5层一个）\n• 重点监测：主进线电缆接头、分支接线盒、穿越楼板处的电缆段\n• 设定阈值：一级提示50°C / 二级警告65°C / 三级紧急80°C\n• 3D孪生联动：在数字孪生场景中标注所有电缆井位置和监测点位，预警时自动聚焦并高亮显示受影响楼层\n• 楼层关联分析：当某层电缆温度异常时自动提示相邻楼层的风险等级' },
        { title: '教训与启示', content: '1. 高层建筑必须定期检测电缆绝缘电阻和载流量\n2. 电缆井内应使用阻燃电缆并做好防火封堵\n3. 严禁在电缆井附近堆放任何可燃物品\n4. 本系统的分布式测温可有效覆盖整栋建筑的电缆安全监控\n5. 建议将电缆温度纳入楼宇自动化管理系统的日常巡检项' }
      ],
      tips: ['电缆井火灾是高层建筑的头号隐形杀手', '建议每年进行一次电缆热成像全面检测', '本系统3D孪生模块可直观展示电缆井分布与疏散路径的关系']
    }
  }
])

const filteredNews = computed(() => {
  if (activeTab.value === 'data') return []
  return newsData.value.filter(n => n.type === activeTab.value)
})

function openLink(item) {
  if (item.detailContent) {
    currentDetail.value = item
    showDetail.value = true
    return
  }
  if (!item.url || item.url === '#') {
    ElMessage.info(`「${item.title}」内容正在整理中，敬请期待`)
    return
  }
  window.open(item.url, '_blank')
}

function closeDetail() {
  showDetail.value = false
  currentDetail.value = null
}

onBeforeUnmount(() => {
  showDetail.value = false
  currentDetail.value = null
})
</script>

<style scoped>
.news-page { height: 100%; overflow-y: auto; padding-right: 4px; }

.page-hero {
  position: relative;
  height: 200px;
  border-radius: 20px;
  overflow: hidden;
  margin-bottom: 24px;
  background: #0a1628 linear-gradient(135deg, #0f2847 0%, #0a1628 50%, #163a6a 100%);
}

.hero-pattern {
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, rgba(10,22,40,0.85) 0%, rgba(18,24,38,0.7) 50%, rgba(10,22,40,0.85) 100%);
}

.hero-content {
  position: relative;
  z-index: 1;
  padding: 40px 36px;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  height: 100%;
}

.hero-content h1 {
  font-size: 32px;
  font-weight: 800;
  color: #FFFFFF;
  margin: 0 0 6px 0;
  letter-spacing: 4px;
}

.hero-content p { font-size: 14px; color: rgba(255,255,255,0.85); margin: 0; }

.page-header { margin-bottom: 24px; }

.header-tabs {
  display: flex;
  gap: 6px;
  background: rgba(99, 102, 241, 0.04);
  padding: 4px;
  border-radius: 12px;
  border: 1px solid var(--border-light);
}

.tab-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 10px 18px;
  border: none;
  border-radius: 9px;
  background: transparent;
  color: var(--text-secondary);
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.25s ease;
}

.tab-btn:hover { color: #165DFF; background: rgba(22,93,255,0.06); }

.tab-btn.active {
  background: rgba(22,93,255,0.12);
  color: #165DFF;
  box-shadow: 0 2px 8px rgba(22,93,255,0.1);
  border-bottom: 2px solid #165DFF;
}

.tab-icon { font-size: 14px; }
.news-content { min-height: 300px; }

.featured-card {
  cursor: pointer;
  position: relative;
  border-radius: 16px;
  overflow: hidden;
  margin-bottom: 24px;
  border: 1px solid rgba(22,93,255,0.12);
  transition: all 0.3s ease;
  display: flex;
  min-height: 220px;
}

.featured-card:hover {
  border-color: rgba(22,93,255,0.25);
  opacity: 0.95;
}

.featured-img {
  width: 40%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  position: relative;
  overflow: hidden;
}

.scene-pattern {
  position: absolute;
  inset: 0;
  opacity: 0.06;
  background-image: repeating-linear-gradient(
    0deg, transparent, transparent 19px, rgba(255,255,255,0.3) 19px, rgba(255,255,255,0.3) 20px
  ), repeating-linear-gradient(
    90deg, transparent, transparent 19px, rgba(255,255,255,0.3) 19px, rgba(255,255,255,0.3) 20px
  );
}

.scene-decor {
  position: absolute;
  inset: 0;
  pointer-events: none;
}

.scene-decor-sm {
  position: absolute;
  inset: 0;
  pointer-events: none;
}

.decor-circle {
  position: absolute;
  border-radius: 50%;
  border: 1.5px solid rgba(255,255,255,0.08);
}

.decor-c1 {
  width: 120px;
  height: 120px;
  top: -30px;
  right: -20px;
}

.decor-c2 {
  width: 80px;
  height: 80px;
  bottom: -15px;
  left: -10px;
  border-color: rgba(255,255,255,0.05);
}

.decor-line {
  position: absolute;
  background: rgba(255,255,255,0.04);
}

.decor-l1 {
  width: 1px;
  height: 60%;
  top: 20%;
  left: 25%;
}

.decor-l2 {
  width: 40%;
  height: 1px;
  top: 35%;
  right: 10%;
}

.scene-label {
  position: absolute;
  bottom: 12px;
  left: 14px;
  font-size: 11px;
  font-weight: 600;
  color: rgba(255,255,255,0.35);
  letter-spacing: 2px;
  text-transform: uppercase;
}

.scene-label-sm {
  position: absolute;
  bottom: 8px;
  left: 10px;
  font-size: 10px;
  font-weight: 600;
  color: rgba(255,255,255,0.3);
  letter-spacing: 1.5px;
}

.scene-gov .scene-pattern {
  background-image:
    repeating-linear-gradient(0deg, transparent, transparent 29px, rgba(255,255,255,0.2) 29px, rgba(255,255,255,0.2) 30px),
    repeating-linear-gradient(90deg, transparent, transparent 29px, rgba(255,255,255,0.2) 29px, rgba(255,255,255,0.2) 30px);
  opacity: 0.06;
}

.scene-gov::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 60px;
  height: 60px;
  border: 2px solid rgba(255,255,255,0.08);
  border-radius: 50%;
  box-shadow: 0 0 0 12px rgba(255,255,255,0.03), 0 0 0 24px rgba(255,255,255,0.015);
}

.scene-iot .scene-pattern {
  opacity: 0.12;
  background-image:
    radial-gradient(circle, rgba(99,200,255,0.4) 1px, transparent 1px);
  background-size: 16px 16px;
}

.scene-iot::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 80px;
  height: 80px;
  border: 1.5px solid rgba(99,200,255,0.15);
  border-radius: 50%;
  box-shadow: 0 0 0 16px rgba(99,200,255,0.06), 0 0 0 32px rgba(99,200,255,0.03);
}

.scene-law .scene-pattern {
  opacity: 0.05;
  background-image: repeating-linear-gradient(
    -45deg, transparent, transparent 8px, rgba(255,255,255,0.15) 8px, rgba(255,255,255,0.15) 9px
  );
}

.scene-law::after {
  content: '';
  position: absolute;
  top: 15%;
  left: 20%;
  width: 3px;
  height: 50%;
  background: rgba(255,255,255,0.06);
  box-shadow: 30px 0 0 rgba(255,255,255,0.04), 60px 0 0 rgba(255,255,255,0.03);
}

.scene-building .scene-pattern {
  opacity: 0.07;
  background-image:
    linear-gradient(0deg, rgba(255,255,255,0.08) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255,255,255,0.08) 1px, transparent 1px);
  background-size: 24px 24px;
}

.scene-building::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 40px;
  height: 55%;
  background: linear-gradient(0deg, rgba(255,255,255,0.04), transparent);
  border-left: 1px solid rgba(255,255,255,0.05);
  border-right: 1px solid rgba(255,255,255,0.05);
  box-shadow: -30px 0 0 rgba(255,255,255,0.02), 30px 0 0 rgba(255,255,255,0.02);
}

.scene-fire .scene-pattern {
  opacity: 0.15;
  background-image:
    radial-gradient(ellipse at 50% 100%, rgba(255,100,0,0.2) 0%, transparent 60%),
    radial-gradient(ellipse at 30% 80%, rgba(255,50,0,0.1) 0%, transparent 40%),
    radial-gradient(ellipse at 70% 90%, rgba(255,150,0,0.08) 0%, transparent 35%);
}

.scene-fire::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 50px;
  height: 60%;
  background: linear-gradient(0deg, rgba(255,80,0,0.18), rgba(255,80,0,0.05) 60%, transparent);
  border-radius: 50% 50% 0 0;
  filter: blur(6px);
}

.scene-ebike .scene-pattern {
  opacity: 0.06;
  background-image:
    radial-gradient(circle, rgba(255,200,0,0.2) 1px, transparent 1px);
  background-size: 12px 12px;
}

.scene-ebike::after {
  content: '';
  position: absolute;
  bottom: 10%;
  left: 50%;
  transform: translateX(-50%);
  width: 36px;
  height: 36px;
  border: 2px solid rgba(255,200,0,0.1);
  border-radius: 50%;
  box-shadow: 0 0 12px rgba(255,200,0,0.06);
}

.scene-thermal .scene-pattern {
  opacity: 0.12;
  background-image:
    radial-gradient(circle at 30% 40%, rgba(255,0,0,0.12) 0%, transparent 40%),
    radial-gradient(circle at 60% 60%, rgba(255,165,0,0.1) 0%, transparent 35%),
    radial-gradient(circle at 45% 30%, rgba(255,255,0,0.06) 0%, transparent 30%),
    radial-gradient(circle at 70% 25%, rgba(255,80,0,0.08) 0%, transparent 25%);
}

.scene-thermal::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 70px;
  height: 70px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(255,100,0,0.12), rgba(255,0,0,0.05) 60%, transparent);
  box-shadow: 0 0 0 8px rgba(255,100,0,0.04), 0 0 0 16px rgba(255,0,0,0.025);
}

.scene-electric .scene-pattern {
  opacity: 0.07;
  background-image:
    linear-gradient(45deg, rgba(0,170,255,0.1) 25%, transparent 25%),
    linear-gradient(-45deg, rgba(0,170,255,0.1) 25%, transparent 25%);
  background-size: 20px 20px;
}

.scene-electric::after {
  content: '';
  position: absolute;
  top: 30%;
  left: 55%;
  width: 2px;
  height: 40px;
  background: rgba(0,170,255,0.15);
  transform: rotate(-30deg);
  box-shadow: 0 0 8px rgba(0,170,255,0.1);
}

.scene-highrise .scene-pattern {
  opacity: 0.05;
  background-image:
    linear-gradient(90deg, rgba(255,255,255,0.06) 1px, transparent 1px);
  background-size: 20px 20px;
}

.scene-highrise::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 24px;
  height: 70%;
  background: linear-gradient(0deg, rgba(255,255,255,0.05), transparent 90%);
  border-left: 1px solid rgba(255,255,255,0.04);
  border-right: 1px solid rgba(255,255,255,0.04);
  box-shadow: -28px 0 0 rgba(255,255,255,0.02), 28px 0 0 rgba(255,255,255,0.02), -56px 0 0 rgba(255,255,255,0.01), 56px 0 0 rgba(255,255,255,0.01);
}

.cover-icon-lg {
  font-size: 80px;
  filter: drop-shadow(0 4px 20px rgba(0,0,0,0.5));
  position: relative;
  z-index: 2;
}

.featured-content {
  position: relative;
  z-index: 1;
  padding: 28px 32px;
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.featured-badge {
  display: inline-block;
  font-size: 11px;
  font-weight: 600;
  padding: 3px 12px;
  border-radius: 6px;
  background: linear-gradient(135deg, #6366f1, #4f46e5);
  color: #fff;
  margin-bottom: 14px;
  letter-spacing: 1px;
  width: fit-content;
}

.featured-title { font-size: 20px; font-weight: 600; color: var(--text-primary); margin: 0 0 12px 0; line-height: 1.4; }
.featured-desc { font-size: 14px; color: var(--text-secondary); line-height: 1.7; margin: 0 0 16px 0; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
.featured-meta { display: flex; gap: 16px; font-size: 12px; color: var(--text-muted); }

.news-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(340px, 1fr)); gap: 16px; }

.news-card {
  cursor: pointer;
  border-radius: 14px;
  background: var(--bg-card);
  border: 1px solid var(--border-light);
  transition: all 0.25s ease;
  overflow: hidden;
}

.news-card:hover { border-color: rgba(22,93,255,0.18); opacity: 0.95; }

.news-card-cover {
  height: 140px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
}

.news-card:hover .news-card-cover { opacity: 0.9; }

.cover-icon-md {
  font-size: 52px;
  filter: drop-shadow(0 2px 8px rgba(0,0,0,0.4));
  position: relative;
  z-index: 2;
}

.news-card-body { padding: 18px 20px; }

.card-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }

.card-tag { display: inline-block; font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: 5px; }

.tag-new { background: rgba(244, 63, 94, 0.12); color: #fb7185; }
.tag-law { background: rgba(99, 102, 241, 0.12); color: #818cf8; }
.tag-policy { background: rgba(34, 211, 238, 0.12); color: #22d3ee; }
.tag-standard { background: rgba(52, 211, 153, 0.12); color: #34d399; }
.tag-major { background: rgba(248, 113, 113, 0.15); color: #f87171; }
.tag-fire { background: rgba(251, 191, 36, 0.12); color: #fbbf24; }
.tag-tech { background: rgba(139, 92, 246, 0.12); color: #a78bfa; }
.tag-science { background: rgba(6, 182, 212, 0.12); color: #06b6d4; }
.tag-guide { background: rgba(22, 93, 255, 0.12); color: #4080FF; }
.tag-emergency { background: rgba(255, 125, 0, 0.12); color: #FF7D00; }
.tag-review { background: rgba(245, 63, 63, 0.12); color: #F53F3F; }

.card-date { font-size: 11px; color: var(--text-muted); }

.news-title { font-size: 15px; font-weight: 600; color: var(--text-primary); margin: 0 0 8px 0; line-height: 1.4; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.news-summary { font-size: 13px; color: var(--text-secondary); line-height: 1.6; margin: 0 0 14px 0; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.card-bottom { display: flex; justify-content: space-between; align-items: center; }
.news-source { font-size: 12px; color: var(--text-muted); }

.card-link { font-size: 12px; color: var(--primary-light); opacity: 0; transform: translateX(-4px); transition: all 0.2s ease; }

.news-card:hover .card-link,
.incident-card:hover .card-link,
.knowledge-card:hover .card-link { opacity: 1; transform: translateX(0); }

.incident-list { display: flex; flex-direction: column; gap: 0; }

.incident-card { display: flex; gap: 12px; cursor: pointer; padding: 16px 20px; border-radius: 12px; transition: all 0.2s ease; position: relative; }
.incident-card:hover { background: rgba(22,93,255,0.03); }

.incident-img {
  width: 100px;
  height: 80px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  position: relative;
  overflow: hidden;
}

.cover-icon-sm {
  font-size: 36px;
  filter: drop-shadow(0 2px 6px rgba(0,0,0,0.4));
  position: relative;
  z-index: 2;
}

.incident-left { display: flex; flex-direction: column; align-items: center; padding-top: 6px; width: 20px; flex-shrink: 0; }

.incident-indicator { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }
.incident-indicator.tag-major { background: #f87171; box-shadow: 0 0 8px rgba(248, 113, 113, 0.4); }
.incident-indicator.tag-fire { background: #fbbf24; box-shadow: 0 0 8px rgba(251, 191, 36, 0.3); }
.incident-indicator.tag-review { background: #F53F3F; box-shadow: 0 0 8px rgba(245, 63, 63, 0.3); }

.incident-timeline { width: 2px; flex: 1; background: linear-gradient(180deg, rgba(99, 102, 241, 0.15), transparent); margin-top: 8px; }

.incident-body { flex: 1; min-width: 0; }
.incident-header { display: flex; align-items: center; gap: 10px; margin-bottom: 6px; }
.incident-date { font-size: 12px; color: var(--text-muted); }
.incident-title { font-size: 15px; font-weight: 600; color: var(--text-primary); margin: 0 0 6px 0; line-height: 1.4; }
.incident-summary { font-size: 13px; color: var(--text-secondary); line-height: 1.6; margin: 0 0 10px 0; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.incident-footer { display: flex; justify-content: space-between; align-items: center; }

.data-section { display: flex; flex-direction: column; gap: 20px; }

.data-hero {
  position: relative;
  border-radius: 16px;
  overflow: hidden;
  padding: 36px 32px;
  min-height: 140px;
  background: linear-gradient(135deg, #030712, #1e1b4b, #312e81);
}

.data-hero-pattern {
  position: absolute;
  inset: 0;
  background-image:
    radial-gradient(circle at 30% 70%, rgba(99, 102, 241, 0.15) 0%, transparent 50%),
    radial-gradient(circle at 70% 30%, rgba(6, 182, 212, 0.1) 0%, transparent 50%);
}

.data-hero-content { position: relative; z-index: 1; }
.data-hero h3 { font-size: 22px; font-weight: 700; color: #f1f5f9; margin: 0 0 6px 0; }
.data-hero p { font-size: 13px; color: rgba(203, 213, 225, 0.6); margin: 0; }

.stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; }

.stat-block { display: flex; align-items: center; gap: 14px; padding: 20px; border-radius: 14px; background: var(--bg-card); border: 1px solid var(--border-light); transition: all 0.2s ease; }
.stat-block:hover { border-color: rgba(99, 102, 241, 0.15); transform: translateY(-2px); }

.stat-icon-wrap { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 22px; flex-shrink: 0; }
.fire-icon { background: rgba(248, 113, 113, 0.1); }
.death-icon { background: rgba(251, 191, 36, 0.1); }
.loss-icon { background: rgba(139, 92, 246, 0.1); }
.injury-icon { background: rgba(34, 211, 238, 0.1); }

.stat-info { flex: 1; }
.stat-number { font-size: 24px; font-weight: 800; color: var(--text-primary); line-height: 1.2; }
.stat-number .unit { font-size: 12px; font-weight: 500; color: var(--text-secondary); margin-left: 2px; }
.stat-desc { font-size: 12px; color: var(--text-muted); margin-top: 2px; }

.stat-trend { font-size: 11px; font-weight: 600; margin-top: 4px; display: inline-block; padding: 1px 6px; border-radius: 4px; }
.stat-trend.down { color: #34d399; background: rgba(52, 211, 153, 0.1); }
.stat-trend.up { color: #f87171; background: rgba(248, 113, 113, 0.1); }

.data-insight { padding: 20px; border-radius: 14px; background: var(--bg-card); border: 1px solid var(--border-light); }
.data-insight h4 { font-size: 15px; font-weight: 600; color: var(--text-primary); margin: 0 0 16px 0; }

.insight-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; }
.insight-item { text-align: center; padding: 14px; border-radius: 10px; background: rgba(99, 102, 241, 0.03); border: 1px solid var(--border-light); }
.insight-num { font-size: 22px; font-weight: 800; background: linear-gradient(135deg, #818cf8, #22d3ee); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; line-height: 1.3; }
.insight-label { font-size: 11px; color: var(--text-muted); margin-top: 4px; line-height: 1.4; }

.data-note { display: flex; align-items: center; gap: 6px; font-size: 12px; color: var(--text-muted); padding: 10px 16px; border-radius: 8px; background: rgba(99, 102, 241, 0.02); border: 1px solid var(--border-light); }

.knowledge-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 16px; }

.knowledge-card { cursor: pointer; border-radius: 14px; background: var(--bg-card); border: 1px solid var(--border-light); transition: all 0.25s ease; overflow: hidden; }
.knowledge-card:hover { border-color: rgba(22,93,255,0.18); opacity: 0.95; }

.knowledge-cover {
  height: 130px;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
  transition: all 0.3s ease;
}

.knowledge-card:hover .knowledge-cover { opacity: 0.9; }

.knowledge-icon-float {
  font-size: 44px;
  filter: drop-shadow(0 2px 8px rgba(0,0,0,0.4));
  position: relative;
  z-index: 2;
}

.knowledge-body { padding: 16px 18px; }
.knowledge-title { font-size: 15px; font-weight: 600; color: var(--text-primary); margin: 6px 0 6px 0; line-height: 1.4; }
.knowledge-summary { font-size: 13px; color: var(--text-secondary); line-height: 1.6; margin: 0 0 10px 0; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.knowledge-footer { display: flex; justify-content: space-between; align-items: center; }

.slide-fade-enter-active { transition: all 0.25s ease-out; }
.slide-fade-leave-active { transition: all 0.15s ease-in; }
.slide-fade-enter-from { transform: translateX(12px); opacity: 0; }
.slide-fade-leave-to { transform: translateX(-12px); opacity: 0; }

@media (max-width: 1200px) { .stats-grid, .insight-grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 768px) {
  .stats-grid, .insight-grid { grid-template-columns: 1fr; }
  .news-grid, .knowledge-grid { grid-template-columns: 1fr; }
  .header-tabs { flex-wrap: wrap; }
  .featured-card { flex-direction: column; }
  .featured-cover { width: 100%; height: 120px; }
}

.light-mode .page-hero { background: #D4E8FC linear-gradient(135deg, #0f2847 0%, #0a1628 50%, #163a6a 100%); }
.light-mode .hero-pattern { background: linear-gradient(135deg, rgba(212,232,252,0.88) 0%, rgba(247,248,250,0.75) 50%, rgba(212,232,252,0.88) 100%); }
.light-mode .hero-content h1 { color: #1D2129; }
.light-mode .hero-content p { color: #4E5969; }
.light-mode .header-tabs { background: rgba(0,0,0,0.03); border-color: #E5E6EB; }
.light-mode .tab-btn { color: #4E5969; }
.light-mode .tab-btn:hover { color: #165DFF; background: rgba(22,93,255,0.06); }
.light-mode .tab-btn.active { background: rgba(22,93,255,0.08); color: #165DFF; border-bottom-color: #165DFF; }
.light-mode .featured-card { border-color: #E5E6EB; background: #FFFFFF; }
.light-mode .featured-card:hover { border-color: rgba(22,93,255,0.3); }
.light-mode .featured-badge { background: linear-gradient(135deg, #165DFF, #4080FF); }
.light-mode .featured-title { color: #1D2129; }
.light-mode .featured-desc { color: #4E5969; }
.light-mode .featured-meta { color: #86909C; }
.light-mode .news-card { background: #FFFFFF; border-color: #E5E6EB; }
.light-mode .news-card:hover { border-color: rgba(22,93,255,0.25); }
.light-mode .news-title { color: #1D2129; }
.light-mode .news-summary { color: #4E5969; }
.light-mode .news-source { color: #86909C; }
.light-mode .card-date { color: #86909C; }
.light-mode .card-link { color: #165DFF; }
.light-mode .knowledge-card { background: #FFFFFF; border-color: #E5E6EB; }
.light-mode .knowledge-card:hover { border-color: rgba(22,93,255,0.25); }
.light-mode .knowledge-title { color: #1D2129; }
.light-mode .knowledge-summary { color: #4E5969; }
.light-mode .incident-card:hover { background: rgba(22,93,255,0.04); }
.light-mode .incident-title { color: #1D2129; }
.light-mode .incident-summary { color: #4E5969; }
.light-mode .incident-date { color: #86909C; }
.light-mode .data-hero { background: linear-gradient(135deg, #E8F0FE, #D4E8FC, #C4D8F0); }
.light-mode .data-hero h3 { color: #1D2129; }
.light-mode .data-hero p { color: #4E5969; }
.light-mode .stat-block { background: #FFFFFF; border-color: #E5E6EB; }
.light-mode .stat-number { color: #1D2129; }
.light-mode .stat-number .unit { color: #4E5969; }
.light-mode .stat-desc { color: #86909C; }
.light-mode .data-insight { background: #FFFFFF; border-color: #E5E6EB; }
.light-mode .data-insight h4 { color: #1D2129; }
.light-mode .insight-item { background: rgba(22,93,255,0.03); border-color: #E5E6EB; }
.light-mode .insight-label { color: #86909C; }
.light-mode .data-note { background: rgba(22,93,255,0.02); border-color: #E5E6EB; color: #86909C; }

.detail-overlay {
  position:fixed; inset:0; z-index:2000;
  background:rgba(0,0,0,0.5);
  display:flex; align-items:center; justify-content:center;
  animation:overlayIn 0.2s ease-out;
}
@keyframes overlayIn { from { opacity:0; } to { opacity:1; } }

.detail-modal {
  width:720px; max-height:80vh;
  background:var(--bg-card);
  border:1px solid var(--border-default);
  border-radius:12px;
  box-shadow:0 20px 60px rgba(0,0,0,0.4);
  display:flex; flex-direction:column;
  animation:modalIn 0.25s ease-out;
}
@keyframes modalIn { from { opacity:0; transform:translateY(20px) scale(0.97); } to { opacity:1; transform:translateY(0) scale(1); } }

.detail-modal-header {
  display:flex; align-items:center; justify-content:space-between;
  padding:16px 24px;
  border-bottom:1px solid var(--border-subtle);
}
.detail-modal-title { font-size:17px; font-weight:700; color:var(--text-primary); margin:0; flex:1; padding-right:12px; }
.detail-modal-close {
  width:32px; height:32px; border:none; border-radius:6px;
  background:transparent; color:var(--text-muted); font-size:16px;
  cursor:pointer; display:flex; align-items:center; justify-content:center;
  transition:all 0.15s;
}
.detail-modal-close:hover { background:var(--bg-hover); color:var(--text-primary); }

.detail-modal-body { padding:20px 24px 24px; overflow-y:auto; max-height:calc(80vh - 60px); }

.detail-body { }
.detail-meta { display:flex; align-items:center; gap:10px; margin-bottom:20px; padding-bottom:14px; border-bottom:1px solid var(--border-subtle); }
.detail-tag { font-size:12px; font-weight:600; padding:2px 10px; border-radius:4px; }
.detail-source, .detail-date { font-size:12px; color:var(--text-muted); }
.detail-section { margin-bottom:22px; }
.section-title { font-size:15px; font-weight:700; color:var(--text-primary); margin:0 0 8px 0; padding-left:10px; border-left:3px solid var(--accent-blue); line-height:1.4; }
.section-content { font-size:13.5px; color:var(--text-secondary); line-height:1.85; margin:0; text-align:justify; }
.detail-tips { background:rgba(255,170,0,0.06); border:1px solid rgba(255,170,0,0.15); border-radius:8px; padding:14px 18px; margin-top:4px; }
.tips-header { font-size:13px; font-weight:700; color:#FFAA00; margin-bottom:8px; }
.tips-list { margin:0; padding-left:18px; }
.tips-list li { font-size:12.5px; color:var(--text-secondary); line-height:1.9; }

.light-mode .detail-overlay { background:rgba(0,0,0,0.3); }
.light-mode .detail-modal { background:#FFFFFF; border-color:#E5E6EB; box-shadow:0 20px 60px rgba(0,0,0,0.12); }
.light-mode .detail-modal-title { color:#1D2129; }
.light-mode .detail-modal-close { color:#86909C; }
.light-mode .detail-modal-close:hover { background:#F2F3F5; color:#1D2129; }
.light-mode .section-title { color:#1D2129; border-left-color:#165DFF; }
.light-mode .section-content { color:#4E5969; }
.light-mode .detail-tips { background:rgba(255,170,0,0.04); border-color:rgba(255,170,0,0.12); }
</style>
