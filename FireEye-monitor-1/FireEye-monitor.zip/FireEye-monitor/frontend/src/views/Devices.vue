<template>
  <div :class="['devices-page', { 'light-mode': isLightMode }]">
    <div class="page-hero">
      <div class="hero-pattern"></div>
      <div class="hero-content">
        <h1>设备管理</h1>
        <p>全设备状态监控、配置与生命周期管理</p>
      </div>
    </div>

    <div class="toolbar">
      <div class="toolbar-left">
        <el-button type="primary" @click="openAddDialog" v-if="userStore.isInvited">
          <el-icon><Plus /></el-icon> 添加设备
        </el-button>
        <el-input v-model="searchQuery" placeholder="搜索设备名称/编号" clearable style="width:200px" @input="filterDevices">
          <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-select v-model="filterScene" placeholder="安装区域" clearable @change="filterDevices">
          <el-option label="全部区域" value="" />
          <el-option label="实验室" value="laboratory" />
          <el-option label="宿舍" value="dormitory" />
          <el-option label="仓库" value="warehouse" />
          <el-option label="商铺" value="shop" />
          <el-option label="配电房" value="power_room" />
        </el-select>
        <el-select v-model="filterStatus" placeholder="设备状态" clearable @change="filterDevices">
          <el-option label="全部状态" value="" />
          <el-option label="在线" value="online" />
          <el-option label="离线" value="offline" />
          <el-option label="预警" value="alert" />
        </el-select>
      </div>
      <div class="toolbar-right">
        <el-button @click="exportDevices" plain size="small"><el-icon><Download /></el-icon> 导出</el-button>
        <el-radio-group v-model="viewMode" size="small">
          <el-radio-button label="card">卡片</el-radio-button>
          <el-radio-button label="list">列表</el-radio-button>
        </el-radio-group>
      </div>
    </div>

    <div class="devices-grid" v-if="viewMode === 'card'">
      <div v-for="(device, idx) in filteredDevices" :key="device.id" class="device-card" :style="{ animationDelay: `${idx * 0.04}s` }">
        <div class="card-accent" :class="getAccentClass(device)"></div>
        <div class="card-top">
          <div class="device-status">
            <span :class="['status-dot', device.status]"></span>
            <span class="status-text">{{ device.status === 'online' ? '在线' : '离线' }}</span>
          </div>
          <el-tag v-if="device.lastData?.temperature >= 60 || device.lastData?.smoke_detected === 1" size="small" type="danger" effect="dark" class="alert-badge">预警</el-tag>
          <el-dropdown trigger="click" v-if="userStore.isInvited">
            <el-button :icon="MoreFilled" text circle size="small" />
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item @click="viewDeviceDetail(device)">查看详情</el-dropdown-item>
                <el-dropdown-item @click="viewDeviceHistory(device)">历史数据</el-dropdown-item>
                <el-dropdown-item @click="viewDeviceAlerts(device)">预警记录</el-dropdown-item>
                <el-dropdown-item @click="openEditDialog(device)" divided>编辑配置</el-dropdown-item>
                <el-dropdown-item @click="restartDevice(device)">远程调试</el-dropdown-item>
                <el-dropdown-item @click="deleteDevice(device)" divided style="color:#F53F3F">删除</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
        <div class="card-body">
          <div class="device-icon" :class="device.scene_type">
            <span class="scene-emoji">{{ getSceneEmoji(device.scene_type) }}</span>
          </div>
          <h3 class="device-name">{{ device.name }}</h3>
          <p class="device-id">{{ device.device_id }}</p>
          <div class="device-meta">
            <el-icon><Location /></el-icon>
            <span>{{ device.location || '未设置位置' }}</span>
          </div>
          <el-tag size="small" effect="plain" class="scene-tag">{{ getSceneName(device.scene_type) }}</el-tag>
        </div>
        <div class="card-stats">
          <div class="stat-item">
            <span class="stat-label">实时温度</span>
            <span :class="['stat-value', getTempClass(device.lastData?.temperature), (device.lastData?.temperature >= 60 ? 'temp-danger' : ''), (device.lastData?.temperature >= 45 && device.lastData?.temperature < 60 ? 'temp-warning' : '')]">
              {{ device.lastData?.temperature?.toFixed(1) || '--' }}°C
            </span>
          </div>
          <div class="stat-divider"></div>
          <div class="stat-item">
            <span class="stat-label">环境温度</span>
            <span class="stat-value ambient">{{ device.lastData?.ambient_temp?.toFixed(1) || '--' }}°C</span>
          </div>
          <div class="stat-divider"></div>
          <div class="stat-item">
            <span class="stat-label">湿度</span>
            <span class="stat-value ambient">{{ device.lastData?.humidity?.toFixed(0) || '--' }}%</span>
          </div>
        </div>
        <div class="card-footer">
          <span class="last-report">最后上报: {{ formatTime(device.last_report_time) }}</span>
        </div>
      </div>
    </div>

    <div class="devices-table" v-else>
      <el-table :data="filteredDevices" style="width:100%" stripe size="small" :header-cell-style="{ background:'var(--bg-elevated)', color:'var(--text-secondary)', borderColor:'var(--border-subtle)' }" :cell-style="{ background:'var(--bg-card)', borderColor:'var(--border-subtle)' }">
        <el-table-column prop="name" label="设备名称" min-width="120" />
        <el-table-column prop="device_id" label="设备编号" min-width="120" />
        <el-table-column prop="location" label="安装位置" min-width="100" />
        <el-table-column prop="scene_type" label="场景类型" min-width="80">
          <template #default="{ row }">{{ getSceneName(row.scene_type) }}</template>
        </el-table-column>
        <el-table-column label="实时温度" min-width="90">
          <template #default="{ row }">
            <span :class="getTempClass(row.lastData?.temperature)">{{ row.lastData?.temperature?.toFixed(1) || '--' }}°C</span>
          </template>
        </el-table-column>
        <el-table-column label="湿度" min-width="70">
          <template #default="{ row }">{{ row.lastData?.humidity?.toFixed(0) || '--' }}%</template>
        </el-table-column>
        <el-table-column label="状态" min-width="70">
          <template #default="{ row }">
            <el-tag size="small" :type="row.status === 'online' ? 'success' : 'danger'" effect="dark">{{ row.status === 'online' ? '在线' : '离线' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="最后上报" min-width="100">
          <template #default="{ row }">{{ formatTime(row.last_report_time) }}</template>
        </el-table-column>
        <el-table-column label="操作" min-width="120" fixed="right">
          <template #default="{ row }">
            <el-button size="small" link type="primary" @click="viewDeviceDetail(row)">详情</el-button>
            <el-button size="small" link type="primary" @click="openEditDialog(row)" v-if="userStore.isInvited">编辑</el-button>
            <el-button size="small" link type="danger" @click="deleteDevice(row)" v-if="userStore.isInvited">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <el-empty v-if="filteredDevices.length === 0 && devices.length === 0" description="暂无设备，点击添加设备完成接入">
      <el-button type="primary" @click="openAddDialog" v-if="userStore.isInvited">添加设备</el-button>
    </el-empty>

    <el-dialog v-model="dialogVisible" :title="isEdit ? '编辑设备' : '添加设备'" width="500px">
      <el-form ref="formRef" :model="form" :rules="rules" label-width="100px">
        <el-form-item label="设备ID" prop="device_id" v-if="!isEdit">
          <el-input v-model="form.device_id" placeholder="如: SENSOR_001" />
        </el-form-item>
        <el-form-item label="设备名称" prop="name">
          <el-input v-model="form.name" placeholder="如: 实验室测温点1" />
        </el-form-item>
        <el-form-item label="安装位置" prop="location">
          <el-input v-model="form.location" placeholder="如: 实验室A区" />
        </el-form-item>
        <el-form-item label="场景类型" prop="scene_type">
          <el-select v-model="form.scene_type" placeholder="请选择场景">
            <el-option label="实验室" value="laboratory" />
            <el-option label="学生宿舍" value="dormitory" />
            <el-option label="中小型仓储" value="warehouse" />
            <el-option label="临街商铺" value="shop" />
            <el-option label="配电房" value="power_room" />
          </el-select>
        </el-form-item>
        <el-form-item label="预警阈值" v-if="userStore.isAdmin">
          <div class="threshold-inputs">
            <el-input-number v-model="form.thresholds.level1" :min="0" :max="100" controls-position="right" />
            <span>℃</span>
            <el-input-number v-model="form.thresholds.level2" :min="0" :max="100" controls-position="right" />
            <span>℃</span>
            <el-input-number v-model="form.thresholds.level3" :min="0" :max="100" controls-position="right" />
            <span>℃</span>
          </div>
          <div class="threshold-labels"><span>一级</span><span>二级</span><span>三级</span></div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitForm" :loading="submitting">{{ isEdit ? '保存' : '添加' }}</el-button>
      </template>
    </el-dialog>

    <el-dialog v-model="detailVisible" :title="detailDevice?.name || '设备详情'" width="600px">
      <div class="detail-panel" v-if="detailDevice">
        <div class="detail-row"><span class="detail-label">设备编号</span><span class="detail-val">{{ detailDevice.device_id }}</span></div>
        <div class="detail-row"><span class="detail-label">安装位置</span><span class="detail-val">{{ detailDevice.location }}</span></div>
        <div class="detail-row"><span class="detail-label">场景类型</span><span class="detail-val">{{ getSceneName(detailDevice.scene_type) }}</span></div>
        <div class="detail-row"><span class="detail-label">在线状态</span><span class="detail-val"><el-tag size="small" :type="detailDevice.status === 'online' ? 'success' : 'danger'" effect="dark">{{ detailDevice.status === 'online' ? '在线' : '离线' }}</el-tag></span></div>
        <div class="detail-row"><span class="detail-label">实时温度</span><span :class="['detail-val', getTempClass(detailDevice.lastData?.temperature)]">{{ detailDevice.lastData?.temperature?.toFixed(1) || '--' }}°C</span></div>
        <div class="detail-row"><span class="detail-label">环境温度</span><span class="detail-val">{{ detailDevice.lastData?.ambient_temp?.toFixed(1) || '--' }}°C</span></div>
        <div class="detail-row"><span class="detail-label">湿度</span><span class="detail-val">{{ detailDevice.lastData?.humidity?.toFixed(0) || '--' }}%</span></div>
        <div class="detail-row"><span class="detail-label">烟雾状态</span><span class="detail-val" :style="{ color: detailDevice.lastData?.smoke_detected ? '#F53F3F' : '#00B42A' }">{{ detailDevice.lastData?.smoke_detected ? '报警' : '正常' }}</span></div>
        <div class="detail-row"><span class="detail-label">最后上报</span><span class="detail-val">{{ formatTime(detailDevice.last_report_time) }}</span></div>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onUnmounted, inject } from 'vue'
import { useRouter } from 'vue-router'
import api from '@/api'
import { useUserStore } from '@/stores/user'
import { ElMessage, ElMessageBox } from 'element-plus'
import { MoreFilled } from '@element-plus/icons-vue'

const router = useRouter()
const userStore = useUserStore()
const isLightMode = inject('isLightMode', ref(false))
const devices = ref([])
const dialogVisible = ref(false)
const detailVisible = ref(false)
const detailDevice = ref(null)
const isEdit = ref(false)
const submitting = ref(false)
const filterScene = ref('')
const filterStatus = ref('')
const searchQuery = ref('')
const viewMode = ref('card')

const formRef = ref(null)
const form = reactive({
  device_id: '', name: '', location: '', scene_type: 'laboratory',
  thresholds: { level1: 45, level2: 60, level3: 80 }
})

const rules = {
  device_id: [{ required: true, message: '请输入设备ID', trigger: 'blur' }],
  name: [{ required: true, message: '请输入设备名称', trigger: 'blur' }],
  location: [{ required: true, message: '请输入安装位置', trigger: 'blur' }],
  scene_type: [{ required: true, message: '请选择场景类型', trigger: 'change' }]
}

const filteredDevices = computed(() => {
  return devices.value.filter(d => {
    if (filterScene.value && d.scene_type !== filterScene.value) return false
    if (filterStatus.value === 'online' && d.status !== 'online') return false
    if (filterStatus.value === 'offline' && d.status === 'online') return false
    if (filterStatus.value === 'alert' && !(d.lastData?.temperature >= 60 || d.lastData?.smoke_detected === 1)) return false
    if (searchQuery.value) {
      const q = searchQuery.value.toLowerCase()
      if (!d.name.toLowerCase().includes(q) && !d.device_id.toLowerCase().includes(q)) return false
    }
    return true
  })
})

let refreshTimer = null

async function fetchDevices() {
  try {
    const res = await api.get('/api/devices')
    const realtimeData = await api.get('/api/data/realtime')
    const realtimeMap = {}
    realtimeData.forEach(d => { realtimeMap[d.device_id] = d })
    devices.value = res.map(d => ({ ...d, lastData: realtimeMap[d.device_id] }))
  } catch (e) { console.error(e) }
}

function filterDevices() {}

function openAddDialog() {
  isEdit.value = false
  Object.assign(form, { device_id: '', name: '', location: '', scene_type: 'laboratory', thresholds: { level1: 45, level2: 60, level3: 80 } })
  dialogVisible.value = true
}

function openEditDialog(device) {
  isEdit.value = true
  Object.assign(form, { id: device.id, device_id: device.device_id, name: device.name, location: device.location, scene_type: device.scene_type, thresholds: device.thresholds ? JSON.parse(device.thresholds) : { level1: 45, level2: 60, level3: 80 } })
  dialogVisible.value = true
}

async function submitForm() {
  if (!formRef.value) return
  await formRef.value.validate(async (valid) => {
    if (!valid) return
    submitting.value = true
    try {
      if (isEdit.value) { await api.put(`/api/devices/${form.id}`, form); ElMessage.success('设备更新成功') }
      else { await api.post('/api/devices', form); ElMessage.success('设备添加成功') }
      dialogVisible.value = false; fetchDevices()
    } catch (e) { console.error(e) } finally { submitting.value = false }
  })
}

function viewDeviceDetail(device) { detailDevice.value = device; detailVisible.value = true }
function viewDeviceHistory(device) { router.push('/history') }
function viewDeviceAlerts(device) { router.push('/alerts') }

async function restartDevice(device) {
  try { await ElMessageBox.confirm(`确定要重启设备 "${device.name}" 吗?`, '提示', { type: 'warning' }); await api.post(`/api/devices/${device.id}/restart`); ElMessage.success('重启指令已下发') } catch (e) { if (e !== 'cancel') console.error(e) }
}

async function deleteDevice(device) {
  try { await ElMessageBox.confirm(`确定要删除设备 "${device.name}" 吗?`, '警告', { type: 'error' }); await api.delete(`/api/devices/${device.id}`); ElMessage.success('设备删除成功'); fetchDevices() } catch (e) { if (e !== 'cancel') console.error(e) }
}

function exportDevices() {
  const data = filteredDevices.value.map(d => ({ 名称: d.name, 编号: d.device_id, 位置: d.location, 场景: getSceneName(d.scene_type), 状态: d.status, 温度: d.lastData?.temperature?.toFixed(1) || '--', 湿度: d.lastData?.humidity?.toFixed(0) || '--' }))
  const csv = [Object.keys(data[0]).join(','), ...data.map(r => Object.values(r).join(','))].join('\n')
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a'); a.href = url; a.download = 'devices.csv'; a.click(); URL.revokeObjectURL(url)
}

function getAccentClass(device) {
  if (device.lastData?.temperature >= 60 || device.lastData?.smoke_detected === 1) return 'accent-alert'
  return device.status === 'online' ? 'accent-online' : 'accent-offline'
}

function getSceneName(type) { return { laboratory: '实验室', dormitory: '宿舍', warehouse: '仓库', shop: '商铺', power_room: '配电房' }[type] || type }
function getSceneEmoji(type) { return { laboratory: '🔬', dormitory: '🏠', warehouse: '📦', shop: '🏪', power_room: '⚡' }[type] || '📡' }
function getTempClass(temp) { if (!temp) return ''; if (temp >= 80) return 'temp-danger'; if (temp >= 60) return 'temp-warning'; if (temp >= 45) return 'temp-caution'; return 'temp-normal' }
function formatTime(timeStr) { if (!timeStr) return '从未'; return new Date(timeStr).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }) }

onMounted(() => { fetchDevices(); refreshTimer = setInterval(fetchDevices, 3000) })
onUnmounted(() => { if (refreshTimer) clearInterval(refreshTimer) })
</script>

<style scoped>
.devices-page { height:100%; overflow-y:auto; }

.page-hero {
  position:relative; height:100px; border-radius:var(--radius-md);
  overflow:hidden; margin-bottom:16px;
  background:linear-gradient(135deg, #121826, #0c2e3b, #0a2540);
  animation:fade-in-up 0.4s var(--ease-out) both;
}

.hero-pattern {
  position:absolute; inset:0;
  background-image:radial-gradient(circle at 20% 80%, rgba(6,182,212,0.12) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(22,93,255,0.08) 0%, transparent 50%);
}

.hero-content { position:relative; z-index:1; padding:24px 28px; display:flex; flex-direction:column; justify-content:flex-end; height:100%; }
.hero-content h1 { font-size:22px; font-weight:700; color:var(--text-primary); margin:0 0 2px 0; letter-spacing:2px; }
.hero-content p { font-size:13px; color:var(--text-secondary); margin:0; }

.toolbar {
  display:flex; justify-content:space-between; align-items:center;
  margin-bottom:16px; gap:12px; flex-wrap:wrap;
}

.toolbar-left { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.toolbar-right { display:flex; align-items:center; gap:8px; }

.devices-grid {
  display:grid; grid-template-columns:repeat(auto-fill, minmax(280px, 1fr)); gap:14px;
}

.device-card {
  background:var(--bg-card); border:1px solid var(--border-subtle);
  border-radius:var(--radius-md); overflow:hidden;
  transition:all var(--dur-fast) var(--ease-out);
  animation:fade-in-up 0.4s var(--ease-out) both;
  cursor: pointer;
}

.device-card:hover { border-color:rgba(22,93,255,0.2); transform:translateY(-2px); box-shadow:var(--shadow-md); }
.device-card:active { transform:translateY(0); }

.card-accent { height:3px; }
.card-accent.accent-online { background:linear-gradient(90deg, #00B42A, #0FC6C2); }
.card-accent.accent-offline { background:linear-gradient(90deg, #F53F3F, #FF7D00); }
.card-accent.accent-alert { background:linear-gradient(90deg, #F53F3F, #FF7D00); animation:accent-pulse 1.5s ease-in-out infinite; }

@keyframes accent-pulse {
  0%,100% { opacity:1; }
  50% { opacity:0.5; }
}

.card-top { display:flex; justify-content:space-between; align-items:center; padding:10px 14px 0; }
.alert-badge { animation:pulse-dot 1.5s ease-in-out infinite; }

.device-status { display:flex; align-items:center; gap:5px; }
.status-dot { width:7px; height:7px; border-radius:50%; }
.status-dot.online { background:#00B42A; box-shadow:0 0 6px rgba(0,180,42,0.5); }
.status-dot.offline { background:#F53F3F; }
.status-text { font-size:11px; color:var(--text-secondary); }

.card-body { padding:12px 16px; text-align:center; }
.device-icon { width:48px; height:48px; margin:0 auto 8px; display:flex; align-items:center; justify-content:center; border-radius:var(--radius-md); font-size:22px; }
.device-icon.laboratory { background:rgba(22,93,255,0.1); }
.device-icon.dormitory { background:rgba(15,198,194,0.1); }
.device-icon.warehouse { background:rgba(255,170,0,0.1); }
.device-icon.shop { background:rgba(245,63,63,0.1); }
.device-icon.power_room { background:rgba(15,198,194,0.1); }

.device-name { font-size:15px; font-weight:600; color:var(--text-primary); margin:0 0 2px 0; }
.device-id { font-size:11px; color:var(--text-muted); font-family:var(--font-num); margin:0 0 6px 0; }
.device-meta { display:flex; align-items:center; justify-content:center; gap:4px; font-size:12px; color:var(--text-secondary); margin-bottom:6px; }
.scene-tag { border-radius:var(--radius-sm); }

.card-stats { display:flex; align-items:center; padding:10px 14px; border-top:1px solid var(--border-subtle); background:rgba(22,93,255,0.02); }
.stat-item { flex:1; text-align:center; }
.stat-label { display:block; font-size:10px; color:var(--text-muted); margin-bottom:2px; }
.stat-value { font-size:18px; font-weight:700; color:var(--text-primary); font-family:var(--font-num); }
.stat-value.ambient { color:var(--text-secondary); font-size:14px; }
.stat-value.temp-danger { color:#F53F3F !important; font-size:20px; text-shadow:0 0 8px rgba(245,63,63,0.2); }
.stat-value.temp-warning { color:#FF7D00 !important; font-size:20px; }
.stat-divider { width:1px; height:24px; background:var(--border-subtle); }

.card-footer { padding:8px 14px; border-top:1px solid var(--border-subtle); }
.last-report { font-size:10px; color:var(--text-muted); }

.temp-normal { color:#00B42A; }
.temp-caution { color:#165DFF; }
.temp-warning { color:#FF7D00; }
.temp-danger { color:#F53F3F; }

.detail-panel { display:flex; flex-direction:column; gap:10px; }
.detail-row { display:flex; justify-content:space-between; align-items:center; padding:6px 0; border-bottom:1px solid var(--border-subtle); }
.detail-row:last-child { border-bottom:none; }
.detail-label { font-size:13px; color:var(--text-muted); }
.detail-val { font-size:13px; font-weight:500; color:var(--text-primary); font-family:var(--font-num); }

.threshold-inputs { display:flex; align-items:center; gap:8px; }
.threshold-inputs .el-input-number { width:80px; }
.threshold-labels { display:flex; gap:80px; margin-top:8px; font-size:12px; color:var(--text-secondary); }

@keyframes fade-in-up { from { opacity:0; transform:translateY(12px); } to { opacity:1; transform:translateY(0); } }
@keyframes pulse-dot { 0%,100% { transform:scale(1); } 50% { transform:scale(1.1); opacity:0.7; } }

:deep(.el-table) { --el-table-border-color: var(--border-subtle); --el-table-header-bg-color: var(--bg-elevated); --el-table-row-hover-bg-color: var(--bg-hover); --el-table-bg-color: var(--bg-card); --el-table-tr-bg-color: var(--bg-card); color: var(--text-primary); }
:deep(.el-table th.el-table__cell) { color: var(--text-secondary); font-weight: 600; }

@media (max-width:768px) {
  .toolbar { flex-direction:column; align-items:flex-start; }
  .devices-grid { grid-template-columns:1fr; }
}

.light-mode .page-hero { background:linear-gradient(135deg, #E8F0FE, #D4E8FC, #C4D8F0); }
.light-mode .hero-content h1 { color:#1D2129; }
.light-mode .hero-content p { color:#4E5969; }
.light-mode .device-card { background:#FFFFFF; border-color:#E5E6EB; }
.light-mode .device-card:hover { border-color:rgba(22,93,255,0.3); box-shadow:0 4px 16px rgba(0,0,0,0.08); }
.light-mode .device-name { color:#1D2129; }
.light-mode .device-id { color:#86909C; }
.light-mode .device-meta { color:#4E5969; }
.light-mode .status-text { color:#4E5969; }
.light-mode .stat-label { color:#86909C; }
.light-mode .stat-value { color:#1D2129; }
.light-mode .stat-value.ambient { color:#4E5969; }
.light-mode .card-stats { background:rgba(22,93,255,0.02); border-top-color:#E5E6EB; }
.light-mode .card-footer { border-top-color:#E5E6EB; }
.light-mode .last-report { color:#86909C; }
.light-mode .card-accent.accent-alert { animation:none; background:linear-gradient(90deg, #F53F3F, #FF7D00); }
.light-mode .detail-label { color:#86909C; }
.light-mode .detail-val { color:#1D2129; }
.light-mode .detail-row { border-bottom-color:#E5E6EB; }
.light-mode .threshold-labels { color:#4E5969; }
.light-mode :deep(.el-table) { --el-table-bg-color:#FFFFFF; --el-table-tr-bg-color:#FFFFFF; --el-table-header-bg-color:#F7F8FA; --el-table-row-hover-bg-color:#F2F3F5; --el-table-border-color:#E5E6EB; color:#1D2129; }
.light-mode :deep(.el-table th.el-table__cell) { color:#4E5969; }
</style>
