<template>
  <div :class="['digital-twin-page', { 'light-mode': isLightMode }]">
    <div class="dt-toolbar">
      <div class="toolbar-left">
        <h3 class="toolbar-title">3D 数字孪生监控</h3>
        <el-tag size="small" :type="hasAlert ? 'danger' : 'success'" effect="dark">
          {{ hasAlert ? '预警中' : '运行正常' }}
        </el-tag>
      </div>
      <div class="toolbar-center">
        <el-radio-group v-model="cameraPreset" size="small" @change="applyCameraPreset">
          <el-radio-button label="overview">总览</el-radio-button>
          <el-radio-button label="front">正面</el-radio-button>
          <el-radio-button label="top">俯视</el-radio-button>
          <el-radio-button label="fps">第一人称</el-radio-button>
        </el-radio-group>
      </div>
      <div class="toolbar-right">
        <el-checkbox-group v-model="visibleLayers" size="small" @change="updateLayers">
          <el-checkbox-button label="sensors">传感器</el-checkbox-button>
          <el-checkbox-button label="facilities">消防设施</el-checkbox-button>
          <el-checkbox-button label="evacuation">疏散通道</el-checkbox-button>
          <el-checkbox-button label="labels">标识</el-checkbox-button>
        </el-checkbox-group>
        <el-switch v-model="nightMode" active-text="夜间" inactive-text="日间" size="small" @change="toggleNightMode" />
        <el-button size="small" @click="toggleFireSim" :type="fireSimActive ? 'danger' : 'default'">
          {{ fireSimActive ? '停止模拟' : '火灾蔓延模拟' }}
        </el-button>
        <button class="action-btn focus-btn" :class="{ active: isFocusing }" @click="handleFocusAlert" :disabled="isFocusing">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M2 12h3M19 12h3M12 2v3M12 19v3"/></svg>
          {{ isFocusing ? '聚焦中...' : '风险聚焦' }}
        </button>
        <button class="action-btn patrol-btn" :class="{ active: isPatrolling }" @click="handlePatrol">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
          {{ isPatrolling ? '轮巡中...' : '一键轮巡' }}
        </button>
        <button class="action-btn replay-btn" :class="{ active: historyReplayActive }" @click="handleHistoryReplay">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
          {{ historyReplayActive ? '回放中' : '历史回溯' }}
        </button>
      </div>
    </div>

    <div class="dt-main">
      <div ref="sceneContainer" class="scene-container"></div>

      <div class="scene-overlay-top" v-if="fireSimActive">
        <div class="fire-sim-badge">
          <span class="pulse-dot"></span>
          火灾蔓延模拟中
        </div>
        <div class="fire-sim-controls">
          <span class="sim-label">蔓延速度</span>
          <el-slider v-model="fireSimSpeed" :min="1" :max="10" :step="1" style="width:120px" />
          <el-button size="small" type="danger" @click="resetFireSim">重置</el-button>
        </div>
      </div>

      <div class="focus-overlay" v-if="isFocusing">
        <div class="focus-badge">
          <span class="pulse-dot red"></span>
          风险聚焦模式
        </div>
      </div>

      <div class="patrol-overlay" v-if="isPatrolling">
        <div class="patrol-badge">
          <span class="pulse-dot orange"></span>
          轮巡中 · {{ patrolCurrentIndex + 1 }}/{{ patrolList.length }}
        </div>
      </div>

      <div class="patrol-controls" v-if="isPatrolling">
        <button class="ctrl-btn" @click="patrolPrev" title="上一个"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg></button>
        <button class="ctrl-btn" @click="togglePatrolPause" :title="patrolPaused ? '继续' : '暂停'">
          <svg v-if="patrolPaused" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
          <svg v-else viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
        </button>
        <button class="ctrl-btn" @click="patrolNext" title="下一个"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg></button>
        <button class="ctrl-btn stop" @click="stopPatrol" title="停止轮巡"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="6" width="12" height="12" rx="1"/></svg></button>
      </div>

      <div class="scene-overlay-bottom" v-if="historyReplayActive">
        <div class="replay-controls">
          <button class="ctrl-btn" @click="replayPlaying = !replayPlaying">
            <svg v-if="!replayPlaying" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
            <svg v-else viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
          </button>
          <div class="replay-speed">
            <button :class="['speed-btn', { active: replaySpeed === 0.5 }]" @click="replaySpeed = 0.5">0.5x</button>
            <button :class="['speed-btn', { active: replaySpeed === 1 }]" @click="replaySpeed = 1">1x</button>
            <button :class="['speed-btn', { active: replaySpeed === 2 }]" @click="replaySpeed = 2">2x</button>
          </div>
          <el-slider v-model="replayProgress" :min="0" :max="100" :step="0.5" style="flex:1;margin:0 12px" @change="seekReplay" />
          <span class="replay-time">{{ replayTimeLabel }}</span>
          <button class="ctrl-btn stop" @click="exitReplay" title="退出回放"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg></button>
        </div>
      </div>

      <div class="scene-info-panel" v-if="selectedPoint">
        <div class="info-header">
          <span class="info-title">{{ selectedPoint.name }}</span>
          <el-tag size="small" :type="selectedPoint.level === 3 ? 'danger' : selectedPoint.level === 2 ? 'warning' : selectedPoint.level === 1 ? '' : 'success'" effect="dark">
            {{ ['正常', '提示', '预警', '报警'][selectedPoint.level] }}
          </el-tag>
          <button v-if="isFocusing" class="exit-focus-btn" @click="exitFocus">退出聚焦</button>
          <el-button v-else size="small" text @click="selectedPoint = null"><el-icon><Close /></el-icon></el-button>
        </div>
        <div class="info-body">
          <div class="info-row"><span class="info-label">位置</span><span class="info-val">{{ selectedPoint.location }}</span></div>
          <div class="info-row"><span class="info-label">温度</span><span class="info-val" :style="{ color: getTempColor(selectedPoint.temperature) }">{{ selectedPoint.temperature?.toFixed(1) || '--' }}°C</span></div>
          <div class="info-row"><span class="info-label">温升速率</span><span class="info-val" :style="{ color: (selectedPoint.temp_rise_rate || 0) > 1 ? '#FF7D00' : '#00B42A' }">{{ selectedPoint.temp_rise_rate?.toFixed(1) || '0.0' }}°C/min</span></div>
          <div class="info-row"><span class="info-label">湿度</span><span class="info-val">{{ selectedPoint.humidity?.toFixed(0) || '--' }}%</span></div>
          <div class="info-row"><span class="info-label">烟雾</span><span class="info-val" :style="{ color: selectedPoint.smoke_detected ? '#F53F3F' : '#00B42A' }">{{ selectedPoint.smoke_detected ? '报警' : '正常' }}</span></div>
          <div class="info-row"><span class="info-label">趋势</span><span class="info-val">{{ { rising: '↑升温', falling: '↓降温', stable: '—稳定' }[selectedPoint.trend] || '—稳定' }}</span></div>
          <div class="info-row" v-if="selectedPoint.last_report_time"><span class="info-label">报警时间</span><span class="info-val">{{ formatTime(selectedPoint.last_report_time) }}</span></div>
          <div class="info-divider" v-if="isFocusing"></div>
          <div class="info-section" v-if="isFocusing">
            <div class="info-section-title">AI风险预判</div>
            <div class="info-section-text">{{ getAiAnalysis(selectedPoint) }}</div>
          </div>
          <div class="info-section" v-if="isFocusing">
            <div class="info-section-title">应急处置指引</div>
            <div class="info-section-text">{{ getEmergencyGuide(selectedPoint) }}</div>
          </div>
        </div>
      </div>

      <div class="facility-panel" v-if="selectedFacility">
        <div class="info-header">
          <span class="info-title">{{ selectedFacility.name }}</span>
          <el-tag size="small" :type="selectedFacility.status === 'normal' ? 'success' : 'danger'" effect="dark">
            {{ selectedFacility.status === 'normal' ? '正常' : '异常' }}
          </el-tag>
          <el-button size="small" text @click="selectedFacility = null"><el-icon><Close /></el-icon></el-button>
        </div>
        <div class="info-body">
          <div class="info-row"><span class="info-label">类型</span><span class="info-val">{{ selectedFacility.typeName }}</span></div>
          <div class="info-row"><span class="info-label">编号</span><span class="info-val">{{ selectedFacility.code }}</span></div>
          <div class="info-row"><span class="info-label">位置</span><span class="info-val">{{ selectedFacility.location }}</span></div>
          <div class="info-row"><span class="info-label">巡检日期</span><span class="info-val">{{ selectedFacility.lastInspection }}</span></div>
          <div class="info-row"><span class="info-label">有效期</span><span class="info-val">{{ selectedFacility.expiryDate }}</span></div>
        </div>
      </div>

      <div class="history-select-panel" v-if="showHistoryPanel">
        <div class="panel-header">
          <h4>历史回溯选择</h4>
          <el-button size="small" text @click="showHistoryPanel = false"><el-icon><Close /></el-icon></el-button>
        </div>
        <div class="panel-body">
          <div class="panel-field">
            <label>选择预警事件</label>
            <el-select v-model="selectedAlertId" placeholder="选择历史预警事件" size="small" filterable style="width:100%">
              <el-option v-for="a in alertHistory" :key="a.id" :label="`${formatTime(a.created_at)} - ${a.device_name} - ${a.message}`" :value="a.id" />
            </el-select>
          </div>
          <div class="panel-field">
            <label>回放时间范围</label>
            <div class="time-range-row">
              <el-date-picker v-model="replayStartTime" type="datetime" placeholder="开始时间" size="small" style="flex:1" />
              <span class="time-sep">至</span>
              <el-date-picker v-model="replayEndTime" type="datetime" placeholder="结束时间" size="small" style="flex:1" />
            </div>
          </div>
          <el-button type="primary" size="small" @click="startReplay" :disabled="!selectedAlertId" style="width:100%">开始回放</el-button>
        </div>
      </div>

      <div class="fps-counter">FPS: {{ fpsDisplay }}</div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, watch, nextTick, inject } from 'vue'
import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
import api from '@/api'
import { ElMessage } from 'element-plus'

const isLightMode = inject('isLightMode', ref(false))
const sceneContainer = ref(null)
const cameraPreset = ref('overview')
const nightMode = ref(false)
const fireSimActive = ref(false)
const fireSimSpeed = ref(3)
const selectedPoint = ref(null)
const selectedFacility = ref(null)
const visibleLayers = ref(['sensors', 'facilities', 'evacuation', 'labels'])
const fpsDisplay = ref(60)

const devices = ref([])
const hasAlert = computed(() => devices.value.some(d => d.temperature >= 60 || d.smoke_detected === 1))

const isFocusing = ref(false)
const isPatrolling = ref(false)
const patrolPaused = ref(false)
const patrolList = ref([])
const patrolCurrentIndex = ref(0)
const historyReplayActive = ref(false)
const replayPlaying = ref(false)
const replayProgress = ref(0)
const replayTimeLabel = ref('00:00')
const replaySpeed = ref(1)
const showHistoryPanel = ref(false)
const alertHistory = ref([])
const selectedAlertId = ref(null)
const replayStartTime = ref(null)
const replayEndTime = ref(null)

let scene, camera, renderer, controls, clock
let frameId = null
let sensorGroup, facilityGroup, evacGroup, labelGroup, fireGroup
let riskZoneGroup = null
let highlightGroup = null
let fireParticles = null
let fireSimTime = 0
let historyData = []
let historySensorData = []
let historyIndex = 0
let fpsFrames = 0
let fpsTime = 0
let raycaster, mouse
let patrolTimer = null
let focusDimGroup = null
let originalExposure = 1.2
let cameraAnimId = null

const SENSOR_POSITIONS = [
  { x: -3.5, y: 1.5, z: 2.5, floor: 1, room: '实验室A' },
  { x: 0, y: 1.5, z: 2.5, floor: 1, room: '实验室B' },
  { x: 3.5, y: 1.5, z: 2.5, floor: 1, room: '仓库' },
  { x: -3.5, y: 1.5, z: -2.5, floor: 1, room: '配电室' },
  { x: 0, y: 1.5, z: -2.5, floor: 1, room: '走廊' },
  { x: 3.5, y: 1.5, z: -2.5, floor: 1, room: '办公区' },
  { x: -3.5, y: 4.5, z: 2.5, floor: 2, room: '宿舍201' },
  { x: 0, y: 4.5, z: 2.5, floor: 2, room: '宿舍202' },
  { x: 3.5, y: 4.5, z: 2.5, floor: 2, room: '宿舍203' },
  { x: -3.5, y: 4.5, z: -2.5, floor: 2, room: '会议室' },
  { x: 0, y: 4.5, z: -2.5, floor: 2, room: '走廊' },
  { x: 3.5, y: 4.5, z: -2.5, floor: 2, room: '办公区' },
]

const FACILITY_DATA = [
  { type: 'extinguisher', typeName: '灭火器', name: 'MFZ/ABC4型灭火器', code: 'XHQ-1F-01', location: '1层走廊东侧', status: 'normal', lastInspection: '2026-04-15', expiryDate: '2027-04-15', x: -1.5, y: 0.5, z: 3.8 },
  { type: 'extinguisher', typeName: '灭火器', name: 'MFZ/ABC4型灭火器', code: 'XHQ-1F-02', location: '1层走廊西侧', status: 'normal', lastInspection: '2026-04-15', expiryDate: '2027-04-15', x: 1.5, y: 0.5, z: 3.8 },
  { type: 'hydrant', typeName: '室内消火栓', name: 'SN65室内消火栓', code: 'XHS-1F-01', location: '1层楼梯间', status: 'normal', lastInspection: '2026-04-10', expiryDate: '2028-04-10', x: -5.2, y: 0.5, z: 0 },
  { type: 'hydrant', typeName: '室内消火栓', name: 'SN65室内消火栓', code: 'XHS-1F-02', location: '1层东侧', status: 'normal', lastInspection: '2026-04-10', expiryDate: '2028-04-10', x: 5.2, y: 0.5, z: 0 },
  { type: 'alarm', typeName: '手动报警按钮', name: 'J-SAP-M-M手动报警按钮', code: 'SDBJ-1F-01', location: '1层出口左侧', status: 'normal', lastInspection: '2026-04-20', expiryDate: '长期', x: -5.5, y: 1.2, z: 4.0 },
  { type: 'alarm', typeName: '手动报警按钮', name: 'J-SAP-M-M手动报警按钮', code: 'SDBJ-1F-02', location: '1层出口右侧', status: 'normal', lastInspection: '2026-04-20', expiryDate: '长期', x: 5.5, y: 1.2, z: 4.0 },
  { type: 'sprinkler', typeName: '喷淋头', name: '下垂型洒水喷头', code: 'PLT-1F-01', location: '1层天花板', status: 'normal', lastInspection: '2026-03-28', expiryDate: '长期', x: 0, y: 2.9, z: 0 },
  { type: 'extinguisher', typeName: '灭火器', name: 'MFZ/ABC4型灭火器', code: 'XHQ-2F-01', location: '2层走廊东侧', status: 'normal', lastInspection: '2026-04-15', expiryDate: '2027-04-15', x: -1.5, y: 3.5, z: 3.8 },
  { type: 'hydrant', typeName: '室内消火栓', name: 'SN65室内消火栓', code: 'XHS-2F-01', location: '2层楼梯间', status: 'normal', lastInspection: '2026-04-10', expiryDate: '2028-04-10', x: -5.2, y: 3.5, z: 0 },
  { type: 'exit', typeName: '安全出口', name: '安全出口标志', code: 'ACK-1F-01', location: '1层主入口', status: 'normal', lastInspection: '2026-04-20', expiryDate: '长期', x: 0, y: 2.2, z: 4.2 },
  { type: 'exit', typeName: '安全出口', name: '安全出口标志', code: 'ACK-1F-02', location: '1层后门', status: 'normal', lastInspection: '2026-04-20', expiryDate: '长期', x: 0, y: 2.2, z: -4.2 },
]

function getAlertLevel(device) {
  if (device.smoke_detected === 1 || device.temperature >= 80) return 3
  if (device.temperature >= 60) return 2
  if (device.temperature >= 45) return 1
  return 0
}

function getAlertDevices(minLevel = 1) {
  return devices.value
    .map((d, i) => ({ device: d, index: i, pos: SENSOR_POSITIONS[i], level: getAlertLevel(d) }))
    .filter(d => d.pos && d.level >= minLevel)
    .sort((a, b) => {
      if (b.level !== a.level) return b.level - a.level
      const aTime = a.device.last_report_time ? new Date(a.device.last_report_time).getTime() : 0
      const bTime = b.device.last_report_time ? new Date(b.device.last_report_time).getTime() : 0
      return bTime - aTime
    })
}

function animateCameraTo(targetPos, lookAt, duration, onComplete) {
  if (cameraAnimId) cancelAnimationFrame(cameraAnimId)
  const start = { x: camera.position.x, y: camera.position.y, z: camera.position.z }
  const startTime = performance.now()
  function anim(now) {
    const t = Math.min((now - startTime) / duration, 1)
    const e = 1 - Math.pow(1 - t, 3)
    camera.position.x = start.x + (targetPos.x - start.x) * e
    camera.position.y = start.y + (targetPos.y - start.y) * e
    camera.position.z = start.z + (targetPos.z - start.z) * e
    controls.target.set(lookAt.x, lookAt.y, lookAt.z)
    controls.update()
    if (t < 1) {
      cameraAnimId = requestAnimationFrame(anim)
    } else {
      cameraAnimId = null
      if (onComplete) onComplete()
    }
  }
  cameraAnimId = requestAnimationFrame(anim)
}

function resetCameraToOverview() {
  animateCameraTo({ x: 14, y: 10, z: 14 }, { x: 0, y: 2, z: 0 }, 800)
}

function dimSceneExcept(targetPos) {
  if (!focusDimGroup) {
    focusDimGroup = new THREE.Group()
    focusDimGroup.name = 'focusDimGroup'
    scene.add(focusDimGroup)
  }
  while (focusDimGroup.children.length) focusDimGroup.remove(focusDimGroup.children[0])

  const dimGeo = new THREE.PlaneGeometry(80, 80)
  const dimMat = new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.5, side: THREE.DoubleSide })
  const dimPlane = new THREE.Mesh(dimGeo, dimMat)
  dimPlane.position.y = 0.05
  dimPlane.rotation.x = -Math.PI / 2
  dimPlane.renderOrder = 999
  focusDimGroup.add(dimPlane)

  const clearGeo = new THREE.CircleGeometry(6, 32)
  const clearMat = new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0, side: THREE.DoubleSide })
  const clearArea = new THREE.Mesh(clearGeo, clearMat)
  clearArea.position.set(targetPos.x, 0.06, targetPos.z)
  clearArea.rotation.x = -Math.PI / 2
  clearArea.renderOrder = 1000
  focusDimGroup.add(clearArea)

  originalExposure = renderer.toneMappingExposure
  renderer.toneMappingExposure = 0.6
}

function restoreSceneBrightness() {
  if (focusDimGroup) {
    while (focusDimGroup.children.length) focusDimGroup.remove(focusDimGroup.children[0])
  }
  renderer.toneMappingExposure = originalExposure
}

function handleFocusAlert() {
  if (isFocusing.value) return
  const alertDevices = getAlertDevices(2)
  if (alertDevices.length === 0) {
    ElMessage.info('当前无报警点位，无需聚焦')
    return
  }
  isFocusing.value = true
  const target = alertDevices[0]
  const pos = target.pos
  const cameraTarget = { x: pos.x + 4, y: pos.y + 3, z: pos.z + 4 }
  const lookAt = { x: pos.x, y: pos.y, z: pos.z }
  animateCameraTo(cameraTarget, lookAt, 500, () => {
    dimSceneExcept(pos)
  })
  selectedPoint.value = {
    ...target.device,
    name: target.device.name || `传感器${target.index + 1}`,
    location: pos.room || target.device.location,
    level: target.level
  }
  selectedFacility.value = null
}

function exitFocus() {
  isFocusing.value = false
  restoreSceneBrightness()
  resetCameraToOverview()
  selectedPoint.value = null
}

function handlePatrol() {
  if (isPatrolling.value) {
    stopPatrol()
    return
  }
  const alertDevices = getAlertDevices(1)
  if (alertDevices.length === 0) {
    ElMessage.info('当前无报警点位，无需轮巡')
    return
  }
  patrolList.value = alertDevices
  patrolCurrentIndex.value = 0
  isPatrolling.value = true
  patrolPaused.value = false
  patrolToIndex(0)
}

function patrolToIndex(idx) {
  if (!isPatrolling.value || idx < 0 || idx >= patrolList.value.length) return
  patrolCurrentIndex.value = idx
  const target = patrolList.value[idx]
  const pos = target.pos
  const cameraTarget = { x: pos.x + 3, y: pos.y + 2, z: pos.z + 3 }
  const lookAt = { x: pos.x, y: pos.y, z: pos.z }
  animateCameraTo(cameraTarget, lookAt, 600)
  selectedPoint.value = {
    ...target.device,
    name: target.device.name || `传感器${target.index + 1}`,
    location: pos.room || target.device.location,
    level: target.level
  }
  selectedFacility.value = null
  if (patrolTimer) clearTimeout(patrolTimer)
  const stayTime = target.level === 3 ? 5000 : 3000
  patrolTimer = setTimeout(() => {
    if (!isPatrolling.value || patrolPaused.value) return
    if (patrolCurrentIndex.value < patrolList.value.length - 1) {
      patrolToIndex(patrolCurrentIndex.value + 1)
    } else {
      stopPatrol()
    }
  }, stayTime)
}

function patrolNext() {
  if (patrolCurrentIndex.value < patrolList.value.length - 1) {
    if (patrolTimer) clearTimeout(patrolTimer)
    patrolToIndex(patrolCurrentIndex.value + 1)
  }
}

function patrolPrev() {
  if (patrolCurrentIndex.value > 0) {
    if (patrolTimer) clearTimeout(patrolTimer)
    patrolToIndex(patrolCurrentIndex.value - 1)
  }
}

function togglePatrolPause() {
  patrolPaused.value = !patrolPaused.value
  if (!patrolPaused.value) {
    const target = patrolList.value[patrolCurrentIndex.value]
    const stayTime = target.level === 3 ? 5000 : 3000
    patrolTimer = setTimeout(() => {
      if (!isPatrolling.value || patrolPaused.value) return
      if (patrolCurrentIndex.value < patrolList.value.length - 1) {
        patrolToIndex(patrolCurrentIndex.value + 1)
      } else {
        stopPatrol()
      }
    }, stayTime)
  } else {
    if (patrolTimer) { clearTimeout(patrolTimer); patrolTimer = null }
  }
}

function stopPatrol() {
  isPatrolling.value = false
  patrolPaused.value = false
  if (patrolTimer) { clearTimeout(patrolTimer); patrolTimer = null }
  resetCameraToOverview()
  selectedPoint.value = null
}

async function handleHistoryReplay() {
  if (historyReplayActive.value) {
    exitReplay()
    return
  }
  try {
    const res = await api.get('/api/alerts?limit=200')
    alertHistory.value = res.sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
    if (alertHistory.value.length === 0) {
      ElMessage.info('暂无历史预警记录，无法回溯')
      return
    }
    selectedAlertId.value = alertHistory.value[0].id
    const firstAlert = alertHistory.value[0]
    const alertTime = new Date(firstAlert.created_at)
    replayStartTime.value = new Date(alertTime.getTime() - 30 * 60000)
    replayEndTime.value = new Date(alertTime.getTime() + 10 * 60000)
    showHistoryPanel.value = true
  } catch (e) {
    ElMessage.error('获取历史预警记录失败')
  }
}

async function startReplay() {
  if (!selectedAlertId.value) return
  showHistoryPanel.value = false
  historyReplayActive.value = true
  replayPlaying.value = true
  replayProgress.value = 0

  try {
    const startStr = replayStartTime.value ? new Date(replayStartTime.value).toISOString() : new Date(Date.now() - 3600000).toISOString()
    const endStr = replayEndTime.value ? new Date(replayEndTime.value).toISOString() : new Date().toISOString()
    const res = await api.get(`/api/data/history?start_time=${startStr}&end_time=${endStr}&limit=2000`)
    const rawData = Array.isArray(res) ? res : (res.data || [])
    historySensorData = rawData.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp))
    if (historySensorData.length === 0) {
      ElMessage.warning('该时间段内无传感器数据，无法回放')
      exitReplay()
      return
    }
    replayTimeLabel.value = formatTime(historySensorData[0].timestamp)
    resetCameraToOverview()
    sensorGroup?.children.forEach(child => {
      if (child.userData.type === 'sensor') {
        child.material.color.setHex(0x64748b)
        child.material.emissive.setHex(0x64748b)
        child.material.emissiveIntensity = 0.05
        child.scale.set(1, 1, 1)
      }
    })
  } catch (e) {
    console.error(e)
    historySensorData = []
    ElMessage.error('获取历史数据失败')
    exitReplay()
  }
}

function seekReplay(val) {
  if (historySensorData.length === 0) return
  const idx = Math.floor((val / 100) * (historySensorData.length - 1))
  const targetTime = new Date(historySensorData[Math.min(idx, historySensorData.length - 1)].timestamp).getTime()
  replayTimeLabel.value = formatTime(historySensorData[Math.min(idx, historySensorData.length - 1)].timestamp)

  const latestByDevice = {}
  for (let i = 0; i < historySensorData.length; i++) {
    const r = historySensorData[i]
    const t = new Date(r.timestamp).getTime()
    if (t <= targetTime) {
      latestByDevice[r.device_id] = r
    }
  }
  Object.values(latestByDevice).forEach(record => applyReplayState(record))
}

function applyReplayState(record) {
  if (!sensorGroup) return
  const temp = record.temperature || 0
  const smoke = record.smoke_detected === 1
  const recordDeviceId = record.device_id

  sensorGroup.children.forEach(child => {
    if (child.userData.type === 'sensor' && child.userData.deviceIndex !== undefined) {
      const dev = devices.value[child.userData.deviceIndex]
      if (dev && (dev.id === recordDeviceId || String(dev.id) === String(recordDeviceId))) {
        let level, color, emissiveIntensity, scale
        if (smoke || temp >= 80) { level = 3; color = 0xF53F3F; emissiveIntensity = 1.2; scale = 1.2 }
        else if (temp >= 60) { level = 2; color = 0xFF7D00; emissiveIntensity = 0.8; scale = 1.0 }
        else if (temp >= 45) { level = 1; color = 0x165DFF; emissiveIntensity = 0.5; scale = 1.0 }
        else { level = 0; color = 0x00B42A; emissiveIntensity = 0.15; scale = 1.0 }
        child.material.color.setHex(color)
        child.material.emissive.setHex(color)
        child.material.emissiveIntensity = emissiveIntensity
        child.scale.set(scale, scale, scale)
        child.userData.alertLevel = level
      }
    }
  })
}

function exitReplay() {
  historyReplayActive.value = false
  replayPlaying.value = false
  historySensorData = []
  updateSensorMarkers()
  resetCameraToOverview()
}

function formatTime(timeStr) {
  if (!timeStr) return '--'
  const date = new Date(timeStr)
  return date.toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' })
}

function getAiAnalysis(point) {
  if (!point) return '暂无分析'
  const temp = point.temperature || 0
  if (temp >= 80 || point.smoke_detected) return '检测到高温/烟雾，火灾风险极高，建议立即启动应急预案，组织人员疏散。'
  if (temp >= 60) return '温度持续升高，存在火灾隐患，建议立即排查热源，准备灭火器材。'
  if (temp >= 45) return '温度偏高，需密切关注温升趋势，排查异常热源。'
  return '温度正常，暂无风险。'
}

function getEmergencyGuide(point) {
  if (!point) return ''
  const temp = point.temperature || 0
  if (temp >= 80 || point.smoke_detected) return '1.立即拨打119报警\n2.启动自动喷淋系统\n3.组织人员沿疏散通道撤离\n4.使用就近灭火器初期灭火\n5.关闭防火门隔离火区'
  if (temp >= 60) return '1.现场确认温度异常原因\n2.准备灭火器材待命\n3.通知安全管理人员\n4.疏散附近人员\n5.持续监测温升速率'
  if (temp >= 45) return '1.排查设备过热原因\n2.加强通风散热\n3.持续监测温度变化\n4.做好预警准备'
  return '正常监控即可。'
}

function initScene() {
  if (!sceneContainer.value) return
  const container = sceneContainer.value
  const w = container.clientWidth
  const h = container.clientHeight

  clock = new THREE.Clock()
  scene = new THREE.Scene()
  scene.background = new THREE.Color(0x121826)
  scene.fog = new THREE.FogExp2(0x121826, 0.012)

  camera = new THREE.PerspectiveCamera(50, w / h, 0.1, 200)
  camera.position.set(14, 10, 14)

  renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' })
  renderer.setSize(w, h)
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
  renderer.shadowMap.enabled = true
  renderer.shadowMap.type = THREE.PCFSoftShadowMap
  renderer.toneMapping = THREE.ACESFilmicToneMapping
  renderer.toneMappingExposure = 1.2
  container.appendChild(renderer.domElement)

  controls = new OrbitControls(camera, renderer.domElement)
  controls.enableDamping = true
  controls.dampingFactor = 0.08
  controls.target.set(0, 2, 0)
  controls.minDistance = 3
  controls.maxDistance = 50
  controls.maxPolarAngle = Math.PI / 2.05

  raycaster = new THREE.Raycaster()
  mouse = new THREE.Vector2()
  renderer.domElement.addEventListener('click', onSceneClick)

  setupLighting()
  buildEnvironment()
  buildBuilding()
  createSensorMarkers()
  createFacilities()
  createEvacuationRoutes()
  createLabels()
  createFireSystem()

  animate()
}

function setupLighting() {
  const ambient = new THREE.AmbientLight(0xc8d8f0, 0.8)
  ambient.name = 'ambientLight'
  scene.add(ambient)
  const hemiLight = new THREE.HemisphereLight(0xd4e4ff, 0x3a4a60, 0.6)
  hemiLight.name = 'hemiLight'
  scene.add(hemiLight)
  const dirLight = new THREE.DirectionalLight(0xfff0e0, 1.4)
  dirLight.name = 'dirLight'
  dirLight.position.set(10, 15, 8)
  dirLight.castShadow = true
  dirLight.shadow.mapSize.set(2048, 2048)
  dirLight.shadow.camera.left = -15
  dirLight.shadow.camera.right = 15
  dirLight.shadow.camera.top = 15
  dirLight.shadow.camera.bottom = -15
  dirLight.shadow.camera.near = 0.5
  dirLight.shadow.camera.far = 50
  dirLight.shadow.bias = -0.001
  scene.add(dirLight)
  const fillLight = new THREE.DirectionalLight(0x6699dd, 0.5)
  fillLight.name = 'fillLight'
  fillLight.position.set(-8, 6, -5)
  scene.add(fillLight)
  const topLight = new THREE.DirectionalLight(0xffffff, 0.4)
  topLight.name = 'topLight'
  topLight.position.set(0, 20, 0)
  scene.add(topLight)
  const backLight = new THREE.DirectionalLight(0x88aadd, 0.3)
  backLight.name = 'backLight'
  backLight.position.set(-5, 8, -10)
  scene.add(backLight)
  const pointA = new THREE.PointLight(0xffeedd, 0.6, 20, 1.5)
  pointA.name = 'pointLightA'
  pointA.position.set(5, 4, 5)
  scene.add(pointA)
  const pointB = new THREE.PointLight(0xddeeff, 0.5, 20, 1.5)
  pointB.name = 'pointLightB'
  pointB.position.set(-5, 4, -3)
  scene.add(pointB)
  const pointC = new THREE.PointLight(0xffffff, 0.4, 15, 1.5)
  pointC.name = 'pointLightC'
  pointC.position.set(0, 6, 0)
  scene.add(pointC)
}

function buildEnvironment() {
  const groundGeo = new THREE.PlaneGeometry(60, 60)
  const groundMat = new THREE.MeshStandardMaterial({ color: 0x1a2030, roughness: 0.9, metalness: 0.0 })
  const ground = new THREE.Mesh(groundGeo, groundMat)
  ground.rotation.x = -Math.PI / 2
  ground.receiveShadow = true
  scene.add(ground)
  const grid = new THREE.GridHelper(60, 60, 0x2a3555, 0x1e2740)
  grid.position.y = 0.01
  grid.name = 'gridHelper'
  scene.add(grid)
  const wallMat = new THREE.MeshStandardMaterial({ color: 0x3a4560, roughness: 0.7, metalness: 0.1 })
  const wallThick = 0.2
  const wallH = 0.6
  const wallPositions = [
    { w: 12, d: wallThick, x: 0, z: 5.2, ry: 0 },
    { w: 12, d: wallThick, x: 0, z: -5.2, ry: 0 },
    { w: wallThick, d: 10.4, x: -6.2, z: 0, ry: 0 },
    { w: wallThick, d: 10.4, x: 6.2, z: 0, ry: 0 },
  ]
  wallPositions.forEach(wp => {
    const geo = new THREE.BoxGeometry(wp.w, wallH, wp.d)
    const wall = new THREE.Mesh(geo, wallMat)
    wall.position.set(wp.x, wallH / 2, wp.z)
    wall.rotation.y = wp.ry || 0
    wall.castShadow = true
    wall.receiveShadow = true
    scene.add(wall)
  })
}

function buildBuilding() {
  const concreteMat = new THREE.MeshStandardMaterial({ color: 0x4a5568, roughness: 0.75, metalness: 0.05 })
  const floorMat = new THREE.MeshStandardMaterial({ color: 0x2d3748, roughness: 0.8, metalness: 0.0 })
  const glassMat = new THREE.MeshStandardMaterial({ color: 0x1a365d, roughness: 0.1, metalness: 0.3, transparent: true, opacity: 0.6 })
  const frameMat = new THREE.MeshStandardMaterial({ color: 0x718096, roughness: 0.4, metalness: 0.6 })
  const bw = 12, bd = 10, floorH = 3, floors = 2

  for (let f = 0; f < floors; f++) {
    const baseY = f * floorH
    const floorGeo = new THREE.BoxGeometry(bw, 0.15, bd)
    const floorMesh = new THREE.Mesh(floorGeo, floorMat)
    floorMesh.position.set(0, baseY + 0.075, 0)
    floorMesh.receiveShadow = true
    scene.add(floorMesh)
    const wallConfigs = [
      { w: bw, h: floorH, d: 0.15, x: 0, y: baseY + floorH / 2, z: bd / 2 },
      { w: bw, h: floorH, d: 0.15, x: 0, y: baseY + floorH / 2, z: -bd / 2 },
      { w: 0.15, h: floorH, d: bd, x: -bw / 2, y: baseY + floorH / 2, z: 0 },
      { w: 0.15, h: floorH, d: bd, x: bw / 2, y: baseY + floorH / 2, z: 0 },
    ]
    wallConfigs.forEach(wc => {
      const geo = new THREE.BoxGeometry(wc.w, wc.h, wc.d)
      const wall = new THREE.Mesh(geo, concreteMat)
      wall.position.set(wc.x, wc.y, wc.z)
      wall.castShadow = true
      wall.receiveShadow = true
      scene.add(wall)
    })
    const windowRows = 3, windowCols = 4
    for (let r = 0; r < windowRows; r++) {
      for (let c = 0; c < windowCols; c++) {
        const wx = -bw / 2 + (bw / (windowCols + 1)) * (c + 1)
        const wy = baseY + 0.6 + r * 0.9
        if (wy > baseY + floorH - 0.4) continue
        const wGeo = new THREE.PlaneGeometry(1.2, 0.7)
        const win = new THREE.Mesh(wGeo, glassMat)
        win.position.set(wx, wy, bd / 2 + 0.08)
        scene.add(win)
        const fGeo = new THREE.BoxGeometry(1.3, 0.8, 0.04)
        const frame = new THREE.Mesh(fGeo, frameMat)
        frame.position.set(wx, wy, bd / 2 + 0.06)
        scene.add(frame)
      }
    }
    const stairGeo = new THREE.BoxGeometry(2, floorH, 3)
    const stairMat = new THREE.MeshStandardMaterial({ color: 0x374151, roughness: 0.6, metalness: 0.1 })
    const stair = new THREE.Mesh(stairGeo, stairMat)
    stair.position.set(-bw / 2 + 1.5, baseY + floorH / 2, -bd / 2 + 2)
    stair.castShadow = true
    scene.add(stair)
    const doorGeo = new THREE.BoxGeometry(1.4, 2.2, 0.16)
    const doorMat = new THREE.MeshStandardMaterial({ color: 0x5a4a3a, roughness: 0.5, metalness: 0.2 })
    const door = new THREE.Mesh(doorGeo, doorMat)
    door.position.set(0, baseY + 1.1, bd / 2)
    scene.add(door)
  }
  const roofGeo = new THREE.BoxGeometry(bw + 0.4, 0.2, bd + 0.4)
  const roofMat = new THREE.MeshStandardMaterial({ color: 0x2d3748, roughness: 0.8, metalness: 0.05 })
  const roof = new THREE.Mesh(roofGeo, roofMat)
  roof.position.set(0, floors * floorH + 0.1, 0)
  roof.castShadow = true
  roof.receiveShadow = true
  scene.add(roof)
}

function createSensorMarkers() {
  sensorGroup = new THREE.Group()
  sensorGroup.name = 'sensorGroup'
  scene.add(sensorGroup)
  updateSensorMarkers()
}

function updateSensorMarkers() {
  if (!sensorGroup) return
  while (sensorGroup.children.length) sensorGroup.remove(sensorGroup.children[0])
  const markerGeo = new THREE.SphereGeometry(0.12, 12, 12)
  const poleGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.4, 6)
  const poleMat = new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.5, metalness: 0.3 })

  devices.value.forEach((device, i) => {
    if (i >= SENSOR_POSITIONS.length) return
    const pos = SENSOR_POSITIONS[i]
    const temp = device.temperature || 0
    const smoke = device.smoke_detected === 1
    let level, color, emissiveIntensity, scale
    if (smoke || temp >= 80) { level = 3; color = 0xF53F3F; emissiveIntensity = 1.2; scale = 1.2 }
    else if (temp >= 60) { level = 2; color = 0xFF7D00; emissiveIntensity = 0.8; scale = 1.0 }
    else if (temp >= 45) { level = 1; color = 0x165DFF; emissiveIntensity = 0.5; scale = 1.0 }
    else { level = 0; color = 0x00B42A; emissiveIntensity = 0.15; scale = 1.0 }

    const mat = new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity, roughness: 0.2, metalness: 0.5 })
    const marker = new THREE.Mesh(markerGeo, mat)
    marker.position.set(pos.x, pos.y, pos.z)
    marker.scale.set(scale, scale, scale)
    marker.castShadow = true
    marker.userData = { type: 'sensor', deviceIndex: i, level, alertLevel: level }
    sensorGroup.add(marker)

    const pole = new THREE.Mesh(poleGeo, poleMat)
    pole.position.set(pos.x, pos.y - 0.3, pos.z)
    sensorGroup.add(pole)

    if (level === 1) {
      const ringGeo = new THREE.RingGeometry(0.2, 0.28, 24)
      const ringMat = new THREE.MeshBasicMaterial({ color: 0x165DFF, transparent: true, opacity: 0.35, side: THREE.DoubleSide })
      const ring = new THREE.Mesh(ringGeo, ringMat)
      ring.position.set(pos.x, pos.y, pos.z)
      ring.rotation.x = -Math.PI / 2
      ring.userData.pulse = true; ring.userData.pulseSpeed = 2; ring.userData.pulseType = 'breathe'
      sensorGroup.add(ring)
      const glowGeo = new THREE.SphereGeometry(0.3, 12, 12)
      const glowMat = new THREE.MeshBasicMaterial({ color: 0x165DFF, transparent: true, opacity: 0.06 })
      const glow = new THREE.Mesh(glowGeo, glowMat)
      glow.position.set(pos.x, pos.y, pos.z)
      glow.userData.pulse = true; glow.userData.pulseSpeed = 2; glow.userData.pulseType = 'breathe'
      sensorGroup.add(glow)
    }
    if (level === 2) {
      const ringGeo = new THREE.RingGeometry(0.2, 0.35, 24)
      const ringMat = new THREE.MeshBasicMaterial({ color: 0xFF7D00, transparent: true, opacity: 0.45, side: THREE.DoubleSide })
      const ring = new THREE.Mesh(ringGeo, ringMat)
      ring.position.set(pos.x, pos.y, pos.z); ring.rotation.x = -Math.PI / 2
      ring.userData.pulse = true; ring.userData.pulseSpeed = 1; ring.userData.pulseType = 'flash'
      sensorGroup.add(ring)
      const ring2Geo = new THREE.RingGeometry(0.35, 0.45, 24)
      const ring2Mat = new THREE.MeshBasicMaterial({ color: 0xFF7D00, transparent: true, opacity: 0.2, side: THREE.DoubleSide })
      const ring2 = new THREE.Mesh(ring2Geo, ring2Mat)
      ring2.position.set(pos.x, pos.y, pos.z); ring2.rotation.x = -Math.PI / 2
      ring2.userData.pulse = true; ring2.userData.pulseSpeed = 1; ring2.userData.pulseType = 'expand'
      sensorGroup.add(ring2)
      const glowGeo = new THREE.SphereGeometry(0.4, 12, 12)
      const glowMat = new THREE.MeshBasicMaterial({ color: 0xFF7D00, transparent: true, opacity: 0.08 })
      const glow = new THREE.Mesh(glowGeo, glowMat)
      glow.position.set(pos.x, pos.y, pos.z)
      glow.userData.pulse = true; glow.userData.pulseSpeed = 1; glow.userData.pulseType = 'flash'
      sensorGroup.add(glow)
    }
    if (level === 3) {
      const ringGeo = new THREE.RingGeometry(0.2, 0.4, 24)
      const ringMat = new THREE.MeshBasicMaterial({ color: 0xF53F3F, transparent: true, opacity: 0.5, side: THREE.DoubleSide })
      const ring = new THREE.Mesh(ringGeo, ringMat)
      ring.position.set(pos.x, pos.y, pos.z); ring.rotation.x = -Math.PI / 2
      ring.userData.pulse = true; ring.userData.pulseSpeed = 0.5; ring.userData.pulseType = 'flash'
      sensorGroup.add(ring)
      for (let r = 0; r < 3; r++) {
        const waveGeo = new THREE.RingGeometry(0.5 + r * 0.4, 0.6 + r * 0.4, 24)
        const waveMat = new THREE.MeshBasicMaterial({ color: 0xF53F3F, transparent: true, opacity: 0.15 - r * 0.04, side: THREE.DoubleSide })
        const wave = new THREE.Mesh(waveGeo, waveMat)
        wave.position.set(pos.x, pos.y, pos.z); wave.rotation.x = -Math.PI / 2
        wave.userData.pulse = true; wave.userData.pulseSpeed = 0.5; wave.userData.pulseType = 'ripple'; wave.userData.rippleIndex = r
        sensorGroup.add(wave)
      }
      const glowGeo = new THREE.SphereGeometry(0.5, 12, 12)
      const glowMat = new THREE.MeshBasicMaterial({ color: 0xF53F3F, transparent: true, opacity: 0.1 })
      const glow = new THREE.Mesh(glowGeo, glowMat)
      glow.position.set(pos.x, pos.y, pos.z)
      glow.userData.pulse = true; glow.userData.pulseSpeed = 0.5; glow.userData.pulseType = 'flash'
      sensorGroup.add(glow)
    }
  })
  updateRiskZones()
  highlightNearbyFacilities()
}

function createFacilities() {
  facilityGroup = new THREE.Group()
  facilityGroup.name = 'facilityGroup'
  scene.add(facilityGroup)
  FACILITY_DATA.forEach(f => {
    let mesh
    const baseMat = new THREE.MeshStandardMaterial({ color: 0xcc0000, roughness: 0.4, metalness: 0.3 })
    const hydrantMat = new THREE.MeshStandardMaterial({ color: 0xcc0000, roughness: 0.3, metalness: 0.4 })
    const alarmMat = new THREE.MeshStandardMaterial({ color: 0xff4444, emissive: 0xff2222, emissiveIntensity: 0.2, roughness: 0.3, metalness: 0.5 })
    const exitMat = new THREE.MeshStandardMaterial({ color: 0x00cc44, emissive: 0x00aa33, emissiveIntensity: 0.4, roughness: 0.2 })
    const sprinklerMat = new THREE.MeshStandardMaterial({ color: 0xc0c0c0, roughness: 0.3, metalness: 0.7 })
    if (f.type === 'extinguisher') {
      const bodyGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.35, 8)
      mesh = new THREE.Mesh(bodyGeo, baseMat)
      const topGeo = new THREE.CylinderGeometry(0.04, 0.06, 0.08, 8)
      const top = new THREE.Mesh(topGeo, baseMat)
      top.position.y = 0.21
      mesh.add(top)
      mesh.position.set(f.x, f.y + 0.175, f.z)
    } else if (f.type === 'hydrant') {
      const bodyGeo = new THREE.BoxGeometry(0.3, 0.5, 0.2)
      mesh = new THREE.Mesh(bodyGeo, hydrantMat)
      const valveGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.15, 6)
      const valve = new THREE.Mesh(valveGeo, sprinklerMat)
      valve.position.y = 0.32; valve.rotation.z = Math.PI / 2
      mesh.add(valve)
      mesh.position.set(f.x, f.y + 0.25, f.z)
    } else if (f.type === 'alarm') {
      const bodyGeo = new THREE.BoxGeometry(0.15, 0.15, 0.06)
      mesh = new THREE.Mesh(bodyGeo, alarmMat)
      mesh.position.set(f.x, f.y, f.z)
    } else if (f.type === 'sprinkler') {
      const bodyGeo = new THREE.CylinderGeometry(0.04, 0.06, 0.08, 8)
      mesh = new THREE.Mesh(bodyGeo, sprinklerMat)
      const plateGeo = new THREE.CylinderGeometry(0.1, 0.12, 0.02, 12)
      const plate = new THREE.Mesh(plateGeo, sprinklerMat)
      plate.position.y = -0.05
      mesh.add(plate)
      mesh.position.set(f.x, f.y, f.z)
    } else if (f.type === 'exit') {
      const signGeo = new THREE.PlaneGeometry(0.5, 0.3)
      mesh = new THREE.Mesh(signGeo, exitMat)
      mesh.position.set(f.x, f.y, f.z)
      if (Math.abs(f.z) > 4) mesh.rotation.y = f.z > 0 ? Math.PI : 0
    }
    if (mesh) {
      mesh.castShadow = true
      mesh.userData = { type: 'facility', facilityData: f }
      facilityGroup.add(mesh)
    }
  })
}

function createEvacuationRoutes() {
  evacGroup = new THREE.Group()
  evacGroup.name = 'evacGroup'
  scene.add(evacGroup)
  const routeMat = new THREE.MeshBasicMaterial({ color: 0x00B42A, transparent: true, opacity: 0.25, side: THREE.DoubleSide })
  const arrowMat = new THREE.MeshBasicMaterial({ color: 0x00ff44, transparent: true, opacity: 0.5, side: THREE.DoubleSide })
  const routes = [
    [{ x: -3, z: 0 }, { x: -5, z: 0 }, { x: -5, z: 4 }, { x: 0, z: 5.5 }],
    [{ x: 3, z: 0 }, { x: 5, z: 0 }, { x: 5, z: 4 }, { x: 0, z: 5.5 }],
    [{ x: -3, z: 0 }, { x: -5, z: 0 }, { x: -5, z: -4 }, { x: 0, z: -5.5 }],
    [{ x: 3, z: 0 }, { x: 5, z: 0 }, { x: 5, z: -4 }, { x: 0, z: -5.5 }],
  ]
  routes.forEach(points => {
    for (let i = 0; i < points.length - 1; i++) {
      const p1 = points[i], p2 = points[i + 1]
      const dx = p2.x - p1.x, dz = p2.z - p1.z
      const len = Math.sqrt(dx * dx + dz * dz)
      const angle = Math.atan2(dx, dz)
      const geo = new THREE.PlaneGeometry(0.4, len)
      const strip = new THREE.Mesh(geo, routeMat)
      strip.position.set((p1.x + p2.x) / 2, 0.02, (p1.z + p2.z) / 2)
      strip.rotation.x = -Math.PI / 2; strip.rotation.z = -angle
      evacGroup.add(strip)
    }
    for (let i = 0; i < points.length - 1; i++) {
      const p1 = points[i], p2 = points[i + 1]
      const mx = (p1.x + p2.x) / 2, mz = (p1.z + p2.z) / 2
      const dx = p2.x - p1.x, dz = p2.z - p1.z
      const angle = Math.atan2(dx, dz)
      const shape = new THREE.Shape()
      shape.moveTo(0, 0.15); shape.lineTo(0.08, -0.05); shape.lineTo(-0.08, -0.05); shape.closePath()
      const arrowGeo = new THREE.ShapeGeometry(shape)
      const arrow = new THREE.Mesh(arrowGeo, arrowMat)
      arrow.position.set(mx, 0.03, mz)
      arrow.rotation.x = -Math.PI / 2; arrow.rotation.z = -angle + Math.PI
      evacGroup.add(arrow)
    }
  })
  const exitGeo = new THREE.PlaneGeometry(1.2, 0.6)
  const exitSignMat = new THREE.MeshBasicMaterial({ color: 0x00ff44, transparent: true, opacity: 0.4, side: THREE.DoubleSide })
  const exitPositions = [{ x: 0, z: 5.3 }, { x: 0, z: -5.3 }]
  exitPositions.forEach(ep => {
    const sign = new THREE.Mesh(exitGeo, exitSignMat)
    sign.position.set(ep.x, 2.5, ep.z)
    sign.rotation.y = ep.z > 0 ? Math.PI : 0
    evacGroup.add(sign)
  })
}

function createLabels() {
  labelGroup = new THREE.Group()
  labelGroup.name = 'labelGroup'
  scene.add(labelGroup)
}

function createFireSystem() {
  fireGroup = new THREE.Group()
  fireGroup.name = 'fireGroup'
  fireGroup.visible = false
  scene.add(fireGroup)
  riskZoneGroup = new THREE.Group()
  riskZoneGroup.name = 'riskZoneGroup'
  scene.add(riskZoneGroup)
  highlightGroup = new THREE.Group()
  highlightGroup.name = 'highlightGroup'
  scene.add(highlightGroup)
}

function updateRiskZones() {
  if (!riskZoneGroup) return
  while (riskZoneGroup.children.length) riskZoneGroup.remove(riskZoneGroup.children[0])
  const alertDevices = devices.value
    .map((d, i) => ({ device: d, index: i, pos: SENSOR_POSITIONS[i] }))
    .filter(d => d.pos && (d.device.temperature >= 45 || d.device.smoke_detected === 1))
  alertDevices.forEach(({ device, pos }) => {
    const temp = device.temperature || 0
    const smoke = device.smoke_detected === 1
    if (smoke || temp >= 80) {
      const coreZone = new THREE.Mesh(new THREE.CircleGeometry(2, 32), new THREE.MeshBasicMaterial({ color: 0xF53F3F, transparent: true, opacity: 0.12, side: THREE.DoubleSide }))
      coreZone.rotation.x = -Math.PI / 2; coreZone.position.set(pos.x, 0.03, pos.z); coreZone.userData.isRiskZone = true
      riskZoneGroup.add(coreZone)
      const warnZone = new THREE.Mesh(new THREE.CircleGeometry(4, 32), new THREE.MeshBasicMaterial({ color: 0xFF7D00, transparent: true, opacity: 0.06, side: THREE.DoubleSide }))
      warnZone.rotation.x = -Math.PI / 2; warnZone.position.set(pos.x, 0.02, pos.z); warnZone.userData.isRiskZone = true
      riskZoneGroup.add(warnZone)
      const safeZone = new THREE.Mesh(new THREE.RingGeometry(4, 6, 32), new THREE.MeshBasicMaterial({ color: 0xFFAA00, transparent: true, opacity: 0.04, side: THREE.DoubleSide }))
      safeZone.rotation.x = -Math.PI / 2; safeZone.position.set(pos.x, 0.01, pos.z)
      riskZoneGroup.add(safeZone)
    } else if (temp >= 60) {
      const warnZone = new THREE.Mesh(new THREE.CircleGeometry(3, 32), new THREE.MeshBasicMaterial({ color: 0xFF7D00, transparent: true, opacity: 0.08, side: THREE.DoubleSide }))
      warnZone.rotation.x = -Math.PI / 2; warnZone.position.set(pos.x, 0.03, pos.z)
      riskZoneGroup.add(warnZone)
    } else if (temp >= 45) {
      const safeZone = new THREE.Mesh(new THREE.CircleGeometry(2, 32), new THREE.MeshBasicMaterial({ color: 0x165DFF, transparent: true, opacity: 0.05, side: THREE.DoubleSide }))
      safeZone.rotation.x = -Math.PI / 2; safeZone.position.set(pos.x, 0.03, pos.z)
      riskZoneGroup.add(safeZone)
    }
  })
}

function highlightNearbyFacilities() {
  if (!highlightGroup) return
  while (highlightGroup.children.length) highlightGroup.remove(highlightGroup.children[0])
  const alertDevices = devices.value
    .map((d, i) => ({ device: d, index: i, pos: SENSOR_POSITIONS[i] }))
    .filter(d => d.pos && (d.device.temperature >= 60 || d.device.smoke_detected === 1))
  if (alertDevices.length === 0) return
  alertDevices.forEach(({ pos, device }) => {
    const temp = device.temperature || 0
    const smoke = device.smoke_detected === 1
    const isEmergency = smoke || temp >= 80
    const highlightColor = isEmergency ? 0xF53F3F : 0xFF7D00
    FACILITY_DATA.forEach(f => {
      const dx = f.x - pos.x, dz = f.z - pos.z
      const dist = Math.sqrt(dx * dx + dz * dz)
      if (dist < 8) {
        const ringGeo = new THREE.RingGeometry(0.25, 0.35, 16)
        const ringMat = new THREE.MeshBasicMaterial({ color: highlightColor, transparent: true, opacity: 0.4, side: THREE.DoubleSide })
        const ring = new THREE.Mesh(ringGeo, ringMat)
        ring.position.set(f.x, f.y + 0.5, f.z); ring.rotation.x = -Math.PI / 2
        ring.userData.pulse = true; ring.userData.pulseSpeed = isEmergency ? 0.8 : 1.5; ring.userData.pulseType = 'breathe'
        highlightGroup.add(ring)
      }
    })
  })
}

function startFireSim() {
  fireGroup.visible = true
  fireSimTime = 0
  const alertDevices = devices.value.filter(d => d.temperature >= 60 || d.smoke_detected === 1)
  const originIdx = alertDevices.length > 0 ? devices.value.indexOf(alertDevices[0]) : 0
  const originPos = SENSOR_POSITIONS[Math.min(originIdx, SENSOR_POSITIONS.length - 1)]
  while (fireGroup.children.length) fireGroup.remove(fireGroup.children[0])
  const particleCount = 600
  const positions = new Float32Array(particleCount * 3)
  const velocities = new Float32Array(particleCount * 3)
  const lifetimes = new Float32Array(particleCount)
  for (let i = 0; i < particleCount; i++) {
    positions[i * 3] = originPos.x + (Math.random() - 0.5) * 0.5
    positions[i * 3 + 1] = originPos.y + Math.random() * 0.3
    positions[i * 3 + 2] = originPos.z + (Math.random() - 0.5) * 0.5
    velocities[i * 3] = (Math.random() - 0.5) * 0.02
    velocities[i * 3 + 1] = 0.01 + Math.random() * 0.03
    velocities[i * 3 + 2] = (Math.random() - 0.5) * 0.02
    lifetimes[i] = Math.random()
  }
  const geo = new THREE.BufferGeometry()
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3))
  geo.userData = { velocities, lifetimes, origin: new THREE.Vector3(originPos.x, originPos.y, originPos.z), spread: 0.5 }
  const mat = new THREE.PointsMaterial({ color: 0xff4400, size: 0.15, transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending, depthWrite: false })
  fireParticles = new THREE.Points(geo, mat)
  fireGroup.add(fireParticles)
  const smokeMat = new THREE.PointsMaterial({ color: 0x444444, size: 0.25, transparent: true, opacity: 0.3, blending: THREE.NormalBlending, depthWrite: false })
  const smokePositions = new Float32Array(200 * 3)
  for (let i = 0; i < 200; i++) {
    smokePositions[i * 3] = originPos.x + (Math.random() - 0.5) * 1
    smokePositions[i * 3 + 1] = originPos.y + 1 + Math.random() * 2
    smokePositions[i * 3 + 2] = originPos.z + (Math.random() - 0.5) * 1
  }
  const smokeGeo = new THREE.BufferGeometry()
  smokeGeo.setAttribute('position', new THREE.BufferAttribute(smokePositions, 3))
  const smoke = new THREE.Points(smokeGeo, smokeMat)
  smoke.userData.isSmoke = true
  fireGroup.add(smoke)
  const heatGeo = new THREE.SphereGeometry(1.5, 16, 16)
  const heatMat = new THREE.MeshBasicMaterial({ color: 0xff2200, transparent: true, opacity: 0.06, side: THREE.DoubleSide })
  const heatZone = new THREE.Mesh(heatGeo, heatMat)
  heatZone.position.set(originPos.x, originPos.y, originPos.z)
  heatZone.userData.isHeatZone = true
  fireGroup.add(heatZone)
}

function updateFireSim(delta) {
  if (!fireParticles || !fireSimActive.value) return
  fireSimTime += delta * fireSimSpeed.value
  const pos = fireParticles.geometry.attributes.position
  const { velocities, lifetimes, origin, spread } = fireParticles.geometry.userData
  const currentSpread = spread + fireSimTime * 0.15
  for (let i = 0; i < pos.count; i++) {
    lifetimes[i] += delta * 0.5
    if (lifetimes[i] > 1) {
      lifetimes[i] = 0
      pos.array[i * 3] = origin.x + (Math.random() - 0.5) * currentSpread
      pos.array[i * 3 + 1] = origin.y + Math.random() * 0.3
      pos.array[i * 3 + 2] = origin.z + (Math.random() - 0.5) * currentSpread
      velocities[i * 3] = (Math.random() - 0.5) * 0.02
      velocities[i * 3 + 1] = 0.01 + Math.random() * 0.03
      velocities[i * 3 + 2] = (Math.random() - 0.5) * 0.02
    }
    pos.array[i * 3] += velocities[i * 3]
    pos.array[i * 3 + 1] += velocities[i * 3 + 1]
    pos.array[i * 3 + 2] += velocities[i * 3 + 2]
    velocities[i * 3 + 1] += 0.0002
  }
  pos.needsUpdate = true
  fireGroup.children.forEach(child => {
    if (child.userData.isSmoke) {
      const sp = child.geometry.attributes.position
      for (let i = 0; i < sp.count; i++) {
        sp.array[i * 3 + 1] += 0.005
        sp.array[i * 3] += (Math.random() - 0.5) * 0.003
        if (sp.array[i * 3 + 1] > origin.y + 5) {
          sp.array[i * 3] = origin.x + (Math.random() - 0.5) * currentSpread
          sp.array[i * 3 + 1] = origin.y + 0.5 + Math.random()
          sp.array[i * 3 + 2] = origin.z + (Math.random() - 0.5) * currentSpread
        }
      }
      sp.needsUpdate = true
    }
    if (child.userData.isHeatZone) {
      const s = 1 + fireSimTime * 0.08
      child.scale.set(s, s * 0.6, s)
      child.material.opacity = Math.min(0.12, 0.04 + fireSimTime * 0.005)
    }
  })
}

function toggleFireSim() {
  fireSimActive.value = !fireSimActive.value
  if (fireSimActive.value) startFireSim()
  else { fireGroup.visible = false; fireParticles = null }
}

function resetFireSim() {
  fireSimTime = 0
  if (fireSimActive.value) startFireSim()
}

function applyCameraPreset(preset) {
  if (!camera || !controls) return
  let target
  switch (preset) {
    case 'overview': target = { x: 14, y: 10, z: 14 }; break
    case 'front': target = { x: 0, y: 4, z: 16 }; break
    case 'top': target = { x: 0, y: 20, z: 0.1 }; break
    case 'fps': target = { x: 0, y: 1.7, z: 4 }; break
    default: target = { x: 14, y: 10, z: 14 }
  }
  animateCameraTo(target, { x: 0, y: preset === 'fps' ? 1.7 : 2, z: 0 }, 800)
}

function updateLayers(layers) {
  if (sensorGroup) sensorGroup.visible = layers.includes('sensors')
  if (facilityGroup) facilityGroup.visible = layers.includes('facilities')
  if (evacGroup) evacGroup.visible = layers.includes('evacuation')
  if (labelGroup) labelGroup.visible = layers.includes('labels')
}

function toggleNightMode(isNight) {
  if (!scene) return
  const lights = {
    dirLight: isNight ? 0.2 : 1.4,
    ambientLight: isNight ? 0.2 : 0.8,
    hemiLight: isNight ? 0.1 : 0.6,
    fillLight: isNight ? 0.1 : 0.5,
    topLight: isNight ? 0.05 : 0.4,
    backLight: isNight ? 0.05 : 0.3,
    pointLightA: isNight ? 0.15 : 0.6,
    pointLightB: isNight ? 0.1 : 0.5,
    pointLightC: isNight ? 0.1 : 0.4,
  }
  Object.entries(lights).forEach(([name, intensity]) => {
    const light = scene.getObjectByName(name)
    if (light) light.intensity = intensity
  })
  scene.background = new THREE.Color(isNight ? 0x080c14 : 0x121826)
  scene.fog = new THREE.FogExp2(isNight ? 0x080c14 : 0x121826, isNight ? 0.025 : 0.012)
  renderer.toneMappingExposure = isNight ? 0.6 : 1.2
}

function onSceneClick(event) {
  if (!renderer || !camera) return
  if (isFocusing.value) return
  const rect = renderer.domElement.getBoundingClientRect()
  mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1
  mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1
  raycaster.setFromCamera(mouse, camera)
  const sensorHits = raycaster.intersectObjects(sensorGroup?.children || [])
  if (sensorHits.length > 0) {
    const hit = sensorHits[0].object
    if (hit.userData.type === 'sensor') {
      const dev = devices.value[hit.userData.deviceIndex]
      if (dev) {
        const pos = SENSOR_POSITIONS[hit.userData.deviceIndex]
        selectedPoint.value = { ...dev, name: dev.name || `传感器${hit.userData.deviceIndex + 1}`, location: pos?.room || dev.location, level: hit.userData.level }
        selectedFacility.value = null
      }
      return
    }
  }
  const facilityHits = raycaster.intersectObjects(facilityGroup?.children || [])
  if (facilityHits.length > 0) {
    const hit = facilityHits[0].object
    if (hit.userData.type === 'facility') {
      selectedFacility.value = hit.userData.facilityData
      selectedPoint.value = null
      return
    }
  }
  selectedPoint.value = null
  selectedFacility.value = null
}

function getTempColor(temp) {
  if (!temp) return '#94a3b8'
  if (temp >= 80) return '#F53F3F'
  if (temp >= 60) return '#FF7D00'
  if (temp >= 45) return '#165DFF'
  return '#00B42A'
}

async function fetchDevices() {
  try {
    const res = await api.get('/api/data/realtime')
    devices.value = res
    if (!historyReplayActive.value) updateSensorMarkers()
  } catch (e) { console.error(e) }
}

function animate() {
  frameId = requestAnimationFrame(animate)
  const delta = clock.getDelta()
  const time = clock.getElapsedTime()
  fpsFrames++
  fpsTime += delta
  if (fpsTime >= 1) {
    fpsDisplay.value = Math.round(fpsFrames / fpsTime)
    fpsFrames = 0; fpsTime = 0
  }
  if (controls) controls.update()
  const pulseGroups = [sensorGroup, highlightGroup]
  pulseGroups.forEach(group => {
    if (!group) return
    group.children.forEach(m => {
      if (m.userData.pulse) {
        const speed = m.userData.pulseSpeed || 2
        const type = m.userData.pulseType || 'breathe'
        const t = time * (Math.PI * 2 / speed)
        if (type === 'breathe') {
          if (m.material.opacity !== undefined) m.material.opacity = 0.15 + Math.sin(t) * 0.25
        } else if (type === 'flash') {
          if (m.material.opacity !== undefined) m.material.opacity = Math.sin(t) > 0 ? 0.5 : 0.1
        } else if (type === 'expand') {
          const s = 1 + Math.sin(t) * 0.3
          m.scale.set(s, s, s)
          if (m.material.opacity !== undefined) m.material.opacity = 0.1 + Math.abs(Math.sin(t)) * 0.2
        } else if (type === 'ripple') {
          const ri = m.userData.rippleIndex || 0
          const phase = (t + ri * 0.8) % (Math.PI * 2)
          const s = 1 + Math.sin(phase) * 0.2
          m.scale.set(s, s, s)
          if (m.material.opacity !== undefined) m.material.opacity = Math.max(0.02, 0.12 - ri * 0.03) * (0.5 + Math.sin(phase) * 0.5)
        }
      }
    })
  })
  if (fireSimActive.value) updateFireSim(delta)
  if (historyReplayActive.value && replayPlaying.value && historySensorData.length > 0) {
    const totalDuration = 30
    const step = replaySpeed.value * (100 / (totalDuration * 60))
    replayProgress.value = Math.min(100, replayProgress.value + step)
    seekReplay(replayProgress.value)
    if (replayProgress.value >= 100) replayPlaying.value = false
  }
  renderer.render(scene, camera)
}

function handleResize() {
  if (!renderer || !sceneContainer.value) return
  const w = sceneContainer.value.clientWidth
  const h = sceneContainer.value.clientHeight
  renderer.setSize(w, h)
  camera.aspect = w / h
  camera.updateProjectionMatrix()
}

let refreshTimer = null

onMounted(() => {
  fetchDevices()
  nextTick(() => initScene())
  refreshTimer = setInterval(fetchDevices, 3000)
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  stopPatrol()
  exitReplay()
  if (isFocusing.value) exitFocus()
  if (frameId) cancelAnimationFrame(frameId)
  if (refreshTimer) clearInterval(refreshTimer)
  window.removeEventListener('resize', handleResize)
  if (controls) controls.dispose()
  if (renderer) { renderer.dispose(); renderer.domElement?.remove() }
  scene?.traverse(obj => {
    if (obj.geometry) obj.geometry.dispose()
    if (obj.material) {
      if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose())
      else obj.material.dispose()
    }
  })
})
</script>

<style scoped>
.digital-twin-page {
  height: 100%; display: flex; flex-direction: column;
  background: var(--bg-base);
}

.dt-toolbar {
  display: flex; align-items: center; justify-content: space-between;
  padding: 10px 16px; background: var(--bg-surface);
  border-bottom: 1px solid var(--border-subtle);
  gap: 12px; flex-wrap: wrap;
}

.toolbar-left { display: flex; align-items: center; gap: 10px; }
.toolbar-title { font-size: 14px; font-weight: 600; color: var(--text-primary); margin: 0; letter-spacing: 0.5px; }
.toolbar-center { display: flex; align-items: center; }
.toolbar-right { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }

.action-btn {
  display: inline-flex; align-items: center; gap: 4px;
  padding: 5px 12px; border-radius: 6px;
  font-size: 12px; font-weight: 500; cursor: pointer;
  transition: all 0.2s; border: 1px solid;
  background: transparent; line-height: 1;
}

.action-btn:disabled {
  opacity: 0.6; cursor: not-allowed;
}

.action-btn:active:not(:disabled) {
  transform: scale(0.96);
}

.focus-btn {
  border-color: rgba(245,63,63,0.3); color: #F53F3F;
  background: rgba(245,63,63,0.06);
}

.focus-btn:hover:not(:disabled) {
  background: rgba(245,63,63,0.12); border-color: rgba(245,63,63,0.5);
  box-shadow: 0 2px 8px rgba(245,63,63,0.15);
}

.focus-btn.active {
  background: rgba(245,63,63,0.15); border-color: #F53F3F;
  animation: btnPulse 1.5s ease-in-out infinite;
}

.patrol-btn {
  border-color: rgba(255,125,0,0.3); color: #FF7D00;
  background: rgba(255,125,0,0.06);
}

.patrol-btn:hover:not(:disabled) {
  background: rgba(255,125,0,0.12); border-color: rgba(255,125,0,0.5);
  box-shadow: 0 2px 8px rgba(255,125,0,0.15);
}

.patrol-btn.active {
  background: rgba(255,125,0,0.15); border-color: #FF7D00;
  animation: btnPulse 1.5s ease-in-out infinite;
}

.replay-btn {
  border-color: rgba(22,93,255,0.3); color: #165DFF;
  background: rgba(22,93,255,0.06);
}

.replay-btn:hover:not(:disabled) {
  background: rgba(22,93,255,0.12); border-color: rgba(22,93,255,0.5);
  box-shadow: 0 2px 8px rgba(22,93,255,0.15);
}

.replay-btn.active {
  background: rgba(22,93,255,0.15); border-color: #165DFF;
  animation: btnPulse 1.5s ease-in-out infinite;
}

@keyframes btnPulse {
  0%, 100% { box-shadow: 0 0 0 0 rgba(22,93,255,0.2); }
  50% { box-shadow: 0 0 0 4px rgba(22,93,255,0.05); }
}

.dt-main {
  flex: 1; position: relative; overflow: hidden;
}

.scene-container {
  width: 100%; height: 100%;
}

.scene-overlay-top {
  position: absolute; top: 12px; left: 50%; transform: translateX(-50%);
  display: flex; align-items: center; gap: 16px;
  padding: 8px 16px; border-radius: var(--radius-md);
  background: rgba(245, 63, 63, 0.1); border: 1px solid rgba(245, 63, 63, 0.2);
  backdrop-filter: blur(8px); z-index: 10;
}

.fire-sim-badge {
  display: flex; align-items: center; gap: 6px;
  font-size: 13px; font-weight: 600; color: var(--accent-red);
}

.pulse-dot {
  width: 8px; height: 8px; border-radius: 50%;
  background: var(--accent-red); animation: pulse-dot 1s ease-in-out infinite;
}

.pulse-dot.red { background: #F53F3F; }
.pulse-dot.orange { background: #FF7D00; }

@keyframes pulse-dot {
  0%, 100% { opacity: 0.4; transform: scale(0.8); }
  50% { opacity: 1; transform: scale(1.2); }
}

.fire-sim-controls {
  display: flex; align-items: center; gap: 8px;
}

.sim-label { font-size: 11px; color: var(--text-muted); }

.focus-overlay {
  position: absolute; top: 12px; left: 50%; transform: translateX(-50%);
  padding: 8px 16px; border-radius: var(--radius-md);
  background: rgba(245, 63, 63, 0.1); border: 1px solid rgba(245, 63, 63, 0.2);
  backdrop-filter: blur(8px); z-index: 10;
}

.focus-badge {
  display: flex; align-items: center; gap: 6px;
  font-size: 13px; font-weight: 600; color: #F53F3F;
}

.patrol-overlay {
  position: absolute; top: 12px; left: 50%; transform: translateX(-50%);
  padding: 8px 16px; border-radius: var(--radius-md);
  background: rgba(255, 125, 0, 0.1); border: 1px solid rgba(255, 125, 0, 0.2);
  backdrop-filter: blur(8px); z-index: 10;
}

.patrol-badge {
  display: flex; align-items: center; gap: 6px;
  font-size: 13px; font-weight: 600; color: #FF7D00;
}

.patrol-controls {
  position: absolute; bottom: 16px; right: 16px;
  display: flex; gap: 6px; padding: 8px 12px;
  border-radius: var(--radius-md);
  background: rgba(18, 24, 38, 0.9); border: 1px solid var(--border-default);
  backdrop-filter: blur(8px); z-index: 10;
}

.ctrl-btn {
  width: 32px; height: 32px; border-radius: 6px;
  display: flex; align-items: center; justify-content: center;
  background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1);
  color: #94a3b8; cursor: pointer; transition: all 0.2s;
}

.ctrl-btn:hover {
  background: rgba(255,255,255,0.12); color: #fff;
}

.ctrl-btn.stop:hover {
  background: rgba(245,63,63,0.15); color: #F53F3F; border-color: rgba(245,63,63,0.3);
}

.scene-overlay-bottom {
  position: absolute; bottom: 16px; left: 50%; transform: translateX(-50%);
  width: 60%; max-width: 600px; padding: 10px 16px;
  border-radius: var(--radius-md); background: rgba(18, 24, 38, 0.9);
  border: 1px solid var(--border-default); backdrop-filter: blur(8px); z-index: 10;
}

.replay-controls {
  display: flex; align-items: center; gap: 8px;
}

.replay-speed {
  display: flex; gap: 2px;
}

.speed-btn {
  padding: 2px 6px; border-radius: 3px; font-size: 10px;
  background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.08);
  color: #94a3b8; cursor: pointer; transition: all 0.2s;
}

.speed-btn.active {
  background: rgba(22,93,255,0.15); color: #165DFF; border-color: rgba(22,93,255,0.3);
}

.speed-btn:hover {
  background: rgba(255,255,255,0.1); color: #fff;
}

.replay-time {
  font-size: 12px; color: var(--text-secondary);
  font-family: var(--font-num); white-space: nowrap; min-width: 80px;
}

.scene-info-panel, .facility-panel {
  position: absolute; top: 12px; right: 12px; width: 280px;
  padding: 14px; border-radius: var(--radius-md);
  background: rgba(18, 24, 38, 0.92); border: 1px solid var(--border-default);
  backdrop-filter: blur(10px); z-index: 10;
  animation: fadeSlideUp 0.25s var(--ease-out) both;
  max-height: 80vh; overflow-y: auto;
}

@keyframes fadeSlideUp {
  from { opacity: 0; transform: translateY(8px); }
  to { opacity: 1; transform: translateY(0); }
}

.info-header {
  display: flex; align-items: center; gap: 8px; margin-bottom: 10px;
}

.info-title { font-size: 14px; font-weight: 600; color: var(--text-primary); flex: 1; }

.exit-focus-btn {
  padding: 3px 10px; border-radius: 4px; font-size: 11px;
  background: rgba(245,63,63,0.1); border: 1px solid rgba(245,63,63,0.3);
  color: #F53F3F; cursor: pointer; transition: all 0.2s;
  white-space: nowrap;
}

.exit-focus-btn:hover {
  background: rgba(245,63,63,0.2); border-color: #F53F3F;
}

.info-body { display: flex; flex-direction: column; gap: 6px; }

.info-row {
  display: flex; justify-content: space-between; align-items: center;
  padding: 4px 0; border-bottom: 1px solid var(--border-subtle);
}

.info-row:last-child { border-bottom: none; }
.info-label { font-size: 12px; color: var(--text-muted); }
.info-val { font-size: 13px; font-weight: 500; color: var(--text-primary); font-family: var(--font-num); }

.info-divider {
  height: 1px; background: var(--border-subtle); margin: 6px 0;
}

.info-section { margin-top: 4px; }
.info-section-title { font-size: 12px; font-weight: 600; color: #165DFF; margin-bottom: 4px; }
.info-section-text { font-size: 12px; color: var(--text-secondary); line-height: 1.6; white-space: pre-line; }

.history-select-panel {
  position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
  width: 420px; padding: 20px; border-radius: 12px;
  background: rgba(18, 24, 38, 0.95); border: 1px solid var(--border-default);
  backdrop-filter: blur(16px); z-index: 20;
  animation: fadeSlideUp 0.3s var(--ease-out) both;
}

.panel-header {
  display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px;
}

.panel-header h4 { font-size: 16px; font-weight: 600; color: var(--text-primary); margin: 0; }

.panel-body { display: flex; flex-direction: column; gap: 14px; }

.panel-field label {
  display: block; font-size: 12px; color: var(--text-muted); margin-bottom: 6px;
}

.time-range-row {
  display: flex; align-items: center; gap: 8px;
}

.time-sep { font-size: 12px; color: var(--text-muted); }

.fps-counter {
  position: absolute; bottom: 12px; left: 12px;
  font-size: 11px; color: var(--text-faint);
  font-family: var(--font-num); z-index: 5;
}

:deep(.el-radio-button__inner) {
  background: var(--bg-elevated) !important; border-color: var(--border-default) !important;
  color: var(--text-muted) !important; font-size: 12px; padding: 5px 10px;
}
:deep(.el-radio-button__original-radio:checked + .el-radio-button__inner) {
  background: var(--accent-blue) !important; border-color: var(--accent-blue) !important; color: #fff !important;
}
:deep(.el-checkbox-button__inner) {
  background: var(--bg-elevated) !important; border-color: var(--border-default) !important;
  color: var(--text-muted) !important; font-size: 11px; padding: 4px 8px;
}
:deep(.el-checkbox-button__original-checkbox:checked + .el-checkbox-button__inner) {
  background: var(--accent-blue) !important; border-color: var(--accent-blue) !important; color: #fff !important;
}

@media (max-width: 768px) {
  .dt-toolbar { flex-direction: column; align-items: flex-start; }
  .toolbar-center, .toolbar-right { width: 100%; overflow-x: auto; }
  .scene-info-panel, .facility-panel { width: 200px; }
  .history-select-panel { width: 90%; }
}

.light-mode .dt-toolbar { background:#FFFFFF; border-bottom-color:#E5E6EB; }
.light-mode .toolbar-title { color:#1D2129; }
.light-mode .scene-overlay-top,
.light-mode .focus-overlay { background:rgba(245,63,63,0.06); border-color:rgba(245,63,63,0.15); }
.light-mode .patrol-overlay { background:rgba(255,125,0,0.06); border-color:rgba(255,125,0,0.15); }
.light-mode .scene-overlay-bottom { background:rgba(255,255,255,0.92); border-color:#E5E6EB; }
.light-mode .replay-time { color:#4E5969; }
.light-mode .scene-info-panel,
.light-mode .facility-panel { background:rgba(255,255,255,0.95); border-color:#E5E6EB; }
.light-mode .info-title { color:#1D2129; }
.light-mode .info-label { color:#86909C; }
.light-mode .info-val { color:#1D2129; }
.light-mode .info-section-title { color:#165DFF; }
.light-mode .info-section-text { color:#4E5969; }
.light-mode .sim-label { color:#86909C; }
.light-mode .fps-counter { color:#86909C; }
.light-mode .patrol-controls { background:rgba(255,255,255,0.92); border-color:#E5E6EB; }
.light-mode .ctrl-btn { background:rgba(0,0,0,0.04); border-color:#E5E6EB; color:#4E5969; }
.light-mode .ctrl-btn:hover { background:rgba(0,0,0,0.08); color:#1D2129; }
.light-mode .history-select-panel { background:rgba(255,255,255,0.96); border-color:#E5E6EB; }
.light-mode .panel-header h4 { color:#1D2129; }
.light-mode .focus-btn { border-color:rgba(245,63,63,0.2); color:#F53F3F; background:rgba(245,63,63,0.04); }
.light-mode .patrol-btn { border-color:rgba(255,125,0,0.2); color:#FF7D00; background:rgba(255,125,0,0.04); }
.light-mode .replay-btn { border-color:rgba(22,93,255,0.2); color:#165DFF; background:rgba(22,93,255,0.04); }
.light-mode :deep(.el-radio-button__inner) { background:#F7F8FA !important; border-color:#E5E6EB !important; color:#4E5969 !important; }
.light-mode :deep(.el-radio-button__original-radio:checked + .el-radio-button__inner) { background:#165DFF !important; border-color:#165DFF !important; color:#fff !important; }
.light-mode :deep(.el-checkbox-button__inner) { background:#F7F8FA !important; border-color:#E5E6EB !important; color:#4E5969 !important; }
.light-mode :deep(.el-checkbox-button__original-checkbox:checked + .el-checkbox-button__inner) { background:#165DFF !important; border-color:#165DFF !important; color:#fff !important; }
</style>
