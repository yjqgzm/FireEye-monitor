<template>
  <div :class="['alerts-page', { 'light-mode': isLightMode }]">
    <div class="page-hero">
      <div class="hero-pattern"></div>
      <div class="hero-content">
        <h1>预警记录</h1>
        <p>查看所有温度异常与烟雾预警事件，实现预警处置全闭环管理</p>
      </div>
    </div>

    <div class="stats-row">
      <div class="stat-card"><span class="stat-label">总预警数</span><span class="stat-value">{{ alerts.length }}</span></div>
      <div class="stat-card"><span class="stat-label">待处理</span><span class="stat-value" :class="{ danger: pendingCount > 0 }">{{ pendingCount }}</span></div>
      <div class="stat-card"><span class="stat-label">已处理</span><span class="stat-value success">{{ handledCount }}</span></div>
      <div class="stat-card"><span class="stat-label">紧急预警</span><span class="stat-value" :class="{ danger: urgentCount > 0 }">{{ urgentCount }}</span></div>
      <div class="stat-card"><span class="stat-label">处理及时率</span><span class="stat-value">{{ timelyRate }}%</span></div>
    </div>

    <div class="toolbar">
      <div class="toolbar-left">
        <el-input v-model="searchQuery" placeholder="搜索预警编号/设备名称" clearable style="width:180px">
          <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-select v-model="filterDevice" placeholder="选择设备" clearable @change="fetchAlerts" style="width:140px">
          <el-option v-for="d in devices" :key="d.id" :label="d.name" :value="d.id" />
        </el-select>
        <el-select v-model="filterLevel" placeholder="预警等级" clearable @change="fetchAlerts" style="width:120px">
          <el-option label="提示" :value="1" /><el-option label="警告" :value="2" /><el-option label="紧急" :value="3" />
        </el-select>
        <el-select v-model="filterStatus" placeholder="处理状态" clearable @change="fetchAlerts" style="width:120px">
          <el-option label="待处理" value="pending" /><el-option label="已处理" value="handled" /><el-option label="误报" value="false_alarm" />
        </el-select>
        <el-button @click="resetFilters" size="small">重置</el-button>
      </div>
      <div class="toolbar-right">
        <el-button @click="exportAlerts" plain size="small"><el-icon><Download /></el-icon> 导出</el-button>
        <el-radio-group v-model="viewMode" size="small">
          <el-radio-button label="card">卡片</el-radio-button>
          <el-radio-button label="list">列表</el-radio-button>
        </el-radio-group>
      </div>
    </div>

    <div class="quick-filters">
      <el-tag :class="['qf-tag', { active: quickFilter === '' }]" @click="quickFilter = ''">全部</el-tag>
      <el-tag :class="['qf-tag', { active: quickFilter === 'pending' }]" type="warning" @click="quickFilter = 'pending'">待处理</el-tag>
      <el-tag :class="['qf-tag', { active: quickFilter === 'handled' }]" type="success" @click="quickFilter = 'handled'">已处理</el-tag>
      <el-tag :class="['qf-tag', { active: quickFilter === 'urgent' }]" type="danger" @click="quickFilter = 'urgent'">紧急预警</el-tag>
      <el-tag :class="['qf-tag', { active: quickFilter === 'today' }]" @click="quickFilter = 'today'">今日预警</el-tag>
    </div>

    <div class="alerts-grid" v-if="viewMode === 'card'">
      <div v-for="(alert, idx) in filteredAlerts" :key="alert.id" :class="['alert-card', `alert-level-${alert.alert_level}`, { 'alert-pending': alert.status === 'pending', 'alert-handled': alert.status === 'handled', 'overtime': isOvertime(alert) }]" :style="{ animationDelay: `${idx * 0.03}s` }">
        <div class="alert-header">
          <el-tag :type="getAlertTagType(alert.alert_level)" size="small" effect="dark">{{ getAlertLevelName(alert.alert_level) }}</el-tag>
          <span class="alert-id">#{{ alert.id }}</span>
          <span class="alert-time">{{ formatTime(alert.created_at) }}</span>
          <el-tag v-if="alert.status === 'handled'" size="small" type="success" effect="plain">已处理</el-tag>
          <el-tag v-else-if="alert.status === 'pending'" size="small" type="danger" effect="dark" class="pending-tag">待处理</el-tag>
        </div>
        <div class="alert-main">
          <div class="alert-device">{{ alert.device_name }}</div>
          <div class="alert-desc">{{ alert.message }}</div>
          <div class="alert-data" v-if="alert.temperature">
            <span class="temp-num" :class="getTempClass(alert.temperature)">{{ alert.temperature?.toFixed(1) }}°C</span>
            <span class="rate-num" v-if="alert.temp_rise_rate">↑{{ alert.temp_rise_rate.toFixed(1) }}/min</span>
          </div>
          <div class="alert-ai" v-if="alert.ai_analysis">{{ alert.ai_analysis.slice(0, 60) }}...</div>
        </div>
        <div class="alert-actions">
          <el-button size="small" link type="primary" @click="viewDetail(alert)">详情</el-button>
          <el-button v-if="alert.status === 'pending'" size="small" link type="warning" @click="handleAlert(alert)">处置</el-button>
          <el-button v-if="alert.ai_analysis" size="small" link type="success" @click="currentAlert=alert; aiDialogVisible=true">AI分析</el-button>
          <el-button v-else-if="alert.alert_level >= 2" size="small" link type="success" @click="triggerAiAnalysis(alert)" :loading="analyzingId === alert.id">AI分析</el-button>
          <el-button size="small" link @click="locateTwin(alert)">定位孪生</el-button>
        </div>
      </div>
    </div>

    <div class="alerts-table" v-else>
      <el-table :data="filteredAlerts" size="small" style="width:100%"
        :header-cell-style="{ background:'var(--bg-elevated)', color:'var(--text-secondary)', borderColor:'var(--border-subtle)' }"
        :cell-style="{ background:'var(--bg-card)', borderColor:'var(--border-subtle)' }">
        <el-table-column label="等级" width="70">
          <template #default="{ row }"><el-tag :type="getAlertTagType(row.alert_level)" size="small" effect="dark">{{ getAlertLevelName(row.alert_level) }}</el-tag></template>
        </el-table-column>
        <el-table-column prop="device_name" label="设备名称" min-width="120" />
        <el-table-column label="温度" width="90">
          <template #default="{ row }"><span :class="getTempClass(row.temperature)">{{ row.temperature?.toFixed(1) || '--' }}°C</span></template>
        </el-table-column>
        <el-table-column prop="message" label="预警信息" min-width="160" show-overflow-tooltip />
        <el-table-column label="状态" width="80">
          <template #default="{ row }"><el-tag size="small" :type="row.status === 'handled' ? 'success' : 'danger'" effect="dark">{{ row.status === 'handled' ? '已处理' : '待处理' }}</el-tag></template>
        </el-table-column>
        <el-table-column label="时间" width="130">
          <template #default="{ row }">{{ formatTime(row.created_at) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <el-button size="small" link type="primary" @click="viewDetail(row)">详情</el-button>
            <el-button v-if="row.status === 'pending'" size="small" link type="warning" @click="handleAlert(row)">处置</el-button>
            <el-button v-if="row.ai_analysis" size="small" link type="success" @click="currentAlert=row; aiDialogVisible=true">AI分析</el-button>
            <el-button v-else-if="row.alert_level >= 2" size="small" link type="success" @click="triggerAiAnalysis(row)" :loading="analyzingId === row.id">AI分析</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <el-empty v-if="filteredAlerts.length === 0" description="暂无预警记录" />

    <el-dialog v-model="detailVisible" title="预警详情" width="550px">
      <div class="detail-panel" v-if="currentAlert">
        <div class="detail-row"><span class="detail-label">预警等级</span><el-tag :type="getAlertTagType(currentAlert.alert_level)" effect="dark">{{ getAlertLevelName(currentAlert.alert_level) }}</el-tag></div>
        <div class="detail-row"><span class="detail-label">设备名称</span><span class="detail-val">{{ currentAlert.device_name }}</span></div>
        <div class="detail-row"><span class="detail-label">触发温度</span><span :class="['detail-val', getTempClass(currentAlert.temperature)]">{{ currentAlert.temperature?.toFixed(1) || '--' }}°C</span></div>
        <div class="detail-row" v-if="currentAlert.temp_rise_rate"><span class="detail-label">温升速率</span><span class="detail-val">{{ currentAlert.temp_rise_rate.toFixed(1) }}°C/min</span></div>
        <div class="detail-row"><span class="detail-label">预警信息</span><span class="detail-val">{{ currentAlert.message }}</span></div>
        <div class="detail-row"><span class="detail-label">处理状态</span><el-tag :type="currentAlert.status === 'handled' ? 'success' : 'danger'" size="small">{{ currentAlert.status === 'handled' ? '已处理' : '待处理' }}</el-tag></div>
        <div class="detail-row" v-if="currentAlert.ai_analysis"><span class="detail-label">AI分析</span><span class="detail-val">{{ currentAlert.ai_analysis }}</span></div>
        <div class="detail-row" v-if="!currentAlert.ai_analysis && currentAlert.alert_level >= 2">
          <span class="detail-label">AI分析</span>
          <el-button size="small" type="success" @click="triggerAiAnalysis(currentAlert)" :loading="analyzingId === currentAlert?.id">触发AI分析</el-button>
        </div>
      </div>
      <template #footer>
        <el-button v-if="currentAlert?.status === 'pending'" type="primary" @click="handleAlert(currentAlert); detailVisible = false">一键处置</el-button>
        <el-button v-if="currentAlert?.ai_analysis" type="success" @click="detailVisible=false; aiDialogVisible=true">查看AI分析</el-button>
        <el-button @click="detailVisible = false">关闭</el-button>
      </template>
    </el-dialog>

    <el-dialog v-model="aiDialogVisible" title="AI智能分析" width="550px" destroy-on-close>
      <div class="ai-panel" v-if="currentAlert">
        <div class="ai-title">
          <el-tag size="large" :type="getAlertTagType(currentAlert.alert_level)" effect="dark">
            {{ currentAlert.alert_type === 'smoke_detected' ? '烟雾预警' : `${getAlertLevelName(currentAlert.alert_level)}预警` }}
          </el-tag>
          <span>{{ currentAlert.device_name }}</span>
        </div>
        <div class="ai-body" v-html="formatAiAnalysis(currentAlert.ai_analysis)"></div>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, inject } from 'vue'
import { useRouter } from 'vue-router'
import api from '@/api'
import { ElMessage } from 'element-plus'

const router = useRouter()
const isLightMode = inject('isLightMode', ref(false))
const alerts = ref([])
const devices = ref([])
const filterDevice = ref('')
const filterLevel = ref(null)
const filterStatus = ref('')
const searchQuery = ref('')
const quickFilter = ref('')
const viewMode = ref('card')
const detailVisible = ref(false)
const currentAlert = ref(null)
const analyzingId = ref(null)
const showAiFromDetail = ref(false)
const aiDialogVisible = ref(false)

const pendingCount = computed(() => alerts.value.filter(a => a.status === 'pending').length)
const handledCount = computed(() => alerts.value.filter(a => a.status === 'handled').length)
const urgentCount = computed(() => alerts.value.filter(a => a.alert_level === 3).length)
const timelyRate = computed(() => {
  const handled = alerts.value.filter(a => a.status === 'handled')
  if (!handled.length) return 100
  const timely = handled.filter(a => {
    if (!a.handled_at || !a.created_at) return true
    return new Date(a.handled_at) - new Date(a.created_at) < 30 * 60 * 1000
  })
  return Math.round(timely.length / handled.length * 100)
})

const filteredAlerts = computed(() => {
  return alerts.value.filter(a => {
    if (filterDevice.value && a.device_id !== filterDevice.value) return false
    if (filterLevel.value && a.alert_level !== filterLevel.value) return false
    if (filterStatus.value && a.status !== filterStatus.value) return false
    if (searchQuery.value) {
      const q = searchQuery.value.toLowerCase()
      if (!a.device_name?.toLowerCase().includes(q) && !String(a.id).includes(q)) return false
    }
    if (quickFilter.value === 'pending' && a.status !== 'pending') return false
    if (quickFilter.value === 'handled' && a.status !== 'handled') return false
    if (quickFilter.value === 'urgent' && a.alert_level !== 3) return false
    if (quickFilter.value === 'today') {
      const today = new Date().toDateString()
      if (new Date(a.created_at).toDateString() !== today) return false
    }
    return true
  }).sort((a, b) => {
    if (a.status === 'pending' && b.status !== 'pending') return -1
    if (a.status !== 'pending' && b.status === 'pending') return 1
    return b.alert_level - a.alert_level
  })
})

let refreshTimer = null

async function fetchAlerts() {
  try { alerts.value = await api.get('/api/alerts?limit=100') } catch (e) { console.error(e) }
}
async function fetchDevices() {
  try { devices.value = await api.get('/api/devices') } catch (e) { console.error(e) }
}

function resetFilters() {
  filterDevice.value = ''; filterLevel.value = null; filterStatus.value = ''; searchQuery.value = ''; quickFilter.value = ''
  fetchAlerts()
}

async function handleAlert(alert) {
  try { await api.put(`/api/alerts/${alert.id}/handle`, { status: 'handled', handling_notes: '已处置' }); ElMessage.success('处置成功'); fetchAlerts() } catch (e) { console.error(e) }
}

function viewDetail(alert) { currentAlert.value = alert; detailVisible.value = true; showAiFromDetail.value = false }
function locateTwin() { router.push('/twin') }

async function triggerAiAnalysis(alert) {
  analyzingId.value = alert.id
  try {
    const res = await api.post(`/api/alerts/${alert.id}/analyze`)
    if (res.ai_analysis) {
      alert.ai_analysis = res.ai_analysis
      currentAlert.value = { ...alert }
    } else {
      currentAlert.value = { ...alert, ai_analysis: res.message || 'AI分析暂无结果，请检查系统设置中的AI服务配置' }
    }
    aiDialogVisible.value = true
  } catch (e) {
    currentAlert.value = { ...alert, ai_analysis: e.response?.data?.detail || 'AI分析请求失败，请检查网络连接和AI服务配置' }
    aiDialogVisible.value = true
  } finally {
    analyzingId.value = null
  }
}

function formatAiAnalysis(text) {
  if (!text) return '<p style="color:#86909c">暂无分析结果</p>'
  let html = text
    .replace(/```[\s\S]*?```/g, m => m.replace(/```\w*\n?/g, '').replace(/```/g, ''))
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/#{1,3}\s+(.*)/g, '<strong style="font-size:14px">$1</strong>')
    .replace(/\n/g, '<br>')
  return html
}

function isOvertime(alert) {
  if (alert.status !== 'pending') return false
  return new Date() - new Date(alert.created_at) > 30 * 60 * 1000
}

function exportAlerts() {
  const data = filteredAlerts.value.map(a => ({ 编号: a.id, 设备: a.device_name, 等级: getAlertLevelName(a.alert_level), 温度: a.temperature?.toFixed(1), 信息: a.message, 状态: a.status === 'handled' ? '已处理' : '待处理', 时间: formatTime(a.created_at) }))
  const csv = [Object.keys(data[0]).join(','), ...data.map(r => Object.values(r).join(','))].join('\n')
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a'); a.href = url; a.download = 'alerts.csv'; a.click(); URL.revokeObjectURL(url)
}

function getAlertLevelName(level) { return { 1: '提示', 2: '警告', 3: '紧急' }[level] || '未知' }
function getAlertTagType(level) { return { 1: 'info', 2: 'warning', 3: 'danger' }[level] || 'info' }
function getTempClass(temp) { if (!temp) return ''; if (temp >= 80) return 'danger'; if (temp >= 60) return 'warning'; if (temp >= 45) return 'caution'; return 'normal' }
function formatTime(timeStr) { if (!timeStr) return ''; return new Date(timeStr).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }) }

onMounted(() => { fetchAlerts(); fetchDevices(); refreshTimer = setInterval(fetchAlerts, 5000) })
onUnmounted(() => { if (refreshTimer) clearInterval(refreshTimer) })
</script>

<style scoped>
.alerts-page { height:100%; overflow-y:auto; }

.page-hero {
  position:relative; height:100px; border-radius:var(--radius-md);
  overflow:hidden; margin-bottom:16px;
  background:linear-gradient(135deg, #121826, #2a1520, #1a1028);
  animation:fade-in-up 0.4s var(--ease-out) both;
}
.hero-pattern { position:absolute; inset:0; background-image:radial-gradient(circle at 80% 20%, rgba(245,63,63,0.08) 0%, transparent 50%); }
.hero-content { position:relative; z-index:1; padding:24px 28px; display:flex; flex-direction:column; justify-content:flex-end; height:100%; }
.hero-content h1 { font-size:22px; font-weight:700; color:var(--text-primary); margin:0 0 2px 0; letter-spacing:2px; }
.hero-content p { font-size:13px; color:var(--text-secondary); margin:0; }

.stats-row { display:grid; grid-template-columns:repeat(5, 1fr); gap:10px; margin-bottom:14px; }
.stat-card {
  display:flex; flex-direction:column; align-items:center; gap:4px;
  padding:10px 12px; border-radius:var(--radius-md);
  background:var(--bg-card); border:1px solid var(--border-subtle);
  animation:fade-in-up 0.4s var(--ease-out) both;
}
.stat-label { font-size:10px; color:var(--text-muted); text-align:center; }
.stat-value { font-size:18px; font-weight:700; color:var(--text-primary); font-family:var(--font-num); }
.stat-value.danger { color:#F53F3F; }
.stat-value.success { color:#00B42A; }

.toolbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; gap:8px; flex-wrap:wrap; }
.toolbar-left { display:flex; align-items:center; gap:6px; flex-wrap:wrap; }
.toolbar-right { display:flex; align-items:center; gap:6px; }

.quick-filters { display:flex; gap:6px; margin-bottom:14px; }
.qf-tag { cursor:pointer; transition:all var(--dur-fast) var(--ease-out); }
.qf-tag.active { box-shadow:0 0 0 1px var(--accent-blue); }

.alerts-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(320px, 1fr)); gap:10px; }

.alert-card {
  background:var(--bg-card); border:1px solid var(--border-subtle);
  border-radius:var(--radius-md); padding:12px 14px;
  border-left:3px solid transparent;
  transition:all var(--dur-fast) var(--ease-out);
  animation:fade-in-up 0.4s var(--ease-out) both;
}
.alert-card:hover { border-color:var(--border-default); transform:translateY(-1px); box-shadow:var(--shadow-md); }

.alert-card.alert-level-1 { border-left-color:#165DFF; }
.alert-card.alert-level-2 { border-left-color:#FF7D00; }
.alert-card.alert-level-3 { border-left-color:#F53F3F; }
.alert-card.alert-pending.alert-level-3 { animation:breathe-high 0.8s ease-in-out infinite; }
.alert-card.alert-handled { opacity:0.45; }
.alert-card.overtime { animation:alert-border-pulse 1s ease-in-out infinite !important; }

.alert-header { display:flex; align-items:center; gap:6px; margin-bottom:8px; flex-wrap:wrap; }
.alert-id { font-size:10px; color:var(--text-faint); font-family:var(--font-num); }
.alert-time { font-size:10px; color:var(--text-muted); margin-left:auto; }
.pending-tag { animation:pulse-dot 1.5s ease-in-out infinite; }

.alert-main { margin-bottom:8px; }
.alert-device { font-size:14px; font-weight:600; color:var(--text-primary); margin-bottom:3px; }
.alert-desc { font-size:12px; color:var(--text-secondary); line-height:1.4; margin-bottom:4px; }
.alert-data { display:flex; gap:8px; font-size:12px; font-variant-numeric:tabular-nums; }
.temp-num { font-weight:600; font-family:var(--font-num); }
.temp-num.normal { color:#00B42A; }
.temp-num.cautio { color:#165DFF; }
.temp-num.warning { color:#FF7D00; }
.temp-num.danger { color:#F53F3F; }
.rate-num { color:var(--text-muted); font-family:var(--font-num); }
.alert-ai { font-size:11px; color:var(--accent-cyan); margin-top:4px; }

.alert-actions { display:flex; justify-content:flex-end; gap:4px; }

.detail-panel { display:flex; flex-direction:column; gap:10px; }
.detail-row { display:flex; justify-content:space-between; align-items:center; padding:6px 0; border-bottom:1px solid var(--border-subtle); }
.detail-row:last-child { border-bottom:none; }
.detail-label { font-size:13px; color:var(--text-muted); }
.detail-val { font-size:13px; font-weight:500; color:var(--text-primary); }

.normal { color:#00B42A; }
.cautio { color:#165DFF; }
.warning { color:#FF7D00; }
.danger { color:#F53F3F; }

:deep(.el-table) { --el-table-border-color: var(--border-subtle); --el-table-header-bg-color: var(--bg-elevated); --el-table-row-hover-bg-color: var(--bg-hover); --el-table-bg-color: var(--bg-card); --el-table-tr-bg-color: var(--bg-card); color: var(--text-primary); }

@keyframes fade-in-up { from { opacity:0; transform:translateY(12px); } to { opacity:1; transform:translateY(0); } }
@keyframes breathe-high { 0%,100% { box-shadow:inset 0 0 0 0 transparent; } 50% { box-shadow:inset 0 0 20px rgba(245,63,63,0.04); } }
@keyframes alert-border-pulse { 0%,100% { border-color:var(--border-default); } 50% { border-color:#F53F3F; } }
@keyframes pulse-dot { 0%,100% { transform:scale(1); } 50% { transform:scale(1.1); opacity:0.7; } }

@media (max-width:768px) { .stats-row { grid-template-columns:repeat(3, 1fr); } .alerts-grid { grid-template-columns:1fr; } .toolbar { flex-direction:column; } }

.light-mode .page-hero { background:linear-gradient(135deg, #FDE8E8, #FCE4D6, #FBE0E8); }
.light-mode .hero-content h1 { color:#1D2129; }
.light-mode .hero-content p { color:#4E5969; }
.light-mode .stat-card { background:#FFFFFF; border-color:#E5E6EB; }
.light-mode .stat-label { color:#86909C; }
.light-mode .stat-value { color:#1D2129; }
.light-mode .alert-card { background:#FFFFFF; border-color:#E5E6EB; }
.light-mode .alert-card:hover { border-color:#C9CDD4; }
.light-mode .alert-device { color:#1D2129; }
.light-mode .alert-desc { color:#4E5969; }
.light-mode .alert-id { color:#86909C; }
.light-mode .alert-time { color:#86909C; }
.light-mode .rate-num { color:#86909C; }
.light-mode .detail-label { color:#86909C; }
.light-mode .detail-val { color:#1D2129; }
.light-mode .detail-row { border-bottom-color:#E5E6EB; }
.light-mode .qf-tag { background:#F2F3F5; border-color:#E5E6EB; color:#4E5969; }
.light-mode .qf-tag.active { box-shadow:0 0 0 1px #165DFF; background:rgba(22,93,255,0.06); color:#165DFF; }
.light-mode :deep(.el-table) { --el-table-bg-color:#FFFFFF; --el-table-tr-bg-color:#FFFFFF; --el-table-header-bg-color:#F7F8FA; --el-table-row-hover-bg-color:#F2F3F5; --el-table-border-color:#E5E6EB; color:#1D2129; }
.light-mode :deep(.el-table th.el-table__cell) { color:#4E5969; }

.ai-panel { padding:8px 0; }
.ai-title { display:flex; align-items:center; gap:12px; margin-bottom:16px; font-size:15px; font-weight:600; color:var(--text-primary); }
.ai-body { background:var(--bg-secondary); border-radius:8px; padding:16px; font-size:13px; line-height:1.8; color:var(--text-primary); white-space:pre-wrap; }
</style>
