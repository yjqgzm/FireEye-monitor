import axios from 'axios'
import { ElMessage } from 'element-plus'
import { useUserStore } from '@/stores/user'

const api = axios.create({
  baseURL: '',
  timeout: 30000
})

api.interceptors.request.use(
  config => {
    const userStore = useUserStore()
    if (userStore.token) {
      config.headers.Authorization = `Bearer ${userStore.token}`
    }
    return config
  },
  error => Promise.reject(error)
)

api.interceptors.response.use(
  response => response.data,
  error => {
    if (error.response) {
      const status = error.response.status
      const message = error.response.data?.detail || '请求失败'
      const silent = error.config?.silent

      if (!silent) {
        if (status === 401) {
          const userStore = useUserStore()
          userStore.logout()
          window.location.href = '/login'
          ElMessage.error('登录已过期，请重新登录')
        } else if (status === 403) {
          ElMessage.error('权限不足')
        } else if (status === 404) {
        } else if (status >= 500) {
          ElMessage.error('服务器错误')
        } else {
          ElMessage.error(message)
        }
      }
    } else if (!error.config?.silent) {
      ElMessage.error('网络连接失败')
    }
    return Promise.reject(error)
  }
)

export default api
