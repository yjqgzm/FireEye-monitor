import { describe, it, expect, vi, beforeEach } from 'vitest'

const mockUse = vi.fn()

vi.mock('axios', () => {
  return {
    default: {
      create: vi.fn(() => ({
        interceptors: {
          request: { use: vi.fn() },
          response: { use: vi.fn() }
        },
        get: vi.fn(),
        post: vi.fn(),
        defaults: { baseURL: '', timeout: 30000 }
      })),
      interceptors: {
        request: { use: mockUse },
        response: { use: mockUse }
      }
    }
  }
})

describe('API Module', () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  it('creates axios instance with correct config', async () => {
    const { default: api } = await import('./index.js')
    expect(api).toBeDefined()
  })

  it('exports an axios instance', async () => {
    const { default: api } = await import('./index.js')
    expect(typeof api).toBe('object')
  })

  it('has request and response methods', async () => {
    const { default: api } = await import('./index.js')
    expect(api.interceptors).toBeDefined()
    expect(api.interceptors.request).toBeDefined()
    expect(api.interceptors.response).toBeDefined()
  })
})
