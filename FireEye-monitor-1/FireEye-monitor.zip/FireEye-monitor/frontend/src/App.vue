/**
 * 火睛智控中心
 * 版权所有：四川职业技术学院 yangming、shahaigui、yanshiyi、qixuding
 * 联系邮箱：2551230793@qq.com
 * 协议：AGPL-3.0，禁止闭源商用
 */

<template>
  <div :class="['app-root', { 'anim-mute': animMuted, 'light-mode': isLightMode }]" :style="{ '--app-font-size': fontSize + 'px' }">
    <div class="app-loading" v-if="appLoading">
      <div class="loading-brand">
        <div class="loading-logo">
          <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
            <circle cx="20" cy="20" r="18" stroke="var(--accent-blue)" stroke-width="1.5" stroke-dasharray="6 4" class="loading-ring" />
            <circle cx="20" cy="20" r="8" fill="var(--accent-blue)" opacity="0.2" />
            <circle cx="20" cy="20" r="4" fill="var(--accent-blue)" class="loading-core" />
          </svg>
        </div>
        <span class="loading-text">火睛智控中心</span>
      </div>
      <div class="loading-bar"><div class="loading-bar-inner"></div></div>
    </div>
    <router-view v-slot="{ Component }" v-else>
      <transition name="page-fade" mode="out-in">
        <component :is="Component" />
      </transition>
    </router-view>
    <div class="anim-mute-toggle" @click="toggleAnimMute" :title="animMuted ? '开启动效' : '静音动效'">
      <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
        <path v-if="!animMuted" d="M2 4h3l4-3v14l-4-3H2V4zm10 3.5a3.5 3.5 0 010 1v-1zm2-3a6.5 6.5 0 010 7v-7z"/>
        <path v-else d="M2 4h3l4-3v14l-4-3H2V4zm11 4L10.5 9.5M10.5 6.5L13 8"/>
      </svg>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, provide } from 'vue'
import { useUserStore } from '@/stores/user'

const userStore = useUserStore()
const appLoading = ref(true)
const animMuted = ref(false)
const fontSize = ref(14)
const isLightMode = ref(false)

provide('animMuted', animMuted)
provide('isLightMode', isLightMode)

function applyFontSize(val) {
  document.documentElement.style.setProperty('--app-font-size', val + 'px')
  document.documentElement.style.fontSize = val + 'px'
  const zoom = val / 14
  document.documentElement.style.setProperty('--app-zoom', zoom)
  document.querySelector('.app-root').style.zoom = zoom
  localStorage.setItem('fontSize', val)
}

function toggleAnimMute() {
  animMuted.value = !animMuted.value
  localStorage.setItem('animMuted', animMuted.value ? '1' : '0')
}

onMounted(() => {
  if (userStore.token) {
    userStore.fetchUserInfo()
  }
  const savedFontSize = localStorage.getItem('fontSize')
  if (savedFontSize) {
    fontSize.value = parseInt(savedFontSize)
    applyFontSize(fontSize.value)
  }
  const savedMute = localStorage.getItem('animMuted')
  if (savedMute === '1') animMuted.value = true
  const savedTheme = localStorage.getItem('themeMode')
  if (savedTheme === 'light') isLightMode.value = true
  setTimeout(() => { appLoading.value = false }, 800)
})
</script>

<style>
:root {
  --app-font-size: 14px;
  --bg-base: #121826;
  --bg-surface: #171e2e;
  --bg-elevated: #1c2438;
  --bg-card: #1e2740;
  --bg-hover: #252e48;
  --bg-base-rgb: 18,24,38;
  --border-subtle: rgba(148,163,184,0.06);
  --border-default: rgba(148,163,184,0.1);
  --border-strong: rgba(148,163,184,0.16);
  --text-primary: #f1f5f9;
  --text-secondary: #94a3b8;
  --text-muted: #64748b;
  --text-faint: #475569;
  --accent-blue: #165DFF;
  --accent-blue-light: #4080FF;
  --accent-blue-dim: rgba(22,93,255,0.12);
  --accent-cyan: #0FC6C2;
  --accent-cyan-dim: rgba(15,198,194,0.1);
  --accent-orange: #FF7D00;
  --accent-orange-dim: rgba(255,125,0,0.1);
  --accent-yellow: #FFAA00;
  --accent-yellow-dim: rgba(255,170,0,0.1);
  --accent-red: #F53F3F;
  --accent-red-dim: rgba(245,63,63,0.1);
  --accent-green: #00B42A;
  --accent-green-dim: rgba(0,180,42,0.1);
  --radius-sm: 4px;
  --radius-md: 8px;
  --shadow-sm: 0 1px 2px rgba(0,0,0,0.3);
  --shadow-md: 0 4px 12px rgba(0,0,0,0.25);
  --shadow-lg: 0 8px 30px rgba(0,0,0,0.35);
  --ease-out: cubic-bezier(0.22,1,0.36,1);
  --ease-in-out: cubic-bezier(0.4,0,0.2,1);
  --font-num: 'SF Mono','Fira Code','Consolas','Menlo',monospace;
  --font-sans: 'Inter',-apple-system,BlinkMacSystemFont,'Noto Sans SC','Source Han Sans SC','Segoe UI',Roboto,sans-serif;
  --dur-fast: 200ms;
  --dur-normal: 300ms;
  --dur-slow: 500ms;
}

* { margin:0; padding:0; box-sizing:border-box; }

html, body, #app {
  width:100%; height:100%;
  font-family: var(--font-sans);
  font-size: var(--app-font-size);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.app-root {
  font-size: var(--app-font-size);
}

.app-root h1 { font-size: calc(var(--app-font-size) * 1.75); }
.app-root h2 { font-size: calc(var(--app-font-size) * 1.5); }
.app-root h3 { font-size: calc(var(--app-font-size) * 1.25); }
.app-root h4 { font-size: calc(var(--app-font-size) * 1.1); }
.app-root h5 { font-size: var(--app-font-size); }
.app-root small, .app-root .text-sm { font-size: calc(var(--app-font-size) * 0.857); }
.app-root .text-xs { font-size: calc(var(--app-font-size) * 0.75); }
.app-root .text-lg { font-size: calc(var(--app-font-size) * 1.143); }
.app-root .text-xl { font-size: calc(var(--app-font-size) * 1.286); }

body {
  background: var(--bg-base);
  color: var(--text-primary);
  background-image:
    radial-gradient(circle at 20% 80%, rgba(22,93,255,0.015) 0%, transparent 50%),
    radial-gradient(circle at 80% 20%, rgba(15,198,194,0.01) 0%, transparent 50%);
}

.app-root { width:100%; height:100%; position:relative; }

.app-loading {
  position:fixed; inset:0; z-index:9999;
  background: var(--bg-base);
  display:flex; flex-direction:column;
  align-items:center; justify-content:center;
  gap:28px;
}

.loading-brand {
  display:flex; flex-direction:column; align-items:center;
  gap:16px;
}

.loading-logo {
  position:relative;
}

.loading-ring {
  animation: spin 3s linear infinite;
  transform-origin: center;
  opacity:0.7;
}

.loading-core {
  opacity:0.85;
}

@keyframes spin { to { transform: rotate(360deg); } }

.loading-text {
  font-size:18px; font-weight:600; letter-spacing:6px;
  color: var(--text-primary);
  opacity:0.8;
}

.loading-bar {
  width:180px; height:3px; border-radius:2px;
  background: var(--border-subtle); overflow:hidden;
}

.loading-bar-inner {
  width:40%; height:100%; border-radius:2px;
  background: linear-gradient(90deg, var(--accent-blue), var(--accent-cyan));
  animation: loadingFlow 2.4s ease-in-out infinite;
}

@keyframes loadingFlow {
  0% { transform:translateX(-100%); opacity:0.3; }
  20% { opacity:1; }
  80% { opacity:1; }
  100% { transform:translateX(260%); opacity:0.3; }
}

.page-fade-enter-active { transition: opacity 0.25s var(--ease-out); }
.page-fade-leave-active { transition: opacity 0.15s var(--ease-in-out); }
.page-fade-enter-from, .page-fade-leave-to { opacity:0; }

.anim-mute-toggle {
  position:fixed; bottom:16px; right:16px; z-index:9998;
  width:32px; height:32px; border-radius:var(--radius-sm);
  background:var(--bg-elevated); border:1px solid var(--border-default);
  display:flex; align-items:center; justify-content:center;
  cursor:pointer; color:var(--text-muted);
  transition:all var(--dur-fast) var(--ease-in-out);
  opacity:0.5;
}

.anim-mute-toggle:hover {
  opacity:1; color:var(--accent-blue); border-color:var(--accent-blue-dim);
  background:var(--accent-blue-dim);
}

::-webkit-scrollbar { width:5px; height:5px; }
::-webkit-scrollbar-track { background:transparent; }
::-webkit-scrollbar-thumb { background:rgba(148,163,184,0.12); border-radius:4px; }
::-webkit-scrollbar-thumb:hover { background:rgba(148,163,184,0.2); }

.el-menu { border-right:none !important; background:transparent !important; }
.el-menu-item { background:transparent !important; }

@keyframes breathe-low {
  0%,100% { opacity:0.6; border-color:var(--accent-blue); }
  50% { opacity:1; border-color:var(--accent-blue-light); }
}

@keyframes breathe-mid {
  0%,100% { box-shadow:0 0 0 0 transparent; transform:scale(1); }
  50% { box-shadow:0 0 8px 2px var(--accent-orange-dim); transform:scale(1.01); }
}

@keyframes breathe-high {
  0%,100% { box-shadow:inset 0 0 0 0 transparent, 0 0 0 0 transparent; }
  50% { box-shadow:inset 0 0 30px rgba(245,63,63,0.06), 0 0 12px rgba(245,63,63,0.08); }
}

@keyframes alert-border-pulse {
  0%,100% { border-color:var(--accent-red); }
  50% { border-color:transparent; }
}

@keyframes value-flash {
  0% { background:transparent; }
  30% { background:var(--accent-red-dim); }
  100% { background:transparent; }
}

@keyframes slide-in-top {
  from { transform:translateY(-100%); opacity:0; }
  to { transform:translateY(0); opacity:1; }
}

@keyframes fade-in-up {
  from { opacity:0; transform:translateY(12px); }
  to { opacity:1; transform:translateY(0); }
}

@keyframes fadeSlideUp {
  from { opacity:0; transform:translateY(16px); }
  to { opacity:1; transform:translateY(0); }
}

@keyframes edge-red-pulse {
  0%,100% { box-shadow:inset 0 0 60px rgba(245,63,63,0.03); }
  50% { box-shadow:inset 0 0 60px rgba(245,63,63,0.08); }
}

.alert-level-1 { animation:breathe-low 2s ease-in-out infinite; }
.alert-level-2 { animation:breathe-mid 1s ease-in-out infinite; }
.alert-level-3 { animation:breathe-high 0.8s ease-in-out infinite; }

.anim-mute .alert-level-1,
.anim-mute .alert-level-2,
.anim-mute .alert-level-3 { animation:none !important; }

.anim-mute * {
  animation-duration:0.01ms !important;
  transition-duration:0.01ms !important;
}

.anim-mute .app-loading,
.anim-mute .loading-ring,
.anim-mute .loading-core,
.anim-mute .loading-bar-inner {
  animation-duration:inherit !important;
}

@media (min-width:2560px) {
  :root { --app-font-size:16px; }
}

@media (max-width:768px) {
  :root { --app-font-size:13px; }
  .anim-mute-toggle { bottom:8px; right:8px; width:28px; height:28px; }
}

.light-mode {
  --bg-base: #F7F8FA;
  --bg-surface: #FFFFFF;
  --bg-elevated: #F2F3F5;
  --bg-card: #FFFFFF;
  --bg-hover: #E8E9EB;
  --bg-base-rgb: 247,248,250;
  --border-subtle: rgba(0,0,0,0.06);
  --border-default: rgba(0,0,0,0.1);
  --border-strong: rgba(0,0,0,0.16);
  --text-primary: #1D2129;
  --text-secondary: #272E3B;
  --text-muted: #4E5969;
  --text-faint: #86909C;
  --shadow-sm: 0 1px 2px rgba(0,0,0,0.06);
  --shadow-md: 0 4px 12px rgba(0,0,0,0.08);
  --shadow-lg: 0 8px 30px rgba(0,0,0,0.1);
}

.light-mode body {
  background: #F7F8FA;
  background-image: none;
}

.light-mode .el-menu { background:#FFFFFF !important; }
.light-mode .el-menu-item { color:#4E5969 !important; }
.light-mode .el-menu-item:hover { background:#F2F3F5 !important; color:#1D2129 !important; }
.light-mode .el-menu-item.is-active { color:#165DFF !important; background:rgba(22,93,255,0.06) !important; }

.light-mode .el-table { --el-table-bg-color: #FFFFFF; --el-table-tr-bg-color: #FFFFFF; --el-table-header-bg-color: #F7F8FA; --el-table-row-hover-bg-color: #F2F3F5; --el-table-border-color: rgba(0,0,0,0.06); color: #1D2129; }
.light-mode .el-table th.el-table__cell { color: #4E5969; }

.light-mode .el-tag--info { background:#F2F3F5 !important; border-color:#E5E6EB !important; color:#4E5969 !important; }
.light-mode .el-input__wrapper { background:#FFFFFF !important; box-shadow:0 0 0 1px rgba(0,0,0,0.1) inset !important; }
.light-mode .el-input__inner { color:#1D2129 !important; }
.light-mode .el-select__wrapper { background:#FFFFFF !important; box-shadow:0 0 0 1px rgba(0,0,0,0.1) inset !important; }
.light-mode .el-radio-button__inner { background:#F2F3F5 !important; border-color:#E5E6EB !important; color:#4E5969 !important; }
.light-mode .el-checkbox-button__inner { background:#F2F3F5 !important; border-color:#E5E6EB !important; color:#4E5969 !important; }
.light-mode .el-pagination { --el-pagination-bg-color: #FFFFFF; --el-pagination-text-color: #4E5969; --el-pagination-button-bg-color: #F2F3F5; }
.light-mode .el-empty__description p { color:#86909C; }
.light-mode .el-dialog { background:#FFFFFF !important; }
.light-mode .el-dialog__title { color:#1D2129 !important; }
.light-mode .el-dialog__body { color:#272E3B !important; }

</style>
