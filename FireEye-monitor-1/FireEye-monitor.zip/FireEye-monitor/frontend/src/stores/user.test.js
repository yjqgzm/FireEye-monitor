import { setActivePinia, createPinia } from 'pinia'
import { describe, it, expect, beforeEach, vi } from 'vitest'
import { useUserStore } from '@/stores/user'

describe('useUserStore', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    localStorage.clear()
  })

  it('initial state has no token', () => {
    const store = useUserStore()
    expect(store.token).toBe('')
    expect(store.user).toBeNull()
    expect(store.isLoggedIn).toBe(false)
    expect(store.isAdmin).toBe(false)
  })

  it('isLoggedIn is true when token exists', () => {
    const store = useUserStore()
    store.token = 'test-token'
    expect(store.isLoggedIn).toBe(true)
  })

  it('isAdmin is true when user role is admin', () => {
    const store = useUserStore()
    store.user = { role: 'admin' }
    expect(store.isAdmin).toBe(true)
  })

  it('isInvited is true when user is_invited', () => {
    const store = useUserStore()
    store.user = { is_invited: true }
    expect(store.isInvited).toBe(true)
  })

  it('logout clears token and user', () => {
    const store = useUserStore()
    store.token = 'test-token'
    store.user = { username: 'admin', role: 'admin' }
    localStorage.setItem('token', 'test-token')

    store.logout()

    expect(store.token).toBe('')
    expect(store.user).toBeNull()
    expect(localStorage.getItem('token')).toBeNull()
  })

  it('restores token from localStorage on init', () => {
    localStorage.setItem('token', 'saved-token')
    const store = useUserStore()
    expect(store.token).toBe('saved-token')
  })
})
