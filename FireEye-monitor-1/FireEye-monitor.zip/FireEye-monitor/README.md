[English](README_en.md) | 中文

## 版权声明

本项目著作权归以下作者共同所有：
- 第一作者：四川职业技术学院 yangming
- 其他作者：四川职业技术学院 shahaigui、yanshiyi、qixuding

未经作者书面许可，禁止删除、篡改本版权声明。联系邮箱：2551230793@qq.com

---

> ⚠️ **协议警告：AGPL-3.0，禁止公司闭源商用，个人/学校可自由使用**

# 火睛智控中心

**FireGuard Intelligent Control Center** — 集成温度、湿度、烟雾、气体与多源环境数据的智能火灾风险感知与预警平台。

## 这是什么？

火睛智控中心是一套面向中小型场所（实验室、宿舍、仓库、商铺、配电房）的智能消防预警系统。它通过 WiFi 红外测温传感器持续采集环境数据，结合分级预警算法和 AI 智能分析，在火灾阴燃阶段即可发出预警，将传统"事后报警"升级为"事前预判"。

## 核心功能

- 🌡️ **多源数据融合感知** — 温度、湿度、烟雾、气体统一接入，打破信息孤岛
- 🚨 **三级分级预警体系** — 提示→警告→紧急，按场景差异化配置阈值，精准分级
- 🤖 **AI 智能研判分析** — 对接国产大模型，自动生成风险概率评估与应急建议
- 🏗️ **3D 数字孪生可视化** — Three.js 构建建筑场景，支持风险聚焦、火灾蔓延模拟、历史回溯
- 📱 **移动端 PWA 支持** — 手机浏览器打开即用，可添加到主屏幕像原生 APP 一样运行
- 🔐 **邀请码权限体系** — 管理员/会员/基础用户三级权限，灵活管控
- 📊 **实时监控大屏** — ECharts 可视化，传感器趋势、频谱监控、预警流一站式呈现
- 🔄 **预警全闭环管理** — 从触发到处置到 AI 分析，完整处置链路

## 技术栈

| 层级 | 技术 |
|------|------|
| 前端 | Vue 3 + Element Plus + ECharts + Three.js |
| 后端 | FastAPI + SQLAlchemy 2.0 + SQLite + slowapi |
| AI | 智谱GLM / 通义千问 / DeepSeek / 文心一言 / OpenAI |
| 硬件 | ESP32 + MLX90614（兼容所有 WiFi 传感器） |
| 移动端 | Vue 3 + Element Plus + ECharts（PWA） |

## 快速开始

👉 详见 [快速开始.md](./快速开始.md)

5 分钟本地跑起来：装好 Node.js 和 Python → 安装依赖 → 配置环境变量 → 启动后端 → 启动前端 → 浏览器打开。

## 目录结构

```
├── frontend/            # PC端前端源码
├── backend/             # 后端源码
│   ├── routers/         #   API路由模块（9个）
│   └── tests/           #   单元测试（70个用例）
├── mobile-app/          # 移动端PWA源码
├── hardware_firmware/   # 传感器固件（Arduino）
├── .github/             # CI/CD + 社区模板
├── docker-compose.yml   # Docker一键部署
├── 启动系统.py           # 一键启动脚本
├── LICENSE              # AGPL-3.0 协议
├── README.md            # 本文件
├── 快速开始.md           # 5分钟上手指南
├── 系统介绍.md           # 功能详解
├── 部署指南.md           # 生产环境部署
├── 硬件接入指南.md       # 传感器接入教程
├── 功能配置手册.md       # AI/阈值/权限/环境变量配置
├── 常见问题.md           # FAQ
├── 开源协议说明.md       # AGPL 大白话解读
├── 目录结构说明.md       # 文件说明
└── 移动端使用指南.md     # 手机端教程
```

## 联系方式

- 邮箱：2551230793@qq.com
- 如需商业授权，请联系第一作者

## 快速体验（Docker）

如果你已安装 Docker，一条命令即可启动全栈：

```bash
docker-compose up -d
```

启动后访问：

- 前端界面：http://localhost:3000
- 后端 API 文档：http://localhost:18889/docs

停止服务：

```bash
docker-compose down
```

## 社区与贡献

我们欢迎任何形式的贡献！请阅读以下指南：

- [贡献指南](./CONTRIBUTING.md) — 如何提交 Issue 和 Pull Request
- [行为准则](./CODE_OF_CONDUCT.md) — 社区行为规范
- [安全策略](./SECURITY.md) — 安全漏洞报告方式


> 版权所有：四川职业技术学院 yangming、shahaigui、yanshiyi、qixuding | 联系：2551230793@qq.com
