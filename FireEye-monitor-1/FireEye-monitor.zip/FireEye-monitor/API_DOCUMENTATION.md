# API Documentation

## Overview

FireGuard API is a RESTful API built with FastAPI. The API provides endpoints for managing fire detection devices, sensors, alerts, users, and system configuration.

## API Documentation URLs

When the backend server is running, you can access the API documentation at:

- **Swagger UI**: http://localhost:18889/docs
- **ReDoc**: http://localhost:18889/redoc
- **OpenAPI Schema**: http://localhost:18889/openapi.json

## Authentication

All API endpoints (except login and register) require authentication using JWT tokens.

### Getting a Token

```bash
POST /api/auth/login
Content-Type: application/json

{
  "username": "admin@example.com",
  "password": "123456"
}
```

Response:
```json
{
  "access_token": "eyJ...",
  "token_type": "bearer"
}
```

### Using the Token

Include the token in the `Authorization` header:

```bash
GET /api/auth/me
Authorization: Bearer eyJ...
```

## API Endpoints

### Authentication (`/api/auth`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | User login |
| POST | `/api/auth/register` | User registration |
| GET | `/api/auth/me` | Get current user info |
| POST | `/api/auth/activate-invite` | Activate invite code |

### Devices (`/api/devices`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/devices` | List all devices |
| POST | `/api/devices` | Create new device |
| PUT | `/api/devices/{id}` | Update device |
| DELETE | `/api/devices/{id}` | Delete device |

### Sensor Data (`/api/data`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/data/collect` | Receive sensor data |
| GET | `/api/data/realtime` | Get realtime data |
| GET | `/api/data/history` | Get history data |
| DELETE | `/api/data/clear` | Clear all data |

### Alerts (`/api/alerts`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/alerts` | List all alerts |
| GET | `/api/alerts/stats` | Get alert statistics |
| POST | `/api/alerts/{id}/handle` | Handle alert |
| POST | `/api/alerts/{id}/analyze` | AI analysis |

### Users (`/api/users`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/users` | List all users (admin) |
| POST | `/api/users` | Create user (admin) |
| DELETE | `/api/users/{id}` | Delete user (admin) |

### Configuration (`/api/config`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/config/alerts` | Get alert configs |
| PUT | `/api/config/alerts/{scene}` | Update alert config |
| GET | `/api/config/system` | Get system configs |
| PUT | `/api/config/system/{key}` | Update system config |

### Settings (`/api/settings`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/settings/password` | Change password |
| POST | `/api/settings/email` | Change email |
| GET | `/api/settings/snapshots` | List snapshots |
| POST | `/api/settings/snapshots` | Create snapshot |

### Logs (`/api/logs`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/logs` | Get operation logs |

## Error Codes

| Code | Description |
|------|-------------|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request |
| 401 | Unauthorized |
| 403 | Forbidden |
| 404 | Not Found |
| 422 | Validation Error |
| 429 | Too Many Requests |
| 500 | Internal Server Error |

## Rate Limiting

- Login endpoint: 5 requests per minute per IP
- Global: 100 requests per minute per IP

## Example Usage

### Python

```python
import requests

# Login
response = requests.post("http://localhost:18889/api/auth/login", json={
    "username": "admin@example.com",
    "password": "123456"
})
token = response.json()["access_token"]

# Get devices
headers = {"Authorization": f"Bearer {token}"}
devices = requests.get("http://localhost:18889/api/devices", headers=headers)
print(devices.json())
```

### JavaScript

```javascript
// Login
const response = await fetch('http://localhost:18889/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ username: 'admin@example.com', password: '123456' })
});
const { access_token } = await response.json();

// Get devices
const devices = await fetch('http://localhost:18889/api/devices', {
  headers: { 'Authorization': `Bearer ${access_token}` }
});
console.log(await devices.json());
```

### cURL

```bash
# Login
curl -X POST http://localhost:18889/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin@example.com", "password": "123456"}'

# Get devices
curl http://localhost:18889/api/devices \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

> 版权所有：四川职业技术学院 yangming、shahaigui、yanshiyi、qixuding | 联系：2551230793@qq.com
