# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.1.0] - 2024-01-15

### Added
- 3D 数字孪生可视化功能（Three.js）
- 移动端 PWA 支持
- 邀请码权限体系（管理员/会员/基础用户）
- 数据镜像备份功能
- 预警全闭环管理（触发→处置→AI分析）
- 多源数据融合感知（温度、湿度、烟雾、气体）
- AI 智能研判分析（支持智谱GLM/通义千问/DeepSeek/文心一言/OpenAI）
- Docker 一键部署支持
- 完整的单元测试（75个后端测试用例）
- GitHub Actions CI/CD 流水线
- 中英文双语文档

### Changed
- 升级到 FastAPI 0.104.0+
- 升级到 SQLAlchemy 2.0
- 升级到 Vue 3.4+
- 升级到 Element Plus 2.5+

### Fixed
- 修复 .env 文件中文编码问题（Windows 环境）
- 修复前端测试用例
- 修复文档中命令兼容性问题

### Security
- 使用 bcrypt 加密密码
- JWT 令牌认证
- 登录接口限流保护
- CORS 跨域配置

## [2.0.0] - 2024-01-01

### Added
- 初始版本发布
- 基础消防预警功能
- 实时监控大屏
- 设备管理
- 用户管理
- 预警管理

---

## Version History

| Version | Date | Description |
|---------|------|-------------|
| 2.1.0 | 2024-01-15 | 功能增强版，添加3D可视化、PWA、AI分析 |
| 2.0.0 | 2024-01-01 | 初始版本发布 |

---

> 版权所有：四川职业技术学院 yangming、shahaigui、yanshiyi、qixuding | 联系：2551230793@qq.com
