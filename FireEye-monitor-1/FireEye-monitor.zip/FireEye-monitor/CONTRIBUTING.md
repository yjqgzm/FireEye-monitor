# 贡献指南

感谢你对 **火睛智控中心** 的关注！我们欢迎任何形式的贡献。

## 如何贡献

### 提交 Issue

- **Bug 报告**：请使用 [Bug 报告模板](.github/ISSUE_TEMPLATE/bug_report.md)，务必包含复现步骤和环境信息。
- **功能建议**：请描述使用场景、期望行为和可能的实现思路。
- **提问**：请先搜索已有 Issue，避免重复。

### 提交 Pull Request

1. **Fork** 本仓库
2. 从 `main` 分支创建新分支：
   - 功能开发：`feature/你的功能名`
   - Bug 修复：`fix/问题描述`
   - 文档更新：`docs/更新内容`
3. 在本地开发和测试
4. 提交 PR，请使用 [PR 模板](.github/PULL_REQUEST_TEMPLATE.md) 填写改动说明

### 分支命名规范

| 类型 | 格式 | 示例 |
|------|------|------|
| 功能 | `feature/功能名` | `feature/smoke-alert` |
| 修复 | `fix/问题描述` | `fix/login-401-error` |
| 文档 | `docs/更新内容` | `docs/api-usage` |

## 开发环境启动

### 后端

```bash
cd backend
py -3 -m pip install -r requirements.txt
py -3 -m uvicorn backend.main:app --host 0.0.0.0 --port 18889
```

### 前端

```bash
cd frontend
npm install
npm run dev
```

### 运行测试

```bash
cd backend
py -3 -m pytest -v
```

项目包含 70 个单元测试用例，覆盖全部 9 个路由模块。新功能必须编写对应测试。

### 运行 Lint 检查

```bash
pip install ruff
ruff check backend/
```

CI 会在每次提交时自动运行 Lint 检查，请确保本地通过后再提交。

## 代码风格

### Python（后端）

- 遵循 [PEP 8](https://peps.python.org/pep-0008/) 规范
- 使用 4 空格缩进
- 函数和类添加 docstring
- 新功能必须编写对应测试

### JavaScript/Vue（前端）

- 遵循 [Vue 官方风格指南](https://cn.vuejs.org/style-guide/)
- 使用 2 空格缩进
- 组件名使用 PascalCase

### 通用

- 提交信息使用中文或英文均可，但需清晰描述改动内容
- 每次提交只做一件事，避免混合多种改动
- 不提交 `node_modules/`、`__pycache__/`、`.db`、`.env` 等文件

## 行为准则

请阅读并遵守 [行为准则](CODE_OF_CONDUCT.md)。

## 安全问题

如果你发现了安全漏洞，请**不要**在公开 Issue 中报告。请发送邮件至 **2551230793@qq.com**，详见 [安全策略](SECURITY.md)。

## 许可证

本项目采用 [AGPL-3.0](LICENSE) 许可证。贡献的代码将以相同许可证发布。
