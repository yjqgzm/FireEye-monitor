"""
FireGuard System - One-click Startup
Run this file to start the entire system (PC + Mobile)
"""

import os
import sys
import time
import signal
import socket
import subprocess
import webbrowser
from pathlib import Path
from datetime import datetime

def check_python_version():
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print(f"[ERROR] Python version too low: {version.major}.{version.minor}.{version.micro}")
        print("Please install Python 3.8 or higher")
        return False
    print(f"[OK] Python version: {version.major}.{version.minor}.{version.micro}")
    return True

def check_dependencies():
    print("\n[1/5] Checking dependencies...")
    try:
        import fastapi
        import uvicorn
        import sqlalchemy
        print("[OK] Core dependencies installed")
        return True
    except ImportError:
        print("[*] Installing dependencies, please wait...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            print("[OK] Dependencies installed")
            return True
        except Exception as e:
            print(f"[ERROR] Failed to install dependencies: {e}")
            return False

def init_database():
    print("\n[2/5] Initializing database...")
    try:
        from backend.database import init_db
        init_db()
        print("[OK] Database initialized")
        return True
    except Exception as e:
        print(f"[ERROR] Database initialization failed: {e}")
        return False

def check_port(port=18889):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.bind(('127.0.0.1', port))
        sock.close()
        return True
    except:
        return False

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return '127.0.0.1'

def start_backend_server():
    print("\n[3/5] Starting backend service...")

    port = 18889
    if not check_port(port):
        print(f"[*] Port 18889 occupied, trying 18890...")
        port = 18890
        if not check_port(port):
            print("[ERROR] Both ports 18889 and 18890 are occupied")
            return None

    print(f"[*] Backend will start at http://localhost:{port}")

    try:
        project_root = os.path.dirname(os.path.abspath(__file__))
        os.chdir(project_root)
        sys.path.insert(0, project_root)

        process = subprocess.Popen(
            [sys.executable, "-m", "uvicorn", "backend.main:app", "--host", "0.0.0.0", "--port", str(port), "--reload"],
            cwd=project_root,
            stdout=None,
            stderr=None,
            creationflags=subprocess.CREATE_NEW_CONSOLE if sys.platform == 'win32' else 0
        )

        print("[*] Waiting for backend service to start...")
        time.sleep(3)

        if process.poll() is not None:
            print("[ERROR] Backend service failed to start")
            return None

        print(f"[OK] Backend service started: http://localhost:{port}")
        return process, port
    except Exception as e:
        print(f"[ERROR] Backend service failed to start: {e}")
        return None

def start_mobile_frontend():
    print("\n[4/5] Starting mobile APP frontend...")

    mobile_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mobile-app")

    if not os.path.exists(mobile_dir):
        print("[WARNING] Mobile APP directory not found, skipping mobile frontend")
        return None, None

    node_modules = os.path.join(mobile_dir, "node_modules")
    if not os.path.exists(node_modules):
        print("[*] Installing mobile APP dependencies (first time, please wait)...")
        try:
            install_result = subprocess.run(
                ["npm", "install", "--prefer-offline"],
                cwd=mobile_dir,
                capture_output=True, text=True, timeout=300
            )
            if install_result.returncode != 0:
                print(f"[WARNING] npm install output: {install_result.stderr[-300:] if install_result.stderr else 'no error'}")
            else:
                print("[OK] Dependencies installed")
        except FileNotFoundError:
            print("[ERROR] npm not found! Please install Node.js from https://nodejs.org/")
            return None, None
        except Exception as e:
            print(f"[WARNING] npm install issue: {e}")

    mobile_port = 3001
    if not check_port(mobile_port):
        for alt in [3002, 3003, 8081]:
            if check_port(alt):
                mobile_port = alt
                break

    print(f"[*] Mobile APP will start at http://0.0.0.0:{mobile_port}")

    mobile_process = None
    try:
        if sys.platform == 'win32':
            cmd_str = f'cd /d "{mobile_dir}" && npx vite --host 0.0.0.0 --port {mobile_port}'
            mobile_process = subprocess.Popen(
                cmd_str,
                shell=True,
                creationflags=subprocess.CREATE_NEW_CONSOLE,
                cwd=mobile_dir
            )
        else:
            mobile_process = subprocess.Popen(
                ["npx", "vite", "--host", "0.0.0.0", "--port", str(mobile_port)],
                cwd=mobile_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )

        print("[*] Waiting for mobile APP to start...")
        time.sleep(5)

        if mobile_process.poll() is not None:
            print("[ERROR] Mobile APP process exited immediately!")
            return None, None

        local_ip = get_local_ip()
        print(f"[OK] Mobile APP started successfully!")
        print(f"     PC access  : http://localhost:{mobile_port}")
        print(f"     Phone URL  : http://{local_ip}:{mobile_port}")

        return mobile_process, mobile_port

    except FileNotFoundError:
        print("[ERROR] Node.js/npx not found! Please install Node.js first: https://nodejs.org/")
        return None, None
    except Exception as e:
        print(f"[ERROR] Failed to start mobile APP: {e}")
        return None, None

def open_browser(backend_port, mobile_port=None):
    print("\n[5/5] Opening system page...")
    time.sleep(1)

    url = f"http://localhost:{backend_port}"
    try:
        webbrowser.open(url)
        print(f"[OK] Browser opened: {url} (PC)")
    except:
        print(f"[*] Please manually open browser: {url}")

    if mobile_port:
        print(f"\n[*] Mobile APP URL: http://{get_local_ip()}:{mobile_port}")
        print("    Open this URL on your phone (same WiFi network)")

def main():
    print("=" * 60)
    print("  FireGuard System - One-click Startup")
    print("  (PC + Mobile APP)")
    print("=" * 60)

    if not check_python_version():
        input("\nPress Enter to exit...")
        sys.exit(1)

    if not check_dependencies():
        input("\nPress Enter to exit...")
        sys.exit(1)

    if not init_database():
        input("\nPress Enter to exit...")
        sys.exit(1)

    result = start_backend_server()
    if result is None:
        input("\nPress Enter to exit...")
        sys.exit(1)

    server, backend_port = result

    mobile_result = start_mobile_frontend()
    mobile_process = mobile_result[0] if mobile_result else None
    mobile_port = mobile_result[1] if mobile_result else None

    open_browser(backend_port, mobile_port)

    print("\n" + "=" * 60)
    print("  System started successfully!")
    print("-" * 60)
    print(f"  PC Web App : http://localhost:{backend_port}")
    if mobile_port:
        print(f"  Mobile APP : http://localhost:{mobile_port}")
        print(f"  Phone URL  : http://{get_local_ip()}:{mobile_port}")
        print("")
        print("  [TIP] If phone cannot access, check:")
        print("    1. Phone and PC on the SAME WiFi network")
        print("    2. Windows Firewall allows port", mobile_port, "(may popup)")
    print("-" * 60)
    print("  Login: admin / 123456")
    print("  Press Ctrl+C in THIS window to stop all services")
    print("=" * 60)

    try:
        server.wait()
    except KeyboardInterrupt:
        print("\n\n[*] Stopping all services...")
        server.terminate()
        if mobile_process:
            try:
                mobile_process.terminate()
            except:
                pass
        print("[OK] All services stopped")

if __name__ == "__main__":
    main()