/*
 * 火睛智控中心 - 传感器固件
 * 版权所有：四川职业技术学院 yangming、shahaigui、yanshiyi、qixuding
 * 联系邮箱：2551230793@qq.com
 * 协议：AGPL-3.0，禁止闭源商用
 */

/*
 * 基于ESP32+MLX90614的红外测温火灾智能预警系统 V2.0 - 边缘端固件
 * 升级功能：OLED屏幕显示、MQ-2烟雾检测、DHT11温湿度、增强数据上报
 * 作者：FireGuard Team
 * 版本：2.0.0
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <Wire.h>
#include <Adafruit_MLX90614.h>
#include <DHT.h>
#include <ArduinoJson.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// ==================== 硬件配置 ====================
#define MLX90614_ADDR 0x5A        // MLX90614 I2C地址
#define DHT_PIN 4                 // DHT11数据引脚 (更新为DHT11)
#define DHT_TYPE DHT11            // DHT传感器类型 (更新为DHT11)
#define SMOKE_PIN 34              // MQ-2烟雾传感器模拟输入引脚
#define BUZZER_PIN 18             // 蜂鸣器引脚
#define LED_R_PIN 19              // RGB红色LED
#define LED_G_PIN 21              // RGB绿色LED  
#define LED_B_PIN 22              // RGB蓝色LED
#define RELAY_PIN 23              // 继电器控制引脚

// ==================== OLED屏幕配置 ====================
#define SCREEN_WIDTH 128          // OLED显示宽度(像素)
#define SCREEN_HEIGHT 64          // OLED显示高度(像素)
#define OLED_RESET -1             // 复位引脚(-1表示共享Arduino复位)
#define SCREEN_ADDRESS 0x3C       // I2C地址 (0x3C或0x3D)

// ==================== WiFi配置 ====================
const char* ssid = "YOUR_WIFI_SSID";           // WiFi名称
const char* password = "YOUR_WIFI_PASSWORD";  // WiFi密码
const char* serverUrl = "http://YOUR_SERVER_IP:18889/api/data/receive";  // 后端服务器地址

// ==================== 设备配置 ====================
const String deviceId = "SENSOR_001";  // 设备唯一ID
const String deviceName = "测温点1";   // 设备名称

// ==================== 预警阈值配置 ====================
float level1Threshold = 45.0;   // 一级预警温度阈值(℃)
float level2Threshold = 60.0;   // 二级预警温度阈值(℃)
float level3Threshold = 80.0;   // 三级预警温度阈值(℃)
float tempRiseRateThreshold = 1.0;  // 温升速率阈值(℃/min)
float smokeThreshold = 600.0;   // 烟雾浓度阈值(ADC值, 可根据实际调整)

// ==================== 采样配置 ====================
const unsigned long sampleInterval = 1000;  // 采样间隔(ms)
const unsigned long uploadInterval = 5000;   // 上传间隔(ms)
const unsigned long displayUpdateInterval = 500;  // 屏幕刷新间隔(ms)

// ==================== 全局对象 ====================
Adafruit_MLX90614 mlx = Adafruit_MLX90614(MLX90614_ADDR);
DHT dht(DHT_PIN, DHT_TYPE);
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// ==================== 全局变量 ====================
float objectTemp = 0.0;      // 物体表面温度
float ambientTemp = 0.0;     // 环境温度
float humidity = 0.0;        // 湿度
float compensatedTemp = 0.0; // 补偿后温度
int smokeValue = 0;          // 烟雾传感器ADC值
bool smokeDetected = false;  // 是否检测到烟雾

float tempHistory[60];       // 温度历史记录(60秒)
int smokeHistory[30];        // 烟雾历史记录(30秒)
int tempHistoryIndex = 0;
int smokeHistoryIndex = 0;
unsigned long lastSampleTime = 0;
unsigned long lastUploadTime = 0;
unsigned long lastDisplayTime = 0;
unsigned long lastAlertTime = 0;

int alertLevel = 0;          // 当前预警等级
bool alertTriggered = false; // 预警是否已触发
int consecutiveCount = 0;    // 连续触发计数(防抖)
int smokeConsecutiveCount = 0;  // 烟雾连续触发计数

// ==================== 函数声明 ====================
void connectWiFi();
void initSensors();
void initDisplay();
void sampleData();
void processData();
void updateDisplay();
float compensateTemperature(float objTemp, float ambTemp, float hum);
float calculateTempRiseRate();
void checkAlert(float temp, float riseRate);
void checkSmokeAlert(int smokeVal);
void triggerAlert(int level);
void clearAlert();
void uploadData();
void controlRelay(bool state);
void beep(int times, int duration);
void setLedColor(int r, int g, int b);

// ==================== 初始化 ====================
void setup() {
  Serial.begin(115200);
  delay(1000);
  
  Serial.println("\n========== 红外测温火灾预警系统 V2.0 ==========");
  Serial.println("设备ID: " + deviceId);
  Serial.println("设备名称: " + deviceName);
  
  // 初始化传感器
  initSensors();
  
  // 初始化OLED屏幕
  initDisplay();
  
  // 初始化GPIO
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_R_PIN, OUTPUT);
  pinMode(LED_G_PIN, OUTPUT);
  pinMode(LED_B_PIN, OUTPUT);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(SMOKE_PIN, INPUT);  // 烟雾传感器输入
  
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(RELAY_PIN, LOW);
  setLedColor(0, 0, 0);
  
  // 连接WiFi
  connectWiFi();
  
  Serial.println("系统初始化完成，开始工作...\n");
}

// ==================== 主循环 ====================
void loop() {
  unsigned long currentTime = millis();
  
  // 检查WiFi连接
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi断开，正在重连...");
    connectWiFi();
  }
  
  // 采样数据
  if (currentTime - lastSampleTime >= sampleInterval) {
    sampleData();
    processData();
    lastSampleTime = currentTime;
  }
  
  // 更新OLED显示
  if (currentTime - lastDisplayTime >= displayUpdateInterval) {
    updateDisplay();
    lastDisplayTime = currentTime;
  }
  
  // 上传数据
  if (currentTime - lastUploadTime >= uploadInterval) {
    uploadData();
    lastUploadTime = currentTime;
  }
  
  delay(10);
}

// ==================== 传感器初始化 ====================
void initSensors() {
  Serial.println("初始化传感器...");
  
  // 初始化I2C通信
  Wire.begin(15, 16);  // SDA=15, SCL=16
  
  // 初始化MLX90614
  if (!mlx.begin()) {
    Serial.println("错误: 无法找到MLX90614传感器!");
    display.clearDisplay();
    display.setCursor(0, 0);
    display.println("MLX90614 Error!");
    display.display();
    while (1) delay(1000);
  }
  Serial.println("MLX90614 初始化成功");
  
  // 初始化DHT11 (更新为DHT11)
  dht.begin();
  Serial.println("DHT11 初始化成功");
  
  // 初始化温度和烟雾历史数组
  for (int i = 0; i < 60; i++) {
    tempHistory[i] = 25.0;
  }
  for (int i = 0; i < 30; i++) {
    smokeHistory[i] = 0;
  }
}

// ==================== OLED屏幕初始化 ====================
void initDisplay() {
  Serial.println("初始化OLED屏幕...");
  
  if(!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
    Serial.println(F("SSD1306分配失败"));
    // 继续运行，只是没有屏幕显示
  } else {
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(0, 0);
    display.println(F("FireGuard V2.0"));
    display.println(F("Initializing..."));
    display.display();
    
    delay(1000);
    Serial.println("OLED屏幕初始化成功");
  }
}

// ==================== WiFi连接 ====================
void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  
  Serial.print("正在连接WiFi");
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 30) {
    delay(500);
    Serial.print(".");
    attempts++;
  }
  
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi连接成功!");
    Serial.print("IP地址: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nWiFi连接失败，请检查配置!");
  }
}

// ==================== 数据采样 ====================
void sampleData() {
  // 读取MLX90614数据
  objectTemp = mlx.readObjectTempC();
  ambientTemp = mlx.readAmbientTempC();
  
  // 读取DHT11数据(多次读取取平均) - 更新为DHT11
  float humSum = 0;
  float tempSum = 0;
  int validReads = 0;
  for (int i = 0; i < 5; i++) {  // DHT11读取5次取平均以提高精度
    float t = dht.readTemperature();
    float h = dht.readHumidity();
    if (!isnan(t) && !isnan(h)) {
      tempSum += t;
      humSum += h;
      validReads++;
    }
    delay(50);
  }
  
  if (validReads > 0) {
    float dhtTemp = tempSum / validReads;
    humidity = humSum / validReads;
    ambientTemp = (ambientTemp + dhtTemp) / 2.0;  // 取平均
  } else {
    Serial.println("DHT11读取失败，使用MLX环境温度");
    humidity = 50.0;  // 默认湿度
  }
  
  // 读取MQ-2烟雾传感器 (多次采样取平均)
  int smokeSum = 0;
  for (int i = 0; i < 10; i++) {
    smokeSum += analogRead(SMOKE_PIN);
    delay(10);
  }
  smokeValue = smokeSum / 10;
  
  // 温度有效性检查
  if (isnan(objectTemp) || objectTemp < -20 || objectTemp > 500) {
    Serial.println("警告: 温度数据无效，使用历史值");
    objectTemp = tempHistory[tempHistoryIndex];
  }
  
  Serial.printf("物体温度: %.1f°C, 环境温度: %.1f°C, 湿度: %.1f%%, 烟雾值: %d\n", 
                objectTemp, ambientTemp, humidity, smokeValue);
}

// ==================== 数据处理 ====================
void processData() {
  // 环境温湿度补偿
  compensatedTemp = compensateTemperature(objectTemp, ambientTemp, humidity);
  
  // 更新温度历史
  tempHistory[tempHistoryIndex] = compensatedTemp;
  tempHistoryIndex = (tempHistoryIndex + 1) % 60;
  
  // 更新烟雾历史
  smokeHistory[smokeHistoryIndex] = smokeValue;
  smokeHistoryIndex = (smokeHistoryIndex + 1) % 30;
  
  // 检查温度预警
  float riseRate = calculateTempRiseRate();
  checkAlert(compensatedTemp, riseRate);
  
  // 检查烟雾预警
  checkSmokeAlert(smokeValue);
  
  // 更新状态指示灯
  updateStatusLed();
}

// ==================== OLED屏幕更新 ====================
void updateDisplay() {
  if (!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
    return;  // 屏幕不可用则跳过
  }
  
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  
  // 第一行：标题
  display.setCursor(0, 0);
  display.print(F("FireGuard V2.0 "));
  
  // 显示在线状态
  if (WiFi.status() == WL_CONNECTED) {
    display.print(F("[ON]"));
  } else {
    display.print(F("[OFF]"));
  }
  
  // 第二行：物体温度
  display.setCursor(0, 10);
  display.print(F("Obj Temp: "));
  display.print(compensatedTemp, 1);
  display.print(F(" C"));
  
  // 第三行：环境温湿度
  display.setCursor(0, 20);
  display.print(F("Env: "));
  display.print(ambientTemp, 1);
  display.print(F("C "));
  display.print(humidity, 1);
  display.print(F("%"));
  
  // 第四行：烟雾状态
  display.setCursor(0, 30);
  display.print(F("Smoke: "));
  display.print(smokeValue);
  if (smokeDetected) {
    display.print(F(" [ALERT!]"));
  }
  
  // 第五行：预警等级
  display.setCursor(0, 40);
  display.print(F("Alert Level: "));
  if (alertLevel == 3) {
    display.print(F("CRITICAL"));
  } else if (alertLevel == 2) {
    display.print(F("WARNING"));
  } else if (alertLevel == 1) {
    display.print(F("NOTICE"));
  } else {
    display.print(F("NORMAL"));
  }
  
  // 第六行：继电器状态
  display.setCursor(0, 50);
  display.print(F("Relay: "));
  if (alertLevel >= 3 || smokeDetected) {
    display.print(F("ACTIVE"));
  } else {
    display.print(F("STANDBY"));
  }
  
  display.display();
}

// ==================== 温度补偿算法 ====================
// 核心创新点：环境温湿度补偿算法，降低误报率
float compensateTemperature(float objTemp, float ambTemp, float hum) {
  float compensated = objTemp;
  
  // 温差补偿：物体与环境温差过大时可能是干扰
  float tempDiff = objTemp - ambTemp;
  
  // 阳光直射补偿(环境温度突然升高时)
  if (ambTemp > 35.0 && tempDiff < 5.0) {
    compensated = ambTemp + 2.0;  // 修正阳光直射影响
  }
  
  // 高湿环境补偿
  if (hum > 80.0) {
    compensated = compensated - 1.0;  // 高湿环境降低显示温度
  }
  
  // 滑动平均滤波(剔除跳变)
  float sum = 0;
  int count = 0;
  for (int i = 0; i < 60; i++) {
    if (abs(tempHistory[i] - objTemp) < 10.0) {  // 剔除异常值
      sum += tempHistory[i];
      count++;
    }
  }
  if (count > 0) {
    compensated = (compensated + sum / count) / 2.0;
  }
  
  return compensated;
}

// ==================== 温升速率计算 ====================
float calculateTempRiseRate() {
  // 计算最近60秒的温度变化速率
  float oldest = tempHistory[(tempHistoryIndex + 1) % 60];
  float newest = tempHistory[tempHistoryIndex];
  
  // 如果历史数据不足60秒，使用较短时间计算
  float rate = (newest - oldest) / 1.0;  // ℃/min
  
  return abs(rate);
}

// ==================== 预警检查（温度）====================
// 核心创新点：三级分级预警机制
void checkAlert(float temp, float riseRate) {
  int newAlertLevel = 0;
  String alertType = "";
  
  // 温度阈值判断
  if (temp >= level3Threshold) {
    newAlertLevel = 3;
    alertType = "critical";
  } else if (temp >= level2Threshold) {
    newAlertLevel = 2;
    alertType = "warning";
  } else if (temp >= level1Threshold) {
    newAlertLevel = 1;
    alertType = "notice";
  }
  
  // 温升速率判断(优先)
  if (riseRate >= 3.0) {
    newAlertLevel = 3;
    alertType = "critical_rate";
  } else if (riseRate >= 2.0 && newAlertLevel < 2) {
    newAlertLevel = 2;
    alertType = "warning_rate";
  } else if (riseRate >= 1.0 && newAlertLevel < 1) {
    newAlertLevel = 1;
    alertType = "notice_rate";
  }
  
  // 防抖机制：连续3次符合条件才触发
  if (newAlertLevel > 0) {
    if (newAlertLevel == alertLevel) {
      consecutiveCount++;
      if (consecutiveCount >= 3 && !alertTriggered) {
        triggerAlert(newAlertLevel);
      }
    } else {
      consecutiveCount = 1;
      alertLevel = newAlertLevel;
    }
  } else {
    if (alertTriggered && !smokeDetected) {  // 只有在没有烟雾报警时才清除
      clearAlert();
    }
    consecutiveCount = 0;
    if (!smokeDetected) {
      alertLevel = 0;
    }
  }
}

// ==================== 烟雾预警检查 ====================
// 新增功能：独立烟雾检测与预警
void checkSmokeAlert(int smokeVal) {
  // 烟雾浓度超过阈值
  if (smokeVal >= smokeThreshold) {
    smokeConsecutiveCount++;
    
    // 连续3次检测到烟雾才确认（防抖）
    if (smokeConsecutiveCount >= 3 && !smokeDetected) {
      smokeDetected = true;
      Serial.printf("!!! 检测到烟雾! 浓度值: %d !!!\n", smokeVal);
      
      // 触发最高级别预警（烟雾=紧急）
      if (alertLevel < 3) {
        triggerAlert(3);  // 烟雾直接触发3级紧急预警
      }
      
      // 立即激活继电器
      controlRelay(true);
      
      // 特殊蜂鸣模式（连续急促）
      beep(5, 200);
      
      // 设置红色LED闪烁
      setLedColor(255, 0, 0);
    }
  } else {
    // 烟雾浓度低于阈值
    if (smokeDetected) {
      smokeConsecutiveCount--;
      if (smokeConsecutiveCount <= 0) {
        smokeDetected = false;
        smokeConsecutiveCount = 0;
        Serial.println("烟雾已消散");
        
        // 如果温度也正常，解除预警
        if (alertLevel < 2) {
          clearAlert();
        }
      }
    } else {
      smokeConsecutiveCount = 0;
    }
  }
}

// ==================== 触发预警 ====================
void triggerAlert(int level) {
  alertTriggered = true;
  alertLevel = level;
  Serial.printf("!!! 预警触发: 等级 %d !!!\n", level);
  
  // 本地声光报警（如果不是由烟雾触发的）
  if (!smokeDetected) {
    if (level >= 3) {
      // 三级：紧急报警
      beep(3, 500);
      setLedColor(255, 0, 0);  // 红色
      controlRelay(true);  // 触发应急联动
    } else if (level >= 2) {
      // 二级：警告
      beep(2, 300);
      setLedColor(255, 165, 0);  // 橙色
    } else {
      // 一级：提示
      beep(1, 200);
      setLedColor(0, 0, 255);  // 蓝色
    }
  }
  
  lastAlertTime = millis();
}

// ==================== 清除预警 ====================
void clearAlert() {
  alertTriggered = false;
  alertLevel = 0;
  consecutiveCount = 0;
  digitalWrite(BUZZER_PIN, LOW);
  setLedColor(0, 255, 0);  // 绿色-正常
  if (!smokeDetected) {  // 只有在没有烟雾时才关闭继电器
    controlRelay(false);
  }
  Serial.println("预警已解除");
}

// ==================== 状态LED更新 ====================
void updateStatusLed() {
  if (!alertTriggered && !smokeDetected) {
    if (WiFi.status() == WL_CONNECTED) {
      setLedColor(0, 255, 0);  // 绿色-正常
    } else {
      setLedColor(255, 255, 0);  // 黄色-WiFi断开
    }
  }
}

// ==================== LED颜色控制 ====================
void setLedColor(int r, int g, int b) {
  analogWrite(LED_R_PIN, 255 - r);
  analogWrite(LED_G_PIN, 255 - g);
  analogWrite(LED_B_PIN, 255 - b);
}

// ==================== 蜂鸣器控制 ====================
void beep(int times, int duration) {
  for (int i = 0; i < times; i++) {
    digitalWrite(BUZZER_PIN, HIGH);
    delay(duration);
    digitalWrite(BUZZER_PIN, LOW);
    if (i < times - 1) {
      delay(duration);
    }
  }
}

// ==================== 继电器控制 ====================
// 核心创新点：应急联动控制
void controlRelay(bool state) {
  digitalWrite(RELAY_PIN, state ? HIGH : LOW);
  Serial.printf("继电器状态: %s\n", state ? "开启" : "关闭");
}

// ==================== 数据上传（增强版）====================
void uploadData() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi未连接，无法上传数据");
    return;
  }
  
  HTTPClient http;
  http.begin(serverUrl);
  http.addHeader("Content-Type", "application/json");
  
  // 构建JSON数据（增加烟雾数据字段）
  StaticJsonDocument<512> doc;  // 扩大缓冲区以容纳更多数据
  doc["device_id"] = deviceId;
  doc["temperature"] = compensatedTemp;
  doc["ambient_temp"] = ambientTemp;
  doc["humidity"] = humidity;
  doc["smoke_value"] = smokeValue;           // 新增：烟雾传感器原始值
  doc["smoke_detected"] = smokeDetected ? 1 : 0;  // 新增：是否检测到烟雾(0/1)
  doc["status"] = "online";
  doc["sensor_status"] = mlx.readStatus() == 0 ? "ok" : "error";
  
  // 添加传感器类型标识
  doc["sensor_types"] = "mlx90614,dht11,mq2";  // 新增：传感器类型列表
  
  String jsonStr;
  serializeJson(doc, jsonStr);
  
  int httpCode = http.POST(jsonStr);
  
  if (httpCode == HTTP_CODE_OK) {
    String response = http.getString();
    Serial.printf("数据上传成功: %s\n", response.c_str());
    
    // 解析服务器响应(可接收远程控制指令)
    StaticJsonDocument<256> responseDoc;
    DeserializationError error = deserializeJson(responseDoc, response);
    if (!error) {
      // 处理服务器下发的配置更新
      if (responseDoc.containsKey("level1_threshold")) {
        level1Threshold = responseDoc["level1_threshold"].as<float>();
        level2Threshold = responseDoc["level2_threshold"].as<float>();
        level3Threshold = responseDoc["level3_threshold"].as<float>();
        Serial.println("温度阈值配置已更新");
      }
      
      // 处理烟雾阈值更新
      if (responseDoc.containsKey("smoke_threshold")) {
        smokeThreshold = responseDoc["smoke_threshold"].as<float>();
        Serial.printf("烟雾阈值已更新: %.0f\n", smokeThreshold);
      }
      
      // 处理远程控制指令
      if (responseDoc.containsKey("relay_control")) {
        bool relayState = responseDoc["relay_control"].as<bool>();
        controlRelay(relayState);
      }
      
      // 处理设备重启指令
      if (responseDoc.containsKey("restart") && responseDoc["restart"].as<bool>()) {
        Serial.println("收到重启指令，准备重启...");
        delay(1000);
        ESP.restart();
      }
    }
  } else {
    Serial.printf("数据上传失败, HTTP错误码: %d\n", httpCode);
  }
  
  http.end();
}

// ==================== 辅助函数 ====================

/*
 * 硬件接线说明 (V2.0升级版):
 * 
 * ESP32引脚分配:
 * - GPIO15 (SDA): MLX90614 SDA / OLED SDA
 * - GPIO16 (SCL): MLX90614 SCL / OLED SCL
 * - GPIO4: DHT11 DATA (更新为DHT11)
 * - GPIO18: 蜂鸣器正极
 * - GPIO19: RGB LED 红色
 * - GPIO21: RGB LED 绿色
 * - GPIO22: RGB LED 蓝色
 * - GPIO23: 继电器模块IN
 * - GPIO34: MQ-2烟雾传感器AO (模拟输入)
 * 
 * 电源:
 * - 3.3V: MLX90614 VCC, DHT11 VCC, OLED VCC
 * - 5V: 继电器模块 VCC, MQ-2 VCC (如果需要5V供电)
 * - GND: 所有模块 GND
 * 
 * I2C总线:
 * - MLX90614和OLED共享I2C总线(地址不同: MLX=0x5A, OLED=0x3C)
 * 
 * 注意事项:
 * 1. MQ-2需要预热3-5分钟才能稳定工作
 * 2. DHT11采样间隔建议>1秒
 * 3. OLED使用128x64分辨率SSD1306控制器
 */
