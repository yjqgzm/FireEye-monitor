# FireGuard Intelligent Control Center

**FireGuard** — An intelligent fire risk perception and early warning platform integrating temperature, humidity, smoke, gas, and multi-source environmental data.

## What is this?

FireGuard is an intelligent fire early warning system designed for small and medium-sized venues (laboratories, dormitories, warehouses, shops, electrical rooms). It continuously collects environmental data through WiFi infrared temperature sensors, combines multi-level warning algorithms with AI-powered analysis, and issues alerts during the smoldering phase — upgrading traditional "post-incident alarm" to "pre-incident prediction."

## Key Features

- 🌡️ **Multi-source Data Fusion** — Unified ingestion of temperature, humidity, smoke, and gas data
- 🚨 **Three-level Warning System** — Notice → Warning → Critical, with scene-specific threshold configuration
- 🤖 **AI-powered Analysis** — Integrates Chinese LLMs (Zhipu GLM, Qwen, DeepSeek, etc.) for automated risk assessment and emergency recommendations
- 🏗️ **3D Digital Twin Visualization** — Three.js building scenes with risk focus, fire spread simulation, and historical playback
- 📱 **Mobile PWA Support** — Works in mobile browsers, installable to home screen as a native-like app
- 🔐 **Invite Code Permission System** — Three-tier access: admin / member / basic user
- 📊 **Real-time Monitoring Dashboard** — ECharts visualization for sensor trends, spectrum monitoring, and alert streams
- 🔄 **Full Alert Lifecycle Management** — From trigger to resolution to AI analysis

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Vue 3 + Element Plus + ECharts + Three.js |
| Backend | FastAPI + SQLAlchemy 2.0 + SQLite + slowapi |
| AI | Zhipu GLM / Qwen / DeepSeek / Baidu ERNIE / OpenAI |
| Hardware | ESP32 + MLX90614 (compatible with all WiFi sensors) |
| Mobile | Vue 3 + Element Plus + ECharts (PWA) |

## Quick Start

👉 See [快速开始.md](./快速开始.md) for detailed setup instructions.

Get it running in 5 minutes: Install Node.js and Python → Install dependencies → Start backend → Start frontend → Open browser.

Default login credentials: `admin@example.com` / `123456`

> ⚠️ Default password is for local testing only. For production, set `DEFAULT_ADMIN_PASSWORD` in `.env`.

## Quick Start with Docker

If you have Docker installed, start the full stack with a single command:

```bash
docker-compose up -d
```

After startup:

- Frontend: http://localhost:3000
- Backend API docs: http://localhost:18889/docs

Stop services:

```bash
docker-compose down
```

## Project Structure

```
├── frontend/            # PC frontend source code
├── backend/             # Backend source code
│   ├── routers/         #   API route modules (9)
│   └── tests/           #   Unit tests (70 test cases)
│   ├── config.py        # Configuration & JWT & password utils
│   ├── deps.py          # FastAPI dependency injection
│   ├── cache.py         # In-memory cache
│   ├── models.py        # Pydantic request/response models
│   └── database.py      # SQLAlchemy models & DB setup
├── hardware_firmware/   # Sensor firmware (Arduino)
├── mobile-app/          # Mobile PWA frontend
├── docker-compose.yml   # Docker Compose config
├── CONTRIBUTING.md      # Contribution guide
├── CODE_OF_CONDUCT.md   # Code of conduct
├── SECURITY.md          # Security policy
└── LICENSE              # AGPL-3.0
```

## Community & Contributing

We welcome contributions of all kinds! Please read our guidelines:

- [Contributing Guide](./CONTRIBUTING.md) — How to submit Issues and Pull Requests
- [Code of Conduct](./CODE_OF_CONDUCT.md) — Community standards
- [Security Policy](./SECURITY.md) — How to report security vulnerabilities

## License

This project is licensed under [AGPL-3.0](./LICENSE). Commercial use with closed-source modifications is prohibited.

## Contact

- Email: 2551230793@qq.com
- For commercial licensing, please contact the lead author

> Copyright: Sichuan Vocational and Technical College — yangming, shahaigui, yanshiyi, qixuding | Contact: 2551230793@qq.com
