import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import api from '@/api'

export const useUserStore = defineStore('user', () => {
  const token = ref(localStorage.getItem('token') || '')
  const user = ref(null)

  const isLoggedIn = computed(() => !!token.value)
  const isAdmin = computed(() => user.value?.role === 'admin')
  const isInvited = computed(() => user.value?.is_invited === true)

  async function login(username, password) {
    const res = await api.post('/api/auth/login', { username, password })
    token.value = res.access_token
    localStorage.setItem('token', token.value)
    await fetchUserInfo()
    return true
  }

  async function register(username, password, email, inviteCode) {
    const data = { username, password }
    if (email) data.email = email
    if (inviteCode) data.invite_code = inviteCode
    const res = await api.post('/api/auth/register', data)
    token.value = res.access_token
    localStorage.setItem('token', token.value)
    await fetchUserInfo()
    return true
  }

  async function activateInvite(inviteCode) {
    const res = await api.post('/api/auth/activate-invite', { invite_code: inviteCode })
    if (user.value) {
      user.value.is_invited = true
    }
    return res
  }

  async function fetchUserInfo() {
    if (!token.value) return
    try {
      const res = await api.get('/api/auth/me')
      user.value = res
    } catch (e) {
      logout()
    }
  }

  function logout() {
    token.value = ''
    user.value = null
    localStorage.removeItem('token')
  }

  if (token.value) {
    fetchUserInfo()
  }

  return { token, user, isLoggedIn, isAdmin, isInvited, login, register, activateInvite, fetchUserInfo, logout }
})
