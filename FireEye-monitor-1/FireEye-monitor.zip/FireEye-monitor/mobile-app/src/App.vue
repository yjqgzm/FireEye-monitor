/**
 * 火睛智控中心
 * 版权所有：四川职业技术学院 yangming、shahaigui、yanshiyi、qixuding
 * 联系邮箱：2551230793@qq.com
 * 协议：AGPL-3.0，禁止闭源商用
 */

<template>
  <router-view />
</template>

<script setup>
import { onMounted } from 'vue'
import { useUserStore } from '@/stores/user'

const userStore = useUserStore()

onMounted(() => {
  if (userStore.token) {
    userStore.fetchUserInfo()
  }
})
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html, body, #app {
  width: 100%;
  height: 100%;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  -webkit-tap-highlight-color: transparent;
  -webkit-font-smoothing: antialiased;
}

body {
  background: #f5f7fa;
  color: #1a1a2e;
  overflow-x: hidden;
}
</style>
