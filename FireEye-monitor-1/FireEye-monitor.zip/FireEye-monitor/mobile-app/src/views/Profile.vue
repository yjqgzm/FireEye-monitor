<template>
  <div class="profile-page page-container">
    <h2 class="page-title">个人中心</h2>
    
    <div class="profile-header glass-card">
      <div class="avatar-wrap">
        <el-avatar :size="60" :style="{background:'linear-gradient(135deg,#165DFF,#3385ff)',fontSize:'24px'}">
          {{ userStore.user?.username?.[0]?.toUpperCase() || '?' }}
        </el-avatar>
      </div>
      <div class="user-info">
        <div class="username">{{ userStore.user?.username || '--' }}</div>
        <div class="role-tag">
          <el-tag v-if="userStore.isAdmin" type="warning" size="small" effect="dark">管理员</el-tag>
          <el-tag v-else-if="userStore.isInvited" type="success" size="small" effect="dark">普通会员</el-tag>
          <el-tag v-else type="info" size="small" effect="dark">基础用户</el-tag>
        </div>
        <div v-if="userStore.user?.email" class="user-email">{{ userStore.user.email }}</div>
      </div>
    </div>

    <div v-if="!userStore.isInvited && !userStore.isAdmin" class="invite-card glass-card">
      <div class="invite-title">
        <el-icon :size="18" color="#FF7D00"><Unlock /></el-icon>
        <span>激活会员权限</span>
      </div>
      <p class="invite-desc">输入邀请码解锁实时监控、设备管理等核心功能</p>
      <div class="invite-input-row">
        <el-input v-model="inviteCode" placeholder="请输入邀请码" size="default" clearable />
        <el-button type="primary" size="default" @click="handleActivate" :loading="activating">激活</el-button>
      </div>
    </div>
    
    <div class="menu-section glass-card">
      <div class="menu-group">
        <div class="menu-item" @click="$router.push('/')">
          <el-icon :size="18"><DataAnalysis /></el-icon>
          <span>实时监控</span>
          <el-icon class="arrow"><ArrowRight /></el-icon>
        </div>
        <div class="menu-item" @click="$router.push('/devices')">
          <el-icon :size="18"><Monitor /></el-icon>
          <span>设备管理</span>
          <el-icon class="arrow"><ArrowRight /></el-icon>
        </div>
        <div class="menu-item" @click="$router.push('/history')">
          <el-icon :size="18"><Clock /></el-icon>
          <span>历史数据</span>
          <el-icon class="arrow"><ArrowRight /></el-icon>
        </div>
        <div class="menu-item" @click="$router.push('/alerts')">
          <el-icon :size="18"><WarningFilled /></el-icon>
          <span>预警记录</span>
          <el-icon class="arrow"><ArrowRight /></el-icon>
        </div>
      </div>
      
      <div class="divider"></div>

      <div class="menu-group">
        <div class="menu-item" @click="showFontSize = !showFontSize">
          <el-icon :size="18"><Setting /></el-icon>
          <span>显示设置</span>
          <span class="menu-extra">{{ fontSize }}px</span>
          <el-icon class="arrow" :style="{transform: showFontSize ? 'rotate(90deg)' : ''}"><ArrowRight /></el-icon>
        </div>
        <transition name="expand">
          <div v-if="showFontSize" class="font-size-panel">
            <div class="font-size-row">
              <span class="fs-label">小</span>
              <el-slider v-model="fontSize" :min="12" :max="20" :step="1" :show-tooltip="false" style="flex:1" />
              <span class="fs-label">大</span>
            </div>
            <div class="fs-preview" :style="{fontSize: fontSize + 'px'}">
              预览文字效果 Abc123
            </div>
          </div>
        </transition>
      </div>
      
      <div class="divider"></div>
      
      <div class="menu-group">
        <div class="menu-item danger" @click="handleLogout">
          <el-icon :size="18"><SwitchButton /></el-icon>
          <span>退出登录</span>
        </div>
      </div>
    </div>
    
    <div class="app-info glass-card">
      <div class="app-logo-small">
        <img src="/logo.png" alt="火睛" />
      </div>
      <div class="app-detail">
        <div class="app-name">火睛智控中心</div>
        <div class="app-version">V10.0 移动端</div>
        <div class="app-desc">智能火灾风险感知与预警平台</div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, watch, onMounted } from 'vue'
import { useUserStore } from '@/stores/user'
import { useRouter } from 'vue-router'
import { ElMessageBox, ElMessage } from 'element-plus'
import { DataAnalysis, Clock, WarningFilled, Monitor, ArrowRight, SwitchButton, Unlock, Setting } from '@element-plus/icons-vue'

const userStore = useUserStore()
const router = useRouter()

const inviteCode = ref('')
const activating = ref(false)
const showFontSize = ref(false)
const fontSize = ref(parseInt(localStorage.getItem('mobile-font-size') || '14'))

async function handleActivate() {
  if (!inviteCode.value.trim()) {
    ElMessage.warning('请输入邀请码')
    return
  }
  activating.value = true
  try {
    await userStore.activateInvite(inviteCode.value.trim())
    ElMessage.success('激活成功，已解锁全部功能')
    inviteCode.value = ''
  } catch (e) {
    ElMessage.error('邀请码无效或已过期')
  } finally {
    activating.value = false
  }
}

function applyFontSize(val) {
  document.documentElement.style.setProperty('--app-font-size', val + 'px')
  document.documentElement.setAttribute('data-font-size', val)
  localStorage.setItem('mobile-font-size', val)
  window.dispatchEvent(new CustomEvent('font-size-change', { detail: val }))
}

watch(fontSize, (val) => {
  applyFontSize(val)
})

onMounted(() => {
  applyFontSize(fontSize.value)
})

async function handleLogout() {
  try {
    await ElMessageBox.confirm('确定要退出登录吗？', '提示')
    userStore.logout()
    ElMessage.success('已退出')
    router.push('/login')
  } catch (e) {}
}
</script>

<style scoped>
.profile-header {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 20px;
  margin-bottom: 14px;
}

.avatar-wrap {
  flex-shrink: 0;
}

.username {
  font-size: 18px;
  font-weight: 700;
  color: #1a1a2e;
  margin-bottom: 6px;
}

.user-email {
  font-size: 12px;
  color: #9ca3b8;
  margin-top: 4px;
}

.invite-card {
  padding: 16px;
  margin-bottom: 14px;
  border: 1px solid rgba(255,125,0,0.15);
  background: linear-gradient(135deg, rgba(255,125,0,0.03), rgba(255,125,0,0.01));
}

.invite-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 15px;
  font-weight: 600;
  color: #1a1a2e;
  margin-bottom: 6px;
}

.invite-desc {
  font-size: 12px;
  color: #6b7394;
  margin-bottom: 12px;
}

.invite-input-row {
  display: flex;
  gap: 8px;
}

.menu-section {
  padding: 4px;
  margin-bottom: 14px;
}

.menu-group {
  padding: 4px 0;
}

.menu-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 16px;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.2s;
  color: #444d66;
  font-size: 14px;
}

.menu-item:active {
  background: #f0f2f7;
}

.menu-item .arrow {
  margin-left: auto;
  color: #c0c4cc;
  font-size: 14px;
  transition: transform 0.2s;
}

.menu-extra {
  margin-left: auto;
  margin-right: 8px;
  font-size: 12px;
  color: #9ca3b8;
}

.menu-item.danger {
  color: #f44336;
}

.divider {
  height: 1px;
  background: rgba(0,0,0,0.06);
  margin: 4px 12px;
}

.font-size-panel {
  padding: 12px 16px;
  background: #f8f9fc;
  border-radius: 8px;
  margin: 4px 8px;
}

.font-size-row {
  display: flex;
  align-items: center;
  gap: 10px;
}

.fs-label {
  font-size: 11px;
  color: #9ca3b8;
  flex-shrink: 0;
}

.fs-preview {
  margin-top: 8px;
  padding: 8px;
  background: #fff;
  border-radius: 6px;
  color: #444d66;
  text-align: center;
  border: 1px dashed rgba(0,0,0,0.08);
}

.expand-enter-active,
.expand-leave-active {
  transition: all 0.25s ease;
  overflow: hidden;
}
.expand-enter-from,
.expand-leave-to {
  opacity: 0;
  max-height: 0;
  padding-top: 0;
  padding-bottom: 0;
  margin-top: 0;
  margin-bottom: 0;
}
.expand-enter-to,
.expand-leave-from {
  max-height: 200px;
}

.app-info {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 16px;
}

.app-logo-small img {
  width: 40px;
  height: 40px;
  object-fit: contain;
}

.app-name {
  font-size: 14px;
  font-weight: 600;
  color: #1a1a2e;
  margin-bottom: 2px;
}

.app-version {
  font-size: 11px;
  color: #165DFF;
  font-weight: 500;
  margin-bottom: 4px;
}

.app-desc {
  font-size: 11px;
  color: #9ca3b8;
}
</style>
