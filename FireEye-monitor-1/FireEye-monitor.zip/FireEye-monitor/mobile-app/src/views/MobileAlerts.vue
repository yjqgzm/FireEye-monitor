<template>
  <div class="alerts-page page-container">
    <h2 class="page-title">预警记录</h2>
    
    <div class="stats-row">
      <div class="mini-stat">
        <span class="mini-val">{{ alerts.length }}</span>
        <span class="mini-label">总预警</span>
      </div>
      <div class="mini-stat pending">
        <span class="mini-val">{{ pendingCount }}</span>
        <span class="mini-label">待处理</span>
      </div>
      <div class="mini-stat handled">
        <span class="mini-val">{{ handledCount }}</span>
        <span class="mini-label">已处理</span>
      </div>
      <div class="mini-stat urgent">
        <span class="mini-val">{{ urgentCount }}</span>
        <span class="mini-label">紧急</span>
      </div>
    </div>

    <div class="filter-tabs">
      <span :class="['tab', { active: filter === 'all' }]" @click="filter = 'all'">全部</span>
      <span :class="['tab', { active: filter === 'pending' }]" @click="filter = 'pending'">
        待处理
        <el-badge :value="pendingCount" :hidden="pendingCount === 0" type="danger" />
      </span>
      <span :class="['tab', { active: filter === 'handled' }]" @click="filter = 'handled'">已处理</span>
      <span :class="['tab', { active: filter === 'urgent' }]" @click="filter = 'urgent'">紧急</span>
    </div>

    <div class="alert-list">
      <TransitionGroup name="slide-up">
        <div
          v-for="alert in filteredAlerts"
          :key="alert.id"
          class="alert-card"
          :class="'level-' + alert.alert_level + (alert.alert_type === 'smoke_detected' ? ' smoke' : '')"
        >
          <div class="alert-header">
            <el-tag size="small" :type="getAlertTagType(alert.alert_level)" effect="dark">
              {{ alert.alert_type === 'smoke_detected' ? '烟雾' : getAlertLevelName(alert.alert_level) }}
            </el-tag>
            <el-tag v-if="alert.status === 'pending'" size="small" type="danger" effect="plain">待处理</el-tag>
            <el-tag v-else size="small" type="info" effect="plain">已处理</el-tag>
          </div>
          
          <div class="alert-body">
            <div class="alert-device">{{ alert.device_name }}</div>
            <div class="alert-desc">{{ alert.message }}</div>
            <div class="alert-data-row" v-if="alert.temperature">
              <span class="temp-val" :class="getTempClass(alert.temperature)">{{ alert.temperature?.toFixed(1) }}°C</span>
              <span v-if="alert.temp_rise_rate" class="rate-val">↑ {{ alert.temp_rise_rate.toFixed(1) }}/min</span>
            </div>
          </div>

          <div v-if="alert.ai_analysis" class="ai-preview" @click="showAIDetail(alert)">
            <el-icon :size="12" color="#165DFF"><View /></el-icon>
            <span>查看AI分析结果</span>
          </div>
          
          <div class="alert-footer">
            <span class="alert-time">{{ formatTime(alert.created_at) }}</span>
            <div class="alert-btns">
              <el-button v-if="alert.status === 'pending'" size="small" type="primary" link @click="handleAlert(alert)">处置</el-button>
              <el-button v-if="alert.alert_level >= 2 && !alert.ai_analysis" size="small" type="success" link @click="triggerAI(alert)">AI分析</el-button>
            </div>
          </div>
        </div>
      </TransitionGroup>
      <el-empty v-if="filteredAlerts.length === 0" description="暂无预警记录" :image-size="60" />
    </div>

    <el-dialog v-model="showAIDialog" title="AI智能分析" width="90%" :close-on-click-modal="false">
      <div v-if="aiLoading" class="ai-loading">
        <el-icon class="is-loading" :size="24"><Loading /></el-icon>
        <span>AI正在分析中...</span>
      </div>
      <div v-else-if="aiResult" class="ai-result" v-html="formatAIResult(aiResult)"></div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import api from '@/api'
import { ElMessage, ElMessageBox } from 'element-plus'
import { View, Loading } from '@element-plus/icons-vue'

const alerts = ref([])
const filter = ref('all')
let timer = null

const showAIDialog = ref(false)
const aiLoading = ref(false)
const aiResult = ref('')

const pendingCount = computed(() => alerts.value.filter(a => a.status === 'pending').length)
const handledCount = computed(() => alerts.value.filter(a => a.status === 'handled').length)
const urgentCount = computed(() => alerts.value.filter(a => a.alert_level === 3).length)

const filteredAlerts = computed(() => {
  if (filter.value === 'all') return alerts.value
  if (filter.value === 'urgent') return alerts.value.filter(a => a.alert_level === 3)
  return alerts.value.filter(a => a.status === filter.value)
})

async function fetchAlerts() {
  try {
    const res = await api.get('/api/alerts?limit=50')
    alerts.value = res
  } catch (e) {}
}

async function handleAlert(alert) {
  try {
    await ElMessageBox.confirm('确认处理此预警？', '提示')
    await api.put(`/api/alerts/${alert.id}/handle`, { status: 'handled', handling_notes: '已通过APP处理' })
    ElMessage.success('已处理')
    fetchAlerts()
  } catch (e) {}
}

async function triggerAI(alert) {
  showAIDialog.value = true
  aiLoading.value = true
  aiResult.value = ''
  try {
    const res = await api.post(`/api/alerts/${alert.id}/ai-analysis`)
    aiResult.value = res.ai_analysis || res.analysis || '分析完成'
    alert.ai_analysis = aiResult.value
  } catch (e) {
    aiResult.value = 'AI分析失败，请稍后重试'
  } finally {
    aiLoading.value = false
  }
}

function showAIDetail(alert) {
  aiResult.value = alert.ai_analysis
  aiLoading.value = false
  showAIDialog.value = true
}

function formatAIResult(text) {
  if (!text) return ''
  return text.replace(/\n/g, '<br/>')
}

function getAlertLevelName(level) {
  return { 1: '提示', 2: '警告', 3: '紧急' }[level] || '未知'
}

function getAlertTagType(level) {
  return { 1: 'info', 2: 'warning', 3: 'danger' }[level] || 'info'
}

function getTempClass(temp) {
  if (!temp) return ''
  if (temp >= 60) return 'danger'
  if (temp >= 45) return 'warning'
  return 'normal'
}

function formatTime(t) {
  if (!t) return ''
  const d = new Date(t)
  return `${d.getMonth()+1}/${d.getDate()} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`
}

onMounted(() => {
  fetchAlerts()
  timer = setInterval(fetchAlerts, 3000)
})

onUnmounted(() => {
  if (timer) clearInterval(timer)
})
</script>

<style scoped>
.stats-row {
  display: flex;
  gap: 8px;
  margin-bottom: 14px;
}

.mini-stat {
  flex: 1;
  text-align: center;
  padding: 10px 4px;
  background: #fff;
  border-radius: 10px;
  border: 1px solid rgba(0,0,0,0.06);
  box-shadow: 0 1px 4px rgba(0,0,0,0.04);
}

.mini-val {
  display: block;
  font-size: 20px;
  font-weight: 700;
  color: #1a1a2e;
  line-height: 1.2;
}

.mini-stat.pending .mini-val { color: #ff9800; }
.mini-stat.handled .mini-val { color: #00c853; }
.mini-stat.urgent .mini-val { color: #f44336; }

.mini-label {
  font-size: 10px;
  color: #9ca3b8;
}

.filter-tabs {
  display: flex;
  gap: 8px;
  margin-bottom: 14px;
  overflow-x: auto;
}

.tab {
  padding: 6px 14px;
  border-radius: 20px;
  font-size: 13px;
  color: #6b7394;
  background: #fff;
  cursor: pointer;
  transition: all 0.25s;
  display: flex;
  align-items: center;
  gap: 6px;
  box-shadow: 0 1px 4px rgba(0,0,0,0.04);
  white-space: nowrap;
}

.tab.active {
  background: var(--primary-color);
  color: #fff;
}

.alert-list {
  margin-bottom: 16px;
}

.alert-card {
  padding: 12px 14px;
  background: #fff;
  border-radius: 12px;
  margin-bottom: 10px;
  border-left: 3px solid transparent;
  box-shadow: 0 1px 4px rgba(0,0,0,0.04);
}
.alert-card.level-1 { border-left-color: #2196f3; }
.alert-card.level-2 { border-left-color: #ff9800; }
.alert-card.level-3 { border-left-color: #f44336; }
.alert-card.smoke {
  background: linear-gradient(135deg, rgba(156,39,176,0.04), rgba(244,67,54,0.04));
  border-left-color: #9c27b0;
}

.alert-header {
  display: flex;
  gap: 8px;
  margin-bottom: 8px;
}

.alert-body {
  margin-bottom: 8px;
}

.alert-device {
  font-size: 14px;
  font-weight: 600;
  color: #1a1a2e;
  margin-bottom: 4px;
}

.alert-desc {
  font-size: 12px;
  color: #6b7394;
  line-height: 1.5;
}

.alert-data-row {
  display: flex;
  gap: 12px;
  margin-top: 6px;
}

.temp-val {
  font-size: 15px;
  font-weight: 700;
}
.temp-val.normal { color: #00c853; }
.temp-val.warning { color: #ff9800; }
.temp-val.danger { color: #f44336; }

.rate-val {
  font-size: 12px;
  color: #6b7394;
}

.ai-preview {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 6px 10px;
  background: rgba(22,93,255,0.04);
  border-radius: 8px;
  font-size: 12px;
  color: #165DFF;
  cursor: pointer;
  margin-bottom: 8px;
}

.alert-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 8px;
  border-top: 1px solid rgba(0,0,0,0.06);
}

.alert-time {
  font-size: 11px;
  color: #9ca3b8;
}

.alert-btns {
  display: flex;
  gap: 4px;
}

.ai-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  padding: 40px;
  color: #6b7394;
  font-size: 14px;
}

.ai-result {
  font-size: 14px;
  line-height: 1.8;
  color: #444d66;
  white-space: pre-wrap;
}

.slide-up-enter-active,
.slide-up-leave-active {
  transition: all 0.3s ease;
}
.slide-up-enter-from {
  opacity: 0;
  transform: translateY(12px);
}
.slide-up-leave-to {
  opacity: 0;
  transform: translateX(-12px);
}
</style>
