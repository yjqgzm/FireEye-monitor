<template>
  <div class="history-page page-container">
    <h2 class="page-title">历史数据</h2>
    
    <div class="stats-row">
      <div class="mini-stat">
        <span class="mini-val temp">{{ stats.maxTemp }}</span>
        <span class="mini-label">最高温度</span>
      </div>
      <div class="mini-stat">
        <span class="mini-val avg">{{ stats.avgTemp }}</span>
        <span class="mini-label">平均温度</span>
      </div>
      <div class="mini-stat">
        <span class="mini-val smoke">{{ stats.maxSmoke }}</span>
        <span class="mini-label">最高烟雾</span>
      </div>
      <div class="mini-stat">
        <span class="mini-val alert">{{ stats.alertCount }}</span>
        <span class="mini-label">预警次数</span>
      </div>
    </div>

    <div class="filter-bar">
      <el-select v-model="filterDevice" placeholder="选择设备" clearable size="default" @change="fetchHistory" style="flex:1">
        <el-option v-for="d in devices" :key="d.id" :label="d.name || d.device_id" :value="d.id" />
      </el-select>
      <div class="time-shortcuts">
        <span :class="['shortcut', { active: timeRange === 'today' }]" @click="setTimeRange('today')">今天</span>
        <span :class="['shortcut', { active: timeRange === '7d' }]" @click="setTimeRange('7d')">7天</span>
        <span :class="['shortcut', { active: timeRange === '30d' }]" @click="setTimeRange('30d')">30天</span>
      </div>
    </div>

    <div class="chart-section">
      <div class="glass-card chart-card">
        <h4>温度趋势</h4>
        <div ref="trendRef" class="chart-box"></div>
      </div>
      <div class="glass-card chart-card">
        <h4>环境趋势</h4>
        <div ref="envRef" class="chart-box"></div>
      </div>
    </div>

    <div class="table-section glass-card">
      <h4>历史记录 <small v-if="historyData.length" style="font-weight:400;color:#9ca3b8">共{{ historyData.length }}条</small></h4>
      <el-table :data="pagedData" v-loading="loading" size="small" style="width:100%" :header-cell-style="{background:'#f8f9fc',color:'#6b7394',fontSize:'12px'}" :cell-style="{fontSize:'12px',padding:'6px 0'}">
        <el-table-column prop="timestamp" label="时间" min-width="130">
          <template #default="{ row }">{{ formatTimeShort(row.timestamp) }}</template>
        </el-table-column>
        <el-table-column label="物温" width="70" align="center">
          <template #default="{ row }"><span :style="{color: row.temperature>=60?'#f44336':row.temperature>=45?'#ff9800':''}">{{ row.temperature?.toFixed(1) }}</span></template>
        </el-table-column>
        <el-table-column label="环温" width="65" align="center">
          <template #default="{ row }">{{ row.ambient_temp?.toFixed(1) }}</template>
        </el-table-column>
        <el-table-column label="湿度" width="60" align="center">
          <template #default="{ row }">{{ row.humidity?.toFixed(0) }}%</template>
        </el-table-column>
        <el-table-column label="烟雾" width="60" align="center">
          <template #default="{ row }">
            <span :style="{color:row.smoke_detected===1?'#f44336':''}">{{ row.smoke_value||0 }}</span>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-wrap" v-if="historyData.length > pageSize">
        <el-pagination small layout="prev, pager, next" :total="historyData.length" :page-size="pageSize" v-model:current-page="currentPage" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, nextTick } from 'vue'
import * as echarts from 'echarts'
import api from '@/api'

const devices = ref([])
const historyData = ref([])
const filterDevice = ref('')
const timeRange = ref('today')
const loading = ref(false)
const currentPage = ref(1)
const pageSize = 15

const trendRef = ref(null)
const envRef = ref(null)
let trendChart = null
let envChart = null
let timer = null

const pagedData = computed(() => {
  const start = (currentPage.value - 1) * pageSize
  return historyData.value.slice(start, start + pageSize)
})

const stats = computed(() => {
  const data = historyData.value
  if (!data.length) return { maxTemp: '--', avgTemp: '--', maxSmoke: '--', alertCount: '--' }
  const temps = data.map(d => d.temperature).filter(Boolean)
  const smokes = data.map(d => d.smoke_value || 0)
  return {
    maxTemp: temps.length ? Math.max(...temps).toFixed(1) + '°' : '--',
    avgTemp: temps.length ? (temps.reduce((a, b) => a + b, 0) / temps.length).toFixed(1) + '°' : '--',
    maxSmoke: smokes.length ? Math.max(...smokes) : '--',
    alertCount: data.filter(d => d.smoke_detected === 1 || (d.temperature && d.temperature >= 60)).length
  }
})

async function fetchDevices() {
  try {
    const res = await api.get('/api/devices')
    devices.value = res
    if (res.length > 0 && !filterDevice.value) {
      filterDevice.value = res[0].id
      await fetchHistory()
    }
  } catch (e) {}
}

function getHours() {
  if (timeRange.value === 'today') {
    const now = new Date()
    return Math.max(1, Math.ceil((now - new Date(now.getFullYear(), now.getMonth(), now.getDate())) / 3600000))
  } else if (timeRange.value === '7d') {
    return 168
  } else if (timeRange.value === '30d') {
    return 720
  }
  return 24
}

async function fetchHistory() {
  if (!filterDevice.value) return
  loading.value = true
  try {
    const hours = getHours()
    const res = await api.get(`/api/data/trend?device_id=${filterDevice.value}&hours=${hours}`)
    historyData.value = res.data || []
    currentPage.value = 1
    updateCharts()
  } catch (e) {
    console.error(e)
  } finally {
    loading.value = false
  }
}

function setTimeRange(range) {
  timeRange.value = range
  fetchHistory()
}

function updateCharts() {
  nextTick(() => {
    const data = historyData.value
    if (!data.length) return

    const times = data.map(d => {
      const dt = new Date(d.timestamp)
      return `${String(dt.getHours()).padStart(2,'0')}:${String(dt.getMinutes()).padStart(2,'0')}`
    })
    const temps = data.map(d => d.temperature)
    const ambientTemps = data.map(d => d.ambient_temp)
    const humidities = data.map(d => d.humidity)
    const smokeValues = data.map(d => d.smoke_value || 0)

    if (trendRef.value) {
      if (!trendChart) trendChart = echarts.init(trendRef.value)
      trendChart.setOption({
        tooltip: { trigger: 'axis', confine: true },
        legend: { data: ['物体温度', '烟雾浓度'], textStyle: { color: '#6b7394', fontSize: 10 }, top: 0 },
        grid: { left: '12%', right: '8%', bottom: '22%', top: '28px', containLabel: true },
        xAxis: { type: 'category', data: times, axisLine: { lineStyle: { color: '#ddd' } }, axisLabel: { color: '#6b7394', fontSize: 9, rotate: 30 } },
        yAxis: [
          { type: 'value', name: '°C', nameTextStyle: { color: '#6b7394', fontSize: 9 }, axisLine: { show: false }, axisLabel: { color: '#6b7394', fontSize: 9 }, splitLine: { lineStyle: { color: '#eee', type: 'dashed' } } },
          { type: 'value', nameTextStyle: { color: '#6b7394', fontSize: 9 }, axisLine: { show: false }, axisLabel: { color: '#6b7394', fontSize: 9 }, splitLine: { show: false } }
        ],
        series: [
          { name: '物体温度', type: 'line', smooth: true, data: temps, lineStyle: { color: '#165DFF', width: 2 }, areaStyle: { color: new echarts.graphic.LinearGradient(0,0,0,1,[{offset:0,color:'rgba(22,93,255,0.15)'},{offset:1,color:'rgba(22,93,255,0)'}]) }, symbol: 'none' },
          { name: '烟雾浓度', type: 'bar', yAxisIndex: 1, barWidth: '45%', data: smokeValues, itemStyle: { color: new echarts.graphic.LinearGradient(0,0,0,1,[{offset:0,color:'#FF7D00'},{offset:1,color:'#FFAB40'}]), borderRadius: [2,2,0,0] } }
        ]
      }, true)
    }

    if (envRef.value) {
      if (!envChart) envChart = echarts.init(envRef.value)
      envChart.setOption({
        tooltip: { trigger: 'axis', confine: true },
        legend: { data: ['环境温度', '环境湿度'], textStyle: { color: '#6b7394', fontSize: 10 }, top: 0 },
        grid: { left: '12%', right: '4%', bottom: '22%', top: '28px', containLabel: true },
        xAxis: { type: 'category', data: times, axisLine: { lineStyle: { color: '#ddd' } }, axisLabel: { color: '#6b7394', fontSize: 9, rotate: 30 } },
        yAxis: [
          { type: 'value', name: '°C', nameTextStyle: { color: '#6b7394', fontSize: 9 }, axisLine: { show: false }, axisLabel: { color: '#6b7394', fontSize: 9 }, splitLine: { lineStyle: { color: '#eee', type: 'dashed' } } },
          { type: 'value', name: '%', nameTextStyle: { color: '#6b7394', fontSize: 9 }, axisLine: { show: false }, axisLabel: { color: '#6b7394', fontSize: 9 }, splitLine: { show: false } }
        ],
        series: [
          { name: '环境温度', type: 'line', smooth: true, symbol: 'circle', symbolSize: 5, data: ambientTemps, lineStyle: { color: '#0FC6C2', width: 2 }, itemStyle: { color: '#0FC6C2' } },
          { name: '环境湿度', type: 'line', smooth: true, yAxisIndex: 1, symbol: 'circle', symbolSize: 5, data: humidities, lineStyle: { color: '#00B42A', width: 2 }, itemStyle: { color: '#00B42A' } }
        ]
      }, true)
    }
  })
}

function formatTimeShort(t) {
  if (!t) return ''
  const d = new Date(t)
  return `${d.getMonth()+1}/${d.getDate()} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`
}

onMounted(() => {
  fetchDevices()
})

onUnmounted(() => {
  if (timer) clearInterval(timer)
  trendChart?.dispose()
  envChart?.dispose()
})
</script>

<style scoped>
.stats-row {
  display: flex;
  gap: 8px;
  margin-bottom: 14px;
}

.mini-stat {
  flex: 1;
  text-align: center;
  padding: 10px 4px;
  background: #fff;
  border-radius: 10px;
  border: 1px solid rgba(0,0,0,0.06);
  box-shadow: 0 1px 4px rgba(0,0,0,0.04);
}

.mini-val {
  display: block;
  font-size: 16px;
  font-weight: 700;
  color: #1a1a2e;
  line-height: 1.2;
}

.mini-val.temp { color: #f44336; }
.mini-val.avg { color: #165DFF; }
.mini-val.smoke { color: #FF7D00; }
.mini-val.alert { color: #f44336; }

.mini-label {
  font-size: 10px;
  color: #9ca3b8;
}

.filter-bar {
  display: flex;
  gap: 8px;
  margin-bottom: 14px;
  align-items: center;
}

.time-shortcuts {
  display: flex;
  gap: 4px;
}

.shortcut {
  padding: 4px 10px;
  border-radius: 12px;
  font-size: 12px;
  color: #9ca3b8;
  background: #fff;
  cursor: pointer;
  transition: all 0.2s;
  border: 1px solid rgba(0,0,0,0.06);
}

.shortcut.active {
  background: #165DFF;
  color: #fff;
  border-color: #165DFF;
}

.chart-section {
  margin-bottom: 14px;
}

.chart-card {
  padding: 12px;
  margin-bottom: 10px;
}

.chart-card h4 {
  font-size: 13px;
  font-weight: 600;
  color: #444d66;
  margin-bottom: 8px;
}

.chart-box {
  height: 180px;
}

.table-section {
  padding: 12px;
}

.table-section h4 {
  font-size: 13px;
  font-weight: 600;
  color: #444d66;
  margin-bottom: 10px;
}

.pagination-wrap {
  margin-top: 10px;
  display: flex;
  justify-content: center;
}
</style>
