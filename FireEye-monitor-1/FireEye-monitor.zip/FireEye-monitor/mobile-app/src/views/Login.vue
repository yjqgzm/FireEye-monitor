<template>
  <div class="login-page">
    <div class="login-bg">
      <div class="bg-gradient"></div>
      <div class="bg-particles">
        <div class="particle" v-for="i in 6" :key="i" :style="{ animationDelay: `${i * 0.8}s`, left: `${10 + i * 15}%` }"></div>
      </div>
    </div>
    <div class="login-content">
      <div class="login-logo">
        <img src="/logo.png" alt="火睛" class="logo-img" />
      </div>
      <h1 class="login-title">火睛智控中心</h1>
      <p class="login-subtitle">智能火灾风险感知与预警平台</p>
      <p class="login-en">FireGuard Intelligent Control Center</p>
      
      <el-form ref="formRef" :model="form" :rules="rules" @submit.prevent="handleLogin" class="login-form">
        <el-form-item prop="username">
          <el-input 
            v-model="form.username" 
            placeholder="请输入邮箱"
            size="large"
            :prefix-icon="User"
          />
        </el-form-item>
        <el-form-item prop="password">
          <el-input 
            v-model="form.password" 
            type="password"
            placeholder="请输入密码"
            size="large"
            :prefix-icon="Lock"
            show-password
            @keyup.enter="handleLogin"
          />
        </el-form-item>

        <div v-if="captchaEnabled" class="captcha-row">
          <el-form-item prop="captcha" style="flex:1;margin-bottom:0">
            <el-input 
              v-model="form.captcha"
              placeholder="验证码"
              size="large"
              maxlength="4"
            />
          </el-form-item>
          <div class="captcha-img" @click="refreshCaptcha">
            <canvas ref="captchaCanvas" width="100" height="40"></canvas>
          </div>
        </div>

        <transition name="tip-slide">
          <div v-if="securityTip" class="security-tip" :class="securityTipType">
            <el-icon :size="14"><WarningFilled /></el-icon>
            <span>{{ securityTip }}</span>
          </div>
        </transition>

        <el-button 
          type="primary" 
          size="large"
          :loading="loading"
          @click="handleLogin"
          class="login-btn"
        >
          {{ loading ? '登录中...' : '登 录' }}
        </el-button>
      </el-form>
      
      <div class="login-footer">
        <div class="demo-line">
          <span>演示: admin@example.com / 123456</span>
          <el-button link type="primary" size="small" @click="fillDemo">一键填充</el-button>
        </div>
        <div class="reg-line">
          <span>没有账户？</span>
          <router-link to="/register" class="reg-link">立即注册</router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { User, Lock, WarningFilled } from '@element-plus/icons-vue'
import { useUserStore } from '@/stores/user'
import { ElMessage } from 'element-plus'

const router = useRouter()
const userStore = useUserStore()
const formRef = ref(null)
const loading = ref(false)
const captchaEnabled = ref(true)
const captchaCanvas = ref(null)
const captchaCode = ref('')
const loginFailCount = ref(0)
const securityTip = ref('')
const securityTipType = ref('warning')

const form = reactive({
  username: '',
  password: '',
  captcha: ''
})

const rules = {
  username: [{ required: true, message: '请输入邮箱', trigger: 'blur' }],
  password: [{ required: true, message: '请输入密码', trigger: 'blur' }]
}

function generateCaptcha() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  let code = ''
  for (let i = 0; i < 4; i++) code += chars[Math.floor(Math.random() * chars.length)]
  return code
}

function drawCaptcha() {
  if (!captchaCanvas.value) return
  const canvas = captchaCanvas.value
  const ctx = canvas.getContext('2d')
  const w = canvas.width
  const h = canvas.height
  ctx.clearRect(0, 0, w, h)

  ctx.fillStyle = '#F2F3F5'
  ctx.fillRect(0, 0, w, h)

  for (let i = 0; i < 4; i++) {
    ctx.strokeStyle = 'rgba(22,93,255,0.08)'
    ctx.beginPath()
    ctx.moveTo(Math.random() * w, Math.random() * h)
    ctx.lineTo(Math.random() * w, Math.random() * h)
    ctx.stroke()
  }

  for (let i = 0; i < 30; i++) {
    ctx.fillStyle = 'rgba(22,93,255,0.15)'
    ctx.beginPath()
    ctx.arc(Math.random() * w, Math.random() * h, 1, 0, 2 * Math.PI)
    ctx.fill()
  }

  captchaCode.value = generateCaptcha()
  const colors = ['#165DFF', '#0FC6C2', '#FF7D00', '#00B42A']
  for (let i = 0; i < captchaCode.value.length; i++) {
    ctx.save()
    ctx.font = `bold ${16 + Math.random() * 4}px 'Consolas',monospace`
    ctx.fillStyle = colors[i % colors.length]
    const x = 10 + i * 22
    const y = 26 + Math.random() * 6
    ctx.translate(x, y)
    ctx.rotate((Math.random() - 0.5) * 0.4)
    ctx.fillText(captchaCode.value[i], 0, 0)
    ctx.restore()
  }
}

function refreshCaptcha() {
  form.captcha = ''
  nextTick(() => drawCaptcha())
}

function fillDemo() {
  form.username = 'admin@example.com'
  form.password = '123456'
}

function showSecurityTip(msg, type = 'warning') {
  securityTip.value = msg
  securityTipType.value = type
  setTimeout(() => { securityTip.value = '' }, 5000)
}

async function handleLogin() {
  if (!form.username) { ElMessage.warning('请输入邮箱'); return }
  if (!form.password) { ElMessage.warning('请输入密码'); return }

  if (captchaEnabled.value && form.captcha.toUpperCase() !== captchaCode.value.toUpperCase()) {
    ElMessage.error('验证码错误')
    refreshCaptcha()
    return
  }

  loading.value = true
  try {
    await userStore.login(form.username, form.password)
    ElMessage.success('登录成功')
    router.push('/')
  } catch (e) {
    loginFailCount.value++
    refreshCaptcha()
    form.captcha = ''
    if (loginFailCount.value >= 3) {
      showSecurityTip('连续登录失败次数过多，请确认账号安全', 'warning')
    } else if (loginFailCount.value >= 2) {
      showSecurityTip('密码错误，请仔细核对后重试', 'info')
    }
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  nextTick(() => {
    if (captchaEnabled.value) drawCaptcha()
  })
})
</script>

<style scoped>
.login-page {
  width: 100%;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
}

.login-bg {
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 0;
  z-index: 0;
}

.bg-gradient {
  width: 100%; height: 100%;
  background: linear-gradient(160deg, #070B14 0%, #0F172A 40%, #111827 70%, #070B14 100%);
}

.bg-particles {
  position: absolute;
  inset: 0;
  overflow: hidden;
}

.particle {
  position: absolute;
  width: 4px;
  height: 4px;
  border-radius: 50%;
  background: rgba(22, 93, 255, 0.3);
  bottom: -10px;
  animation: floatUp 8s ease-in infinite;
}

@keyframes floatUp {
  0% { transform: translateY(0) scale(1); opacity: 0; }
  10% { opacity: 1; }
  90% { opacity: 1; }
  100% { transform: translateY(-100vh) scale(0.5); opacity: 0; }
}

.login-content {
  position: relative;
  z-index: 1;
  width: 90%;
  max-width: 380px;
  padding: 36px 24px;
  text-align: center;
  background: rgba(255,255,255,0.95);
  border-radius: 20px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.3);
  backdrop-filter: blur(20px);
}

.login-logo {
  margin-bottom: 12px;
}

.logo-img {
  width: 64px;
  height: 64px;
  object-fit: contain;
}

.login-title {
  font-size: 26px;
  font-weight: 700;
  color: #0F172A;
  margin-bottom: 4px;
  letter-spacing: 2px;
}

.login-subtitle {
  font-size: 13px;
  color: #6b7394;
  margin-bottom: 2px;
}

.login-en {
  font-size: 10px;
  color: #9ca3b8;
  margin-bottom: 24px;
  font-family: 'Arial', sans-serif;
}

.login-form {
  margin-bottom: 16px;
}

.captcha-row {
  display: flex;
  gap: 8px;
  align-items: flex-start;
  margin-bottom: 18px;
}

.captcha-img {
  flex-shrink: 0;
  cursor: pointer;
  border-radius: 8px;
  overflow: hidden;
  border: 1px solid rgba(0,0,0,0.1);
  height: 40px;
}

.security-tip {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 12px;
  border-radius: 8px;
  font-size: 12px;
  margin-bottom: 12px;
  animation: tipIn 0.3s ease;
}

.security-tip.warning {
  background: rgba(255,152,0,0.08);
  color: #FF7D00;
  border: 1px solid rgba(255,152,0,0.15);
}

.security-tip.info {
  background: rgba(22,93,255,0.08);
  color: #165DFF;
  border: 1px solid rgba(22,93,255,0.15);
}

@keyframes tipIn {
  from { opacity: 0; transform: translateY(-6px); }
  to { opacity: 1; transform: translateY(0); }
}

.tip-slide-enter-active,
.tip-slide-leave-active {
  transition: all 0.3s ease;
}
.tip-slide-enter-from,
.tip-slide-leave-to {
  opacity: 0;
  transform: translateY(-6px);
}

.login-btn {
  width: 100%;
  height: 46px;
  font-size: 16px;
  font-weight: 600;
  border-radius: 10px;
  letter-spacing: 4px;
}

.login-footer {
  margin-top: 16px;
}

.demo-line {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  font-size: 11px;
  color: #9ca3b8;
  margin-bottom: 8px;
}

.reg-line {
  font-size: 12px;
  color: #9ca3b8;
}

.reg-link {
  color: #165DFF;
  text-decoration: none;
  font-weight: 500;
}
</style>
