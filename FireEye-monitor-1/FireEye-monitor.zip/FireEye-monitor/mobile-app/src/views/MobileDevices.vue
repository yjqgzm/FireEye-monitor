<template>
  <div class="devices-page page-container">
    <h2 class="page-title">设备管理</h2>
    
    <div class="device-list">
      <div
        v-for="device in devices"
        :key="device.device_id"
        class="device-card glass-card"
      >
        <div class="device-main">
          <div class="device-icon-wrap" :class="{ online: device.status === 'online' }">
            <el-icon :size="24"><Monitor /></el-icon>
          </div>
          <div class="device-info">
            <div class="device-name">{{ device.name || device.device_id }}</div>
            <div class="device-id">ID: {{ device.device_id }}</div>
            <div class="device-location">{{ device.location || '未设置位置' }}</div>
            <el-tag v-if="device.scene_type" size="small" type="info" effect="plain" class="scene-tag">
              {{ sceneNames[device.scene_type] || device.scene_type }}
            </el-tag>
          </div>
        </div>
        
        <div class="device-status-bar">
          <div :class="['status-tag', device.status]">
            <span class="dot"></span>
            {{ device.status === 'online' ? '在线' : '离线' }}
          </div>
          <span v-if="device.smoke_detected === 1" class="smoke-tag">
            <el-icon><WarningFilled /></el-icon> 烟雾报警
          </span>
        </div>
        
        <div class="sensor-grid">
          <div class="sensor-item">
            <span class="sensor-label">物体温度</span>
            <span class="sensor-value" :class="getTempClass(device.temperature)">
              {{ device.temperature?.toFixed(1) }}°C
            </span>
          </div>
          <div class="sensor-item">
            <span class="sensor-label">环境温度</span>
            <span class="sensor-value env">{{ device.ambient_temp?.toFixed(1) }}°C</span>
          </div>
          <div class="sensor-item">
            <span class="sensor-label">湿度</span>
            <span class="sensor-value humidity">{{ device.humidity?.toFixed(0) }}%</span>
          </div>
          <div class="sensor-item">
            <span class="sensor-label">烟雾浓度</span>
            <span class="sensor-value smoke" :style="{color: device.smoke_detected===1?'#f44336':''}">
              {{ device.smoke_value || 0 }}
            </span>
          </div>
          <div class="sensor-item">
            <span class="sensor-label">温升速率</span>
            <span class="sensor-value" :style="{color: (device.temp_rise_rate||0)>=2?'#f44336':(device.temp_rise_rate||0)>=1?'#ff9800':'#00c853'}">
              {{ (device.temp_rise_rate || 0).toFixed(1) }}°C/min
            </span>
          </div>
          <div class="sensor-item">
            <span class="sensor-label">最后上报</span>
            <span class="sensor-value time">{{ formatTime(device.last_seen) }}</span>
          </div>
        </div>
      </div>
      
      <el-empty v-if="devices.length === 0" description="暂无设备数据" :image-size="60" />
    </div>
    
    <div class="refresh-info">
      <el-button @click="fetchDevices" size="small" round :icon="Refresh">
        刷新设备列表
      </el-button>
      <span class="update-time">每3秒自动更新</span>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import api from '@/api'
import { Monitor, WarningFilled, Refresh } from '@element-plus/icons-vue'

const devices = ref([])
let timer = null

const sceneNames = {
  lab: '实验室',
  dormitory: '宿舍',
  warehouse: '仓库',
  shop: '商铺',
  power_room: '配电房'
}

async function fetchDevices() {
  try {
    const res = await api.get('/api/data/realtime')
    devices.value = res
  } catch (e) {}
}

function getTempClass(temp) {
  if (!temp) return ''
  if (temp >= 60) return 'danger'
  if (temp >= 45) return 'warning'
  return 'normal'
}

function formatTime(t) {
  if (!t) return '--'
  const d = new Date(t)
  return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`
}

onMounted(() => {
  fetchDevices()
  timer = setInterval(fetchDevices, 3000)
})

onUnmounted(() => {
  if (timer) clearInterval(timer)
})
</script>

<style scoped>
.device-list {
  margin-bottom: 16px;
}

.device-card {
  padding: 14px;
  margin-bottom: 12px;
}

.device-main {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
}

.device-icon-wrap {
  width: 48px; height: 48px;
  border-radius: 12px;
  background: rgba(255,82,82,0.08);
  color: #ff5252;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  transition: all 0.3s;
}
.device-icon-wrap.online {
  background: rgba(0,200,83,0.08);
  color: #00c853;
}

.device-name {
  font-size: 15px;
  font-weight: 600;
  color: #1a1a2e;
  margin-bottom: 2px;
}

.device-id {
  font-size: 11px;
  color: #9ca3b8;
  font-family: monospace;
}

.device-location {
  font-size: 11px;
  color: #6b7394;
  margin-top: 2px;
}

.scene-tag {
  margin-top: 4px;
  font-size: 10px;
}

.device-status-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}

.status-tag {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 3px 10px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 500;
}
.status-tag .dot {
  width: 6px; height: 6px; border-radius: 50%;
}
.status-tag.online {
  background: rgba(0,200,83,0.08);
  color: #00c853;
}
.status-tag.online .dot { background: #00c853; box-shadow: 0 0 4px rgba(0,200,83,0.35); }
.status-tag.offline {
  background: rgba(255,82,82,0.08);
  color: #ff5252;
}
.status-tag.offline .dot { background: #ff5252; }

.smoke-tag {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 11px;
  color: #f44336;
  font-weight: 500;
}

.sensor-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
}

.sensor-item {
  padding: 8px 10px;
  background: #f5f7fa;
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.sensor-label {
  font-size: 10px;
  color: #9ca3b8;
}

.sensor-value {
  font-size: 16px;
  font-weight: 700;
  color: #00c853;
}
.sensor-value.danger { color: #f44336; }
.sensor-value.warning { color: #ff9800; }
.sensor-value.env { color: #00bcd4; }
.sensor-value.humidity { color: #4caf50; }
.sensor-value.smoke { color: #ff9800; }
.sensor-value.time { color: #6b7394; font-size: 13px; }

.refresh-info {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 0;
}

.update-time {
  font-size: 11px;
  color: #9ca3b8;
}
</style>
