<template>
  <div class="mobile-layout" :style="{ zoom: fontZoom }">
    <transition name="banner-slide">
      <div v-if="hasHighAlert && !bannerDismissed" class="alert-banner">
        <div class="banner-edge"></div>
        <div class="banner-content">
          <el-icon :size="14"><WarningFilled /></el-icon>
          <span class="banner-text">高风险预警：{{ highAlertDevice }} 温度异常</span>
          <el-button size="small" type="danger" @click="goToAlerts" class="banner-btn">立即处理</el-button>
          <el-icon class="banner-close" @click="bannerDismissed = true"><Close /></el-icon>
        </div>
      </div>
    </transition>

    <div class="app-header">
      <div class="header-left">
        <img src="/logo.png" alt="" class="header-logo" />
        <span class="header-title">火睛智控中心</span>
      </div>
      <div class="header-right">
        <span v-if="userStore.isAdmin" class="role-badge admin">管理员</span>
        <span v-else-if="userStore.isInvited" class="role-badge member">会员</span>
        <span v-else class="role-badge basic">基础</span>
        <span class="online-dot"></span>
        <span class="online-text">在线</span>
      </div>
    </div>
    
    <div class="page-content">
      <router-view v-slot="{ Component }">
        <transition name="slide" mode="out-in">
          <component :is="Component" />
        </transition>
      </router-view>
    </div>
    
    <nav class="tab-bar safe-bottom">
      <router-link to="/" class="tab-item" :class="{ active: $route.path === '/' }">
        <el-icon :size="22"><DataAnalysis /></el-icon>
        <span>监控</span>
      </router-link>
      <router-link to="/devices" class="tab-item" :class="{ active: $route.path === '/devices' }">
        <el-icon :size="22"><Monitor /></el-icon>
        <span>设备</span>
      </router-link>
      <router-link to="/history" class="tab-item" :class="{ active: $route.path.startsWith('/history') }">
        <el-icon :size="22"><Clock /></el-icon>
        <span>历史</span>
      </router-link>
      <router-link to="/alerts" class="tab-item" :class="{ active: $route.path === '/alerts' }">
        <el-icon :size="22"><WarningFilled /></el-icon>
        <span>预警</span>
        <span v-if="pendingAlertCount > 0" class="tab-badge">{{ pendingAlertCount > 99 ? '99+' : pendingAlertCount }}</span>
      </router-link>
      <router-link to="/profile" class="tab-item" :class="{ active: $route.path === '/profile' }">
        <el-icon :size="22"><User /></el-icon>
        <span>我的</span>
      </router-link>
    </nav>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, watch } from 'vue'
import { useRouter } from 'vue-router'
import { DataAnalysis, Monitor, Clock, WarningFilled, User, Close } from '@element-plus/icons-vue'
import { useUserStore } from '@/stores/user'
import api from '@/api'

const router = useRouter()
const userStore = useUserStore()

const bannerDismissed = ref(false)
const alerts = ref([])
let timer = null

const savedFontSize = parseInt(localStorage.getItem('mobile-font-size') || '14')
const fontZoom = ref(savedFontSize / 14)

function checkFontZoom() {
  const fs = parseInt(localStorage.getItem('mobile-font-size') || '14')
  fontZoom.value = fs / 14
}

const hasHighAlert = computed(() => alerts.value.some(a => a.status === 'pending' && a.alert_level === 3))
const highAlertDevice = computed(() => {
  const a = alerts.value.find(a => a.status === 'pending' && a.alert_level === 3)
  return a?.device_name || ''
})
const pendingAlertCount = computed(() => alerts.value.filter(a => a.status === 'pending').length)

async function fetchAlerts() {
  try {
    const res = await api.get('/api/alerts?limit=20', { silent: true })
    alerts.value = res
  } catch (e) {}
}

function goToAlerts() {
  bannerDismissed.value = true
  router.push('/alerts')
}

onMounted(() => {
  fetchAlerts()
  timer = setInterval(fetchAlerts, 5000)
  window.addEventListener('font-size-change', (e) => {
    fontZoom.value = parseInt(e.detail) / 14
  })
})

onUnmounted(() => {
  if (timer) clearInterval(timer)
})
</script>

<style scoped>
.mobile-layout {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background: #f5f7fa;
}

.alert-banner {
  position: relative;
  background: linear-gradient(90deg, #f44336, #e53935);
  color: #fff;
  z-index: 100;
}

.banner-edge {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 3px;
  background: #ffcdd2;
}

.banner-content {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  font-size: 12px;
}

.banner-text {
  flex: 1;
  font-weight: 500;
}

.banner-btn {
  font-size: 11px !important;
  padding: 2px 8px !important;
  height: 24px !important;
}

.banner-close {
  cursor: pointer;
  opacity: 0.7;
}

.banner-slide-enter-active,
.banner-slide-leave-active {
  transition: all 0.3s ease;
}
.banner-slide-enter-from,
.banner-slide-leave-to {
  transform: translateY(-100%);
  opacity: 0;
}

.app-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 16px;
  background: #fff;
  border-bottom: 1px solid rgba(0,0,0,0.06);
}

.header-left {
  display: flex;
  align-items: center;
  gap: 8px;
}

.header-logo {
  width: 28px;
  height: 28px;
  object-fit: contain;
}

.header-title {
  font-size: 16px;
  font-weight: 700;
  color: #0F172A;
  letter-spacing: 1px;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 8px;
}

.role-badge {
  font-size: 10px;
  padding: 2px 8px;
  border-radius: 10px;
  font-weight: 500;
}

.role-badge.admin {
  background: rgba(255,152,0,0.1);
  color: #FF7D00;
}

.role-badge.member {
  background: rgba(0,180,42,0.08);
  color: #00B42A;
}

.role-badge.basic {
  background: rgba(134,144,156,0.08);
  color: #86909C;
}

.online-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #00c853;
  box-shadow: 0 0 4px rgba(0,200,83,0.4);
}

.online-text {
  font-size: 11px;
  color: #00c853;
  font-weight: 500;
}

.page-content {
  flex: 1;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}

.tab-bar {
  display: flex;
  align-items: center;
  justify-content: space-around;
  background: #fff;
  border-top: 1px solid rgba(0,0,0,0.06);
  padding: 6px 0;
  position: relative;
}

.tab-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  padding: 4px 12px;
  color: #9ca3b8;
  text-decoration: none;
  font-size: 10px;
  transition: color 0.2s;
  position: relative;
}

.tab-item.active {
  color: #165DFF;
}

.tab-item.active :deep(.el-icon) {
  color: #165DFF;
}

.tab-badge {
  position: absolute;
  top: 0;
  right: 4px;
  min-width: 16px;
  height: 16px;
  line-height: 16px;
  text-align: center;
  font-size: 9px;
  font-weight: 600;
  color: #fff;
  background: #f44336;
  border-radius: 8px;
  padding: 0 4px;
}

.slide-enter-active,
.slide-leave-active {
  transition: all 0.2s ease;
}
.slide-enter-from {
  opacity: 0;
  transform: translateX(10px);
}
.slide-leave-to {
  opacity: 0;
  transform: translateX(-10px);
}
</style>
