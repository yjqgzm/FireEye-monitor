<template>
  <div class="home-page page-container">
    <div class="stats-grid">
      <div class="stat-card" v-for="(stat, idx) in statsCards" :key="idx">
        <div class="stat-icon-wrap" :style="{ background: stat.bg }">
          <el-icon :size="18" :color="stat.color"><component :is="stat.icon" /></el-icon>
        </div>
        <div class="stat-info">
          <div class="stat-val">{{ stat.value }}</div>
          <div class="stat-label">{{ stat.label }}</div>
        </div>
      </div>
    </div>

    <div class="section-title">设备状态</div>
    <div class="device-list">
      <div
        v-for="device in devices"
        :key="device.device_id"
        class="device-card glass-card"
      >
        <div class="device-top">
          <div class="device-name-row">
            <span :class="['status-dot', device.status]"></span>
            <span class="device-name">{{ device.name || device.device_id }}</span>
            <el-tag size="small" :type="device.status === 'online' ? 'success' : 'danger'" effect="dark">
              {{ device.status === 'online' ? '在线' : '离线' }}
            </el-tag>
            <el-tag v-if="device.scene_type" size="small" type="info" effect="plain" class="scene-tag">
              {{ sceneNames[device.scene_type] || device.scene_type }}
            </el-tag>
          </div>
          <div class="temp-big" :class="getTempClass(device.temperature)">
            {{ device.temperature?.toFixed(1) }}°C
          </div>
        </div>
        <div class="device-details">
          <div class="detail-item">
            <span class="detail-label">环境</span>
            <span class="detail-val">{{ device.ambient_temp?.toFixed(1) }}°C</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">湿度</span>
            <span class="detail-val">{{ device.humidity?.toFixed(0) }}%</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">烟雾</span>
            <span class="detail-val" :style="{ color: device.smoke_detected === 1 ? '#f44336' : '' }">
              {{ device.smoke_value || 0 }}
              <small>ppm</small>
            </span>
          </div>
          <div class="detail-item">
            <span class="detail-label">温升</span>
            <span class="detail-val" :style="{ color: (device.temp_rise_rate || 0) >= 2 ? '#f44336' : (device.temp_rise_rate || 0) >= 1 ? '#ff9800' : '' }">
              {{ (device.temp_rise_rate || 0).toFixed(1) }}
              <small>°C/min</small>
            </span>
          </div>
        </div>
      </div>
      <el-empty v-if="devices.length === 0" description="暂无设备数据" :image-size="60" />
    </div>

    <div class="section-title">温度趋势</div>
    <div class="chart-card glass-card">
      <div class="chart-header">
        <span>传感器趋势</span>
        <div class="time-tabs">
          <span :class="['time-tab', { active: trendRange === '1h' }]" @click="changeTrendRange('1h')">1H</span>
          <span :class="['time-tab', { active: trendRange === '6h' }]" @click="changeTrendRange('6h')">6H</span>
          <span :class="['time-tab', { active: trendRange === '24h' }]" @click="changeTrendRange('24h')">24H</span>
        </div>
      </div>
      <div ref="chartRef" class="chart-box"></div>
    </div>

    <div class="section-title">实时预警</div>
    <div class="alert-list">
      <div
        v-for="alert in recentAlerts.slice(0, 5)"
        :key="alert.id"
        class="alert-card"
        :class="'level-' + alert.alert_level"
      >
        <div class="alert-left">
          <el-tag size="small" :type="getAlertTagType(alert.alert_level)" effect="dark">
            {{ alert.alert_type === 'smoke_detected' ? '烟雾' : getAlertLevelName(alert.alert_level) }}
          </el-tag>
        </div>
        <div class="alert-body">
          <div class="alert-device">{{ alert.device_name }}</div>
          <div class="alert-msg">{{ alert.message }}</div>
          <div class="alert-data" v-if="alert.temperature">
            <span :class="getTempClass(alert.temperature)">{{ alert.temperature?.toFixed(1) }}°C</span>
            <span v-if="alert.temp_rise_rate" class="rate">↑{{ alert.temp_rise_rate.toFixed(1) }}/min</span>
          </div>
        </div>
        <div class="alert-actions">
          <div class="alert-time">{{ formatTime(alert.created_at) }}</div>
          <div class="alert-btns">
            <el-button v-if="alert.status === 'pending'" size="small" type="primary" link @click="handleAlert(alert)">处置</el-button>
            <el-button v-if="alert.alert_level >= 2 && !alert.ai_analysis" size="small" type="success" link @click="triggerAI(alert)">AI分析</el-button>
          </div>
        </div>
      </div>
      <el-empty v-if="recentAlerts.length === 0" description="暂无预警" :image-size="50" />
    </div>

    <el-dialog v-model="showAIDialog" title="AI智能分析" width="90%" :close-on-click-modal="false">
      <div v-if="aiLoading" class="ai-loading">
        <el-icon class="is-loading" :size="24"><Loading /></el-icon>
        <span>AI正在分析中...</span>
      </div>
      <div v-else-if="aiResult" class="ai-result" v-html="formatAIResult(aiResult)"></div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, nextTick } from 'vue'
import * as echarts from 'echarts'
import api from '@/api'
import { Monitor, Connection, Close, WarningFilled, Loading } from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const devices = ref([])
const recentAlerts = ref([])
const chartRef = ref(null)
const trendRange = ref('1h')
let chart = null
let timer = null

const showAIDialog = ref(false)
const aiLoading = ref(false)
const aiResult = ref('')

const sceneNames = {
  lab: '实验室',
  dormitory: '宿舍',
  warehouse: '仓库',
  shop: '商铺',
  power_room: '配电房'
}

const statsCards = computed(() => [
  { label: '紧急预警', value: recentAlerts.value.filter(a => a.status === 'pending' && a.alert_level === 3).length, icon: 'WarningFilled', color: '#f44336', bg: 'rgba(244,67,54,0.08)' },
  { label: '在线设备', value: devices.value.filter(d => d.status === 'online').length, icon: 'Connection', color: '#00c853', bg: 'rgba(0,200,83,0.08)' },
  { label: '离线设备', value: devices.value.filter(d => d.status !== 'online').length, icon: 'Close', color: '#ff5252', bg: 'rgba(255,82,82,0.08)' },
  { label: '总设备', value: devices.value.length, icon: 'Monitor', color: '#0066ff', bg: 'rgba(0,102,255,0.08)' }
])

async function fetchDevices() {
  try {
    const res = await api.get('/api/data/realtime')
    devices.value = res
    updateChart()
  } catch (e) {}
}

async function fetchAlerts() {
  try {
    const res = await api.get('/api/alerts?limit=10')
    recentAlerts.value = res
  } catch (e) {}
}

async function fetchTrend() {
  try {
    const res = await api.get(`/api/data/trend?range=${trendRange.value}`)
    updateTrendChart(res)
  } catch (e) {}
}

function changeTrendRange(range) {
  trendRange.value = range
  fetchTrend()
}

function updateChart() {
  if (!devices.value.length) return
}

function updateTrendChart(data) {
  if (!chartRef.value) return
  nextTick(() => {
    if (!chart) chart = echarts.init(chartRef.value)
    if (!data || !data.timestamps || data.timestamps.length === 0) {
      chart.setOption({
        title: { text: '暂无趋势数据', left: 'center', top: 'center', textStyle: { color: '#9ca3b8', fontSize: 13 } },
        xAxis: { show: false },
        yAxis: { show: false },
        series: []
      }, true)
      return
    }

    const times = data.timestamps.map(t => {
      const d = new Date(t)
      return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`
    })

    chart.setOption({
      tooltip: { trigger: 'axis', confine: true },
      legend: { data: ['物体温度', '环境温度', '湿度', '烟雾'], textStyle: { color: '#6b7394', fontSize: 10 }, top: 0, itemWidth: 12, itemHeight: 8 },
      grid: { left: '12%', right: '8%', bottom: '20%', top: '32px', containLabel: true },
      xAxis: {
        type: 'category',
        data: times,
        axisLine: { lineStyle: { color: '#ddd' } },
        axisLabel: { color: '#6b7394', fontSize: 9, rotate: 30 }
      },
      yAxis: [
        { type: 'value', name: '°C', nameTextStyle: { color: '#6b7394', fontSize: 9 }, axisLine: { show: false }, axisLabel: { color: '#6b7394', fontSize: 9 }, splitLine: { lineStyle: { color: '#eee', type: 'dashed' } } },
        { type: 'value', nameTextStyle: { color: '#6b7394', fontSize: 9 }, axisLine: { show: false }, axisLabel: { color: '#6b7394', fontSize: 9 }, splitLine: { show: false } }
      ],
      series: [
        { name: '物体温度', type: 'line', smooth: true, data: data.temperatures || [], lineStyle: { color: '#165DFF', width: 2 }, itemStyle: { color: '#165DFF' }, symbol: 'none' },
        { name: '环境温度', type: 'line', smooth: true, data: data.ambient_temps || [], lineStyle: { color: '#0FC6C2', width: 2 }, itemStyle: { color: '#0FC6C2' }, symbol: 'none' },
        { name: '湿度', type: 'line', smooth: true, yAxisIndex: 1, data: data.humidities || [], lineStyle: { color: '#00B42A', width: 1.5 }, itemStyle: { color: '#00B42A' }, symbol: 'none' },
        { name: '烟雾', type: 'bar', yAxisIndex: 1, barWidth: '30%', data: data.smoke_values || [], itemStyle: { color: new echarts.graphic.LinearGradient(0,0,0,1,[{offset:0,color:'#FF7D00'},{offset:1,color:'#FFAB40'}]), borderRadius: [2,2,0,0] } }
      ]
    }, true)
  })
}

async function handleAlert(alert) {
  try {
    await ElMessageBox.confirm('确认处理此预警？', '提示')
    await api.put(`/api/alerts/${alert.id}/handle`, { status: 'handled', handling_notes: '已通过APP处理' })
    ElMessage.success('已处理')
    fetchAlerts()
  } catch (e) {}
}

async function triggerAI(alert) {
  showAIDialog.value = true
  aiLoading.value = true
  aiResult.value = ''
  try {
    const res = await api.post(`/api/alerts/${alert.id}/ai-analysis`)
    aiResult.value = res.ai_analysis || res.analysis || '分析完成'
    alert.ai_analysis = aiResult.value
  } catch (e) {
    aiResult.value = 'AI分析失败，请稍后重试'
  } finally {
    aiLoading.value = false
  }
}

function formatAIResult(text) {
  if (!text) return ''
  return text.replace(/\n/g, '<br/>')
}

function getTempClass(temp) {
  if (temp >= 60) return 'danger'
  if (temp >= 45) return 'warning'
  return 'normal'
}

function getAlertLevelName(level) {
  return { 1: '提示', 2: '警告', 3: '紧急' }[level] || '未知'
}

function getAlertTagType(level) {
  return { 1: 'info', 2: 'warning', 3: 'danger' }[level] || 'info'
}

function formatTime(timeStr) {
  if (!timeStr) return ''
  const d = new Date(timeStr)
  return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`
}

onMounted(() => {
  fetchDevices()
  fetchAlerts()
  fetchTrend()
  timer = setInterval(() => {
    fetchDevices()
    fetchAlerts()
  }, 3000)
})

onUnmounted(() => {
  if (timer) clearInterval(timer)
  chart?.dispose()
})
</script>

<style scoped>
.stats-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  margin-bottom: 16px;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px;
  background: #fff;
  border-radius: 12px;
  border: 1px solid rgba(0,0,0,0.06);
  box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}

.stat-icon-wrap {
  width: 38px; height: 38px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.stat-val {
  font-size: 20px;
  font-weight: 700;
  color: #1a1a2e;
  line-height: 1.2;
}

.stat-label {
  font-size: 11px;
  color: #6b7394;
}

.section-title {
  font-size: 15px;
  font-weight: 600;
  color: #1a1a2e;
  margin-bottom: 10px;
  padding-left: 2px;
}

.device-list {
  margin-bottom: 16px;
}

.device-card {
  padding: 14px;
  margin-bottom: 10px;
}

.device-top {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 10px;
}

.device-name-row {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.status-dot {
  width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0;
}
.status-dot.online { background: #00c853; box-shadow: 0 0 6px rgba(0,200,83,0.35); }
.status-dot.offline { background: #ff5252; }

.device-name {
  font-size: 14px;
  font-weight: 600;
  color: #1a1a2e;
}

.scene-tag {
  font-size: 10px;
}

.temp-big {
  font-size: 24px;
  font-weight: 700;
}
.temp-big.normal { color: #00c853; }
.temp-big.warning { color: #ff9800; }
.temp-big.danger { color: #f44336; }

.device-details {
  display: flex;
  gap: 16px;
}

.detail-item {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.detail-label {
  font-size: 11px;
  color: #9ca3b8;
}

.detail-val {
  font-size: 14px;
  font-weight: 600;
  color: #444d66;
}
.detail-val small {
  font-size: 10px;
  color: #9ca3b8;
  font-weight: 400;
}

.chart-card {
  padding: 12px;
  margin-bottom: 16px;
}

.chart-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
  font-size: 13px;
  font-weight: 600;
  color: #444d66;
}

.time-tabs {
  display: flex;
  gap: 4px;
}

.time-tab {
  padding: 2px 10px;
  border-radius: 12px;
  font-size: 11px;
  color: #9ca3b8;
  cursor: pointer;
  transition: all 0.2s;
}

.time-tab.active {
  background: #165DFF;
  color: #fff;
}

.chart-box {
  height: 200px;
}

.alert-list {
  margin-bottom: 16px;
}

.alert-card {
  display: flex;
  gap: 10px;
  padding: 10px 12px;
  background: #fff;
  border-radius: 10px;
  margin-bottom: 8px;
  border-left: 3px solid transparent;
  box-shadow: 0 1px 4px rgba(0,0,0,0.04);
}
.alert-card.level-1 { border-left-color: #2196f3; }
.alert-card.level-2 { border-left-color: #ff9800; }
.alert-card.level-3 { border-left-color: #f44336; }

.alert-body {
  flex: 1;
  min-width: 0;
}

.alert-device {
  font-size: 13px;
  font-weight: 600;
  color: #1a1a2e;
}

.alert-msg {
  font-size: 11px;
  color: #6b7394;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.alert-data {
  display: flex;
  gap: 8px;
  margin-top: 2px;
  font-size: 12px;
}

.alert-data .danger { color: #f44336; font-weight: 600; }
.alert-data .warning { color: #ff9800; font-weight: 600; }
.alert-data .normal { color: #00c853; }
.alert-data .rate { color: #6b7394; }

.alert-actions {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 4px;
  flex-shrink: 0;
}

.alert-time {
  font-size: 11px;
  color: #9ca3b8;
}

.alert-btns {
  display: flex;
  gap: 4px;
}

.ai-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  padding: 40px;
  color: #6b7394;
  font-size: 14px;
}

.ai-result {
  font-size: 14px;
  line-height: 1.8;
  color: #444d66;
  white-space: pre-wrap;
}
</style>
