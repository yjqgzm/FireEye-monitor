"""
火睛智控中心
版权所有：四川职业技术学院 yangming、shahaigui、yanshiyi、qixuding
联系邮箱：2551230793@qq.com
协议：AGPL-3.0，禁止闭源商用
"""

import os
import sys

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
    os.chdir(parent_dir)

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware

from backend.config import logger, ALLOWED_ORIGINS, limiter
from backend.database import init_db
from backend.routers import (
    auth, devices, users, logs, config as config_router,
    settings, static_files, data, alerts
)

app = FastAPI(
    title="火睛智控中心",
    description="火睛智控中心 - 兼容所有WiFi消防报警设备的智能预警平台 V2.1",
    version="2.1.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(SlowAPIMiddleware)

app.include_router(auth.router)
app.include_router(devices.router)
app.include_router(users.router)
app.include_router(logs.router)
app.include_router(config_router.router)
app.include_router(settings.router)
app.include_router(data.router)
app.include_router(alerts.router)
app.include_router(static_files.router)

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"全局异常: {exc}")
    return JSONResponse(
        status_code=500,
        content={"detail": "服务器内部错误", "message": str(exc)}
    )

init_db()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=18889)
