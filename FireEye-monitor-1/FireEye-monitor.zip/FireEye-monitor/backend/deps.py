from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session
from backend.database import get_db, User, OperationLog
from backend.config import verify_token, logger

def get_current_user(request: Request, db: Session = Depends(get_db)):
    token = request.headers.get("Authorization")
    if not token or not token.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="未授权访问")
    token = token.replace("Bearer ", "")
    username = verify_token(token)
    user = db.query(User).filter(User.username == username).first()
    if not user:
        raise HTTPException(status_code=401, detail="用户不存在")
    return user

def require_admin(user: User = Depends(get_current_user)):
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="需要管理员权限")
    return user

def require_admin_or_member(user: User = Depends(get_current_user)):
    if user.role not in ("admin", "member") and not user.is_invited:
        raise HTTPException(status_code=403, detail="需要邀请用户权限")
    return user

def log_operation(db: Session, username: str, action: str, details: str = "", ip: str = "127.0.0.1"):
    log = OperationLog(username=username, action=action, details=details, ip_address=ip)
    db.add(log)
    db.commit()
