import json
from datetime import datetime
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.database import get_db, Device, Alert, SensorData, SystemConfig, User
from backend.config import logger
from backend.deps import get_current_user, log_operation
from backend.cache import data_cache, alert_counter, temp_trend_cache, alert_cooldown
from backend.models import AlertHandle

router = APIRouter()

def check_alert(device: Device, temperature: float, temp_rise_rate: float, db: Session):
    thresholds = json.loads(device.thresholds)
    
    trend_key = f"trend_{device.device_id}"
    trend = temp_trend_cache.get(trend_key, {})
    trend_direction = trend.get("direction", "stable")
    
    if trend_direction == "falling" and temp_rise_rate < 0:
        return
    
    if trend_direction == "stable" and abs(temp_rise_rate) < 0.1:
        cooldown_key = f"stable_{device.id}"
        cooldown = alert_cooldown[cooldown_key]
        if cooldown["last_alert_time"]:
            time_since_last = (datetime.now() - cooldown["last_alert_time"]).total_seconds()
            if time_since_last < 600:
                return
    
    alert_level = 0
    alert_type = ""
    
    if temperature >= thresholds.get("level3", 80):
        alert_level = 3
        alert_type = "critical"
    elif temperature >= thresholds.get("level2", 60):
        alert_level = 2
        alert_type = "warning"
    elif temperature >= thresholds.get("level1", 45):
        alert_level = 1
        alert_type = "notice"
    
    if temp_rise_rate > 0:
        if alert_level == 0 and temp_rise_rate >= thresholds.get("level3_rate", 3):
            alert_level = 3
            alert_type = "critical_rate"
        elif alert_level == 0 and temp_rise_rate >= thresholds.get("level2_rate", 2):
            alert_level = 3
            alert_type = "critical_rate"
        elif alert_level == 0 and temp_rise_rate >= thresholds.get("level1_rate", 1):
            alert_level = 2
            alert_type = "warning_rate"
    
    if alert_level > 0:
        level3_rate = thresholds.get("level3_rate", 3)
        counter_key = f"{device.id}_{alert_level}"
        counter = alert_counter[counter_key]
        cooldown_key = f"alert_{device.id}"
        cooldown = alert_cooldown[cooldown_key]
        
        if temp_rise_rate > 0 and temp_rise_rate >= level3_rate * 2:
            counter["count"] = 3
            counter["last_alert_time"] = datetime.now()
        else:
            if counter["last_alert_time"] and (datetime.now() - counter["last_alert_time"]).seconds < 300:
                counter["count"] += 1
            else:
                counter["count"] = 1
            counter["last_alert_time"] = datetime.now()
        
        if counter["count"] >= 3:
            now = datetime.now()
            
            if cooldown["last_alert_time"]:
                time_since_last = (now - cooldown["last_alert_time"]).total_seconds()
                cooldown["repeat_count"] += 1
                
                if cooldown["repeat_count"] <= 2:
                    min_interval = 120
                elif cooldown["repeat_count"] <= 5:
                    min_interval = 300
                else:
                    min_interval = 600
                
                if time_since_last < min_interval:
                    counter["count"] = 0
                    return
            else:
                cooldown["repeat_count"] = 0
            
            if cooldown["repeat_count"] >= 3 and trend_direction == "stable":
                alert_type = "sustained_" + alert_type
                message_prefix = "持续监控"
            elif cooldown["repeat_count"] >= 1:
                message_prefix = "重复提醒"
            else:
                message_prefix = "预警"
            
            cache_key = f"device_{device.device_id}"
            history = data_cache.get(cache_key, [])
            avg_temp_diff = None
            if history:
                recent_diffs = [h.get("temp_diff", 0) for h in history[-10:]]
                if recent_diffs:
                    avg_temp_diff = round(sum(recent_diffs) / len(recent_diffs), 2)
            
            avg_diff_info = f", 平均温差: {avg_temp_diff}°C" if avg_temp_diff is not None else ""
            trend_info = {"rising": "升温中", "falling": "降温中", "stable": "温度稳定"}.get(trend_direction, "")
            
            alert = Alert(
                device_id=device.id,
                alert_level=alert_level,
                alert_type=alert_type,
                temperature=temperature,
                temp_rise_rate=temp_rise_rate,
                message=f"[{message_prefix}] {device.name} 温度异常: {temperature:.2f}°C, 温升速率: {temp_rise_rate:.2f}°C/min, 趋势: {trend_info}{avg_diff_info}"
            )
            db.add(alert)
            db.commit()
            
            cooldown["last_alert_time"] = now
            cooldown["alert_level"] = alert_level
            counter["count"] = 0
            
            logger.warning(f"预警触发: 设备 {device.name}, 等级 {alert_level}, 温度 {temperature}°C, 趋势 {trend_direction}, 重复次数 {cooldown['repeat_count']}")

def check_smoke_alert(device: Device, smoke_value: int, db: Session):
    alert = Alert(
        device_id=device.id,
        alert_level=3,
        alert_type="smoke_detected",
        temperature=0.0,
        temp_rise_rate=0.0,
        message=f"{device.name} 检测到烟雾! 烟雾浓度值: {smoke_value}"
    )
    db.add(alert)
    db.commit()
    
    logger.warning(f"烟雾预警触发: 设备 {device.name}, 烟雾值 {smoke_value}")

def trigger_ai_analysis(device_id: int, temperature: float, temp_rise_rate: float, db: Session, alert_id: int = None, smoke_value: int = 0, smoke_detected: bool = False, alert_message: str = "", alert_level: int = 2):
    import httpx

    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        return None

    cache_key = f"device_{device.device_id}"
    history = data_cache.get(cache_key, [])
    history_str = "\n".join([
        f"- {h['timestamp']}: 温度={h.get('temperature', 'N/A')}°C, 湿度={h.get('humidity', 'N/A')}%, 烟雾值={h.get('smoke_value', 'N/A')}"
        for h in history[-30:]
    ])

    provider_config = db.query(SystemConfig).filter_by(config_key="ai_provider").first()
    api_key_config = db.query(SystemConfig).filter_by(config_key="ai_api_key").first()
    model_config = db.query(SystemConfig).filter_by(config_key="ai_model").first()

    api_key = api_key_config.config_value if api_key_config else ""
    if not api_key:
        logger.warning("AI分析跳过: 未配置API Key")
        return None

    provider = (provider_config.config_value if provider_config else "zhipu") or "zhipu"
    custom_model = model_config.config_value if model_config else ""

    AI_PROVIDERS = {
        "qwen": {
            "name": "通义千问",
            "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
            "default_model": "qwen-turbo",
            "headers_fn": lambda key: {"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        },
        "baidu": {
            "name": "文心一言",
            "base_url": "https://qianfan.baidubce.com/v2/chat/completions",
            "default_model": "ernie-speed-128k",
            "headers_fn": lambda key: {"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        },
        "zhipu": {
            "name": "智谱GLM",
            "base_url": "https://open.bigmodel.cn/api/paas/v4/chat/completions",
            "default_model": "glm-4-flash",
            "headers_fn": lambda key: {"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        },
        "deepseek": {
            "name": "DeepSeek",
            "base_url": "https://api.deepseek.com/v1/chat/completions",
            "default_model": "deepseek-chat",
            "headers_fn": lambda key: {"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        },
        "openai": {
            "name": "OpenAI",
            "base_url": "https://api.openai.com/v1/chat/completions",
            "default_model": "gpt-4o-mini",
            "headers_fn": lambda key: {"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        },
    }

    if provider not in AI_PROVIDERS:
        logger.error(f"不支持的AI提供商: {provider}，请在系统设置中重新选择")
        return None

    ai_conf = AI_PROVIDERS[provider]
    model_name = custom_model or ai_conf["default_model"]

    level_names = {1: "提示", 2: "警告", 3: "紧急"}
    smoke_status = f"已检测到烟雾（浓度值: {smoke_value}）" if smoke_detected else f"未检测到烟雾（浓度值: {smoke_value}）"

    prompt = f"""你是火灾预警系统的AI分析专家。请根据以下传感器数据，用简洁清晰的中文文字进行分析，直接输出可读文本，不要使用JSON格式。

【设备信息】
- 设备名称：{device.name}
- 安装位置：{device.location}
- 场景类型：{device.scene_type}

【预警信息】
- 预警等级：{level_names.get(alert_level, '未知')}（{alert_level}级）
- 预警描述：{alert_message or '温度异常'}
- 当前温度：{temperature}°C
- 温升速率：{temp_rise_rate}°C/min
- 烟雾状态：{smoke_status}

【近30分钟传感器历史】
{history_str if history_str else '暂无历史数据'}

请按以下格式输出分析结果（纯文本，不要用JSON）：

🔥 风险分析
（分析当前温度、温升速率和烟雾数据，判断风险原因）

📊 火灾概率：XX%
（给出0-100%的概率评估）

⚡ 应急建议
1. （第一条建议）
2. （第二条建议）
3. （第三条建议）"""

    try:
        response = httpx.post(
            ai_conf["base_url"],
            headers=ai_conf["headers_fn"](api_key),
            json={
                "model": model_name,
                "messages": [
                    {"role": "system", "content": "你是专业的火灾预警分析专家。请用简洁清晰的中文输出分析结果，直接输出可读文本，绝对不要使用JSON格式，不要使用代码块，不要使用markdown语法。"},
                    {"role": "user", "content": prompt}
                ],
                "temperature": 0.7
            },
            timeout=30.0
        )

        if response.status_code == 200:
            result = response.json()
            content = result.get("choices", [{}])[0].get("message", {}).get("content", "")

            if not content:
                logger.error(f"AI返回空内容: {provider}")
                return None

            content = content.strip()
            if content.startswith("```"):
                lines = content.split("\n")
                content = "\n".join(lines[1:-1] if lines[-1].strip() == "```" else lines[1:])

            import json as _json
            try:
                parsed = _json.loads(content)
                if isinstance(parsed, dict):
                    parts = []
                    if "risk_analysis" in parsed:
                        parts.append(f"🔥 风险分析\n{parsed['risk_analysis']}")
                    if "fire_probability" in parsed:
                        prob = parsed["fire_probability"]
                        parts.append(f"📊 火灾概率：{prob}%")
                    if "suggestions" in parsed and isinstance(parsed["suggestions"], list):
                        suggestions = []
                        for s in parsed["suggestions"]:
                            s_clean = str(s).strip()
                            import re as _re
                            s_clean = _re.sub(r'^\d+[\.\)、]\s*', '', s_clean)
                            s_clean = s_clean.lstrip("- •*")
                            if s_clean:
                                suggestions.append(s_clean)
                        parts.append("⚡ 应急建议\n" + "\n".join(f"{i+1}. {s}" for i, s in enumerate(suggestions)))
                    for key in parsed:
                        if key not in ("risk_analysis", "fire_probability", "suggestions"):
                            val = parsed[key]
                            if isinstance(val, str) and len(val) > 5:
                                parts.append(f"📌 {key}\n{val}")
                            elif isinstance(val, list):
                                parts.append(f"📌 {key}\n" + "\n".join(f"- {s}" for s in val))
                    if parts:
                        content = "\n\n".join(parts)
            except (ValueError, TypeError):
                pass

            target_alert = None
            if alert_id:
                target_alert = db.query(Alert).filter(Alert.id == alert_id).first()
            if not target_alert:
                target_alert = db.query(Alert).filter(
                    Alert.device_id == device_id
                ).order_by(Alert.created_at.desc()).first()

            if target_alert:
                target_alert.ai_analysis = content
                target_alert.ai_provider = provider
                db.commit()

            return content
        else:
            error_text = response.text[:300] if response.text else ""
            logger.error(f"AI分析请求失败: {provider} HTTP {response.status_code} - {error_text}")
            return None
    except httpx.TimeoutException:
        logger.error(f"AI分析超时({provider}): 30s")
        return None
    except Exception as e:
        logger.error(f"AI分析调用失败({provider}): {e}")
        return None

@router.get("/api/alerts")
def get_alerts(
    device_id: Optional[int] = None,
    alert_level: Optional[int] = None,
    status: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    limit: int = 100,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    query = db.query(Alert)
    
    if device_id:
        query = query.filter(Alert.device_id == device_id)
    if alert_level:
        query = query.filter(Alert.alert_level == alert_level)
    if status:
        query = query.filter(Alert.status == status)
    if start_date:
        query = query.filter(Alert.created_at >= datetime.fromisoformat(start_date))
    if end_date:
        query = query.filter(Alert.created_at <= datetime.fromisoformat(end_date))
    
    alerts = query.order_by(Alert.created_at.desc()).limit(limit).all()
    
    result = []
    for a in alerts:
        device = db.query(Device).filter(Device.id == a.device_id).first()
        result.append({
            "id": a.id,
            "device_id": a.device_id,
            "device_name": device.name if device else "未知设备",
            "device_location": device.location if device else "",
            "alert_level": a.alert_level,
            "alert_type": a.alert_type,
            "temperature": a.temperature,
            "temp_rise_rate": a.temp_rise_rate,
            "message": a.message,
            "status": a.status,
            "ai_analysis": a.ai_analysis,
            "handling_notes": a.handling_notes,
            "handled_by": a.handled_by,
            "handled_at": a.handled_at.isoformat() if a.handled_at else None,
            "created_at": a.created_at.isoformat()
        })
    
    return result

@router.put("/api/alerts/{alert_id}/handle")
def handle_alert(
    alert_id: int,
    handle_data: AlertHandle,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    alert = db.query(Alert).filter(Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=404, detail="预警记录不存在")
    
    alert.status = handle_data.status
    alert.handling_notes = handle_data.handling_notes
    alert.handled_by = user.username
    alert.handled_at = datetime.now()
    db.commit()
    
    log_operation(db, user.username, "处理预警", f"预警ID: {alert_id}, 状态: {handle_data.status}")
    
    return {"message": "预警处理成功"}

@router.post("/api/alerts/{alert_id}/analyze")
def analyze_alert(
    alert_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    alert = db.query(Alert).filter(Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=404, detail="预警不存在")
    
    if alert.alert_level < 2:
        return {"message": "只有2级及以上预警才能触发AI分析", "code": 400}
    
    if alert.ai_analysis:
        return {"message": "该预警已存在AI分析结果", "code": 400, "ai_analysis": alert.ai_analysis}
    
    device = db.query(Device).filter(Device.id == alert.device_id).first()
    if not device:
        raise HTTPException(status_code=404, detail="设备不存在")

    smoke_detected = alert.alert_type == "smoke_detected" or bool(alert.message and "烟雾" in alert.message)

    latest_sensor = db.query(SensorData).filter(
        SensorData.device_id == device.id
    ).order_by(SensorData.timestamp.desc()).first()
    smoke_value = latest_sensor.smoke_value if latest_sensor else 0

    ai_result = trigger_ai_analysis(
        device.id, alert.temperature, alert.temp_rise_rate, db,
        alert_id=alert.id,
        smoke_value=smoke_value,
        smoke_detected=smoke_detected,
        alert_message=alert.message or "",
        alert_level=alert.alert_level
    )
    
    db.refresh(alert)

    if not alert.ai_analysis:
        api_key_config = db.query(SystemConfig).filter_by(config_key="ai_api_key").first()
        if not api_key_config or not api_key_config.config_value:
            return {"message": "AI分析失败：未配置AI服务API密钥，请在系统设置中配置", "ai_analysis": None, "code": 500}
        if ai_result is None:
            return {"message": "AI分析失败：AI服务调用异常，请检查API配置、模型名称或网络连接", "ai_analysis": None, "code": 500}
        return {"message": "AI分析完成但结果未保存，请重试", "ai_analysis": None, "code": 500}
    
    log_operation(db, user.username, "AI分析", f"预警ID: {alert_id}")
    
    return {"message": "AI分析完成", "ai_analysis": alert.ai_analysis}

@router.get("/api/alerts/stats")
def get_alert_stats(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    
    total = db.query(Alert).count()
    today_count = db.query(Alert).filter(Alert.created_at >= today).count()
    pending = db.query(Alert).filter(Alert.status == "pending").count()
    
    level_counts = {
        "level1": db.query(Alert).filter(Alert.alert_level == 1).count(),
        "level2": db.query(Alert).filter(Alert.alert_level == 2).count(),
        "level3": db.query(Alert).filter(Alert.alert_level == 3).count()
    }
    
    return {
        "total": total,
        "today": today_count,
        "pending": pending,
        "level_counts": level_counts
    }
