from datetime import datetime
from typing import Optional
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.database import get_db, OperationLog, User
from backend.deps import require_admin

router = APIRouter()

@router.get("/api/logs")
def get_operation_logs(
    username: Optional[str] = None,
    action: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    limit: int = 100,
    db: Session = Depends(get_db),
    user: User = Depends(require_admin)
):
    query = db.query(OperationLog)
    
    if username:
        query = query.filter(OperationLog.username == username)
    if action:
        query = query.filter(OperationLog.action.like(f"%{action}%"))
    if start_date:
        query = query.filter(OperationLog.timestamp >= datetime.fromisoformat(start_date))
    if end_date:
        query = query.filter(OperationLog.timestamp <= datetime.fromisoformat(end_date))
    
    logs = query.order_by(OperationLog.timestamp.desc()).limit(limit).all()
    
    return [{
        "id": l.id,
        "username": l.username,
        "action": l.action,
        "details": l.details,
        "ip_address": l.ip_address,
        "timestamp": l.timestamp.isoformat()
    } for l in logs]
