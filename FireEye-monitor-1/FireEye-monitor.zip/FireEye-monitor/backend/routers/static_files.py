import os
from fastapi import APIRouter, Request
from fastapi.responses import FileResponse, HTMLResponse

router = APIRouter()

@router.get("/")
def root():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    index_path = os.path.join(current_dir, "..", "..", "frontend", "dist", "index.html")
    index_path = os.path.normpath(index_path)
    if os.path.exists(index_path):
        with open(index_path, 'r', encoding='utf-8') as f:
            content = f.read()
        return HTMLResponse(content=content, status_code=200, media_type="text/html; charset=utf-8")
    return HTMLResponse(content="""
        <html>
        <head><title>火睛智控中心</title></head>
        <body>
            <h1>火睛智控中心</h1>
            <p>后端服务运行正常 (V2.1)</p>
        </body>
        </html>
    """, status_code=200, media_type="text/html; charset=utf-8")

@router.get("/{full_path:path}")
async def serve_static(full_path: str):
    current_dir = os.path.dirname(os.path.abspath(__file__))
    base_dir = os.path.normpath(os.path.join(current_dir, "..", "..", "frontend", "dist"))
    file_path = os.path.normpath(os.path.join(base_dir, full_path))
    
    if not os.path.normpath(base_dir) in os.path.normpath(file_path):
        return HTMLResponse("Forbidden", status_code=403)
    
    if full_path.startswith('api/'):
        return HTMLResponse("Not Found", status_code=404)
    
    if os.path.isfile(file_path):
        return FileResponse(file_path)
    
    index_path = os.path.join(file_path, "index.html")
    if os.path.isfile(index_path):
        return FileResponse(index_path)
    
    main_index = os.path.join(base_dir, "index.html")
    if os.path.isfile(main_index):
        return FileResponse(main_index)
    
    return HTMLResponse("Not Found", status_code=404)
