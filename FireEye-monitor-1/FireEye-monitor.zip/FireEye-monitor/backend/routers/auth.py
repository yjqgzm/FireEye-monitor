from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from backend.database import get_db, User, InviteCode
from backend.config import hash_password, verify_password, create_access_token, logger, limiter
from backend.deps import get_current_user, require_admin, log_operation
from backend.models import (
    LoginRequest, Token, RegisterRequest, ActivateInviteRequest, InviteCodeCreate
)

router = APIRouter()

@router.post("/api/auth/login", response_model=Token)
@limiter.limit("5/minute")
def login(request: Request, login_data: LoginRequest, db: Session = Depends(get_db)):
    if "@" in login_data.username:
        user = db.query(User).filter(User.email == login_data.username).first()
    else:
        user = db.query(User).filter(User.username == login_data.username).first()
    
    if not user or not verify_password(login_data.password, user.password_hash):
        raise HTTPException(status_code=401, detail="邮箱/用户名或密码错误")
    
    if not user.is_active:
        raise HTTPException(status_code=403, detail="账号已被禁用")
    
    user.last_login = datetime.now()
    db.commit()
    
    access_token = create_access_token(data={"sub": user.username, "role": user.role})
    log_operation(db, user.username, "用户登录", f"角色: {user.role}")
    
    return {"access_token": access_token, "token_type": "bearer"}

@router.get("/api/auth/me")
def get_user_info(user: User = Depends(get_current_user)):
    return {
        "username": user.username,
        "role": user.role,
        "email": user.email,
        "is_invited": user.is_invited,
        "last_login": user.last_login.isoformat() if user.last_login else None
    }

@router.post("/api/auth/register", response_model=Token)
def register(request: RegisterRequest, db: Session = Depends(get_db)):
    existing = db.query(User).filter(User.username == request.username).first()
    if existing:
        raise HTTPException(status_code=400, detail="用户名已存在")
    
    existing_email = db.query(User).filter(User.email == request.email).first()
    if existing_email:
        raise HTTPException(status_code=400, detail="该邮箱已被注册")
    
    if len(request.username) < 3:
        raise HTTPException(status_code=400, detail="用户名至少3个字符")
    if len(request.password) < 6:
        raise HTTPException(status_code=400, detail="密码至少6个字符")
    if "@" not in request.email:
        raise HTTPException(status_code=400, detail="请输入有效的邮箱地址")
    
    is_invited = False
    invite_code_record = None
    
    if request.invite_code:
        invite_code_record = db.query(InviteCode).filter(
            InviteCode.code == request.invite_code,
            InviteCode.is_used == False
        ).first()
        
        if not invite_code_record:
            raise HTTPException(status_code=400, detail="邀请码无效或已使用")
        
        if invite_code_record.expires_at and invite_code_record.expires_at < datetime.now():
            raise HTTPException(status_code=400, detail="邀请码已过期")
        
        if invite_code_record.use_count >= invite_code_record.max_uses:
            raise HTTPException(status_code=400, detail="邀请码已达到使用上限")
        
        is_invited = True
    
    user = User(
        username=request.username,
        password_hash=hash_password(request.password),
        role="member" if is_invited else "user",
        email=request.email,
        is_invited=is_invited,
        invite_code_id=invite_code_record.id if invite_code_record else None
    )
    db.add(user)
    
    if invite_code_record:
        invite_code_record.use_count += 1
        if invite_code_record.use_count >= invite_code_record.max_uses:
            invite_code_record.is_used = True
        invite_code_record.used_by = user.id
        invite_code_record.used_at = datetime.now()
    
    db.commit()
    db.refresh(user)
    
    access_token = create_access_token(data={"sub": user.username, "role": user.role})
    log_operation(db, user.username, "用户注册", f"邀请码: {'有' if is_invited else '无'}")
    
    return {"access_token": access_token, "token_type": "bearer"}

@router.post("/api/auth/activate-invite")
def activate_invite(request: ActivateInviteRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.is_invited:
        raise HTTPException(status_code=400, detail="您已是邀请用户，无需重复激活")
    
    invite_code_record = db.query(InviteCode).filter(
        InviteCode.code == request.invite_code,
        InviteCode.is_used == False
    ).first()
    
    if not invite_code_record:
        raise HTTPException(status_code=400, detail="邀请码无效或已使用")
    
    if invite_code_record.expires_at and invite_code_record.expires_at < datetime.now():
        raise HTTPException(status_code=400, detail="邀请码已过期")
    
    if invite_code_record.use_count >= invite_code_record.max_uses:
        raise HTTPException(status_code=400, detail="邀请码已达到使用上限")
    
    user.is_invited = True
    user.role = "member"
    user.invite_code_id = invite_code_record.id
    invite_code_record.use_count += 1
    if invite_code_record.use_count >= invite_code_record.max_uses:
        invite_code_record.is_used = True
    invite_code_record.used_by = user.id
    invite_code_record.used_at = datetime.now()
    
    db.commit()
    
    log_operation(db, user.username, "激活邀请码", f"邀请码: {request.invite_code}")
    
    return {"message": "邀请码激活成功", "is_invited": True}

@router.post("/api/invite-codes")
def create_invite_codes(request: InviteCodeCreate, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    import secrets
    codes = []
    for _ in range(request.count):
        code_str = f"FHQJ-{secrets.token_hex(4).upper()}"
        invite = InviteCode(
            code=code_str,
            created_by=admin.id,
            max_uses=request.max_uses,
            description=request.description
        )
        db.add(invite)
        codes.append(code_str)
    
    db.commit()
    log_operation(db, admin.username, "生成邀请码", f"数量: {len(codes)}")
    
    return {"codes": codes, "count": len(codes)}

@router.get("/api/invite-codes")
def list_invite_codes(db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    codes = db.query(InviteCode).order_by(InviteCode.created_at.desc()).all()
    result = []
    for c in codes:
        result.append({
            "id": c.id,
            "code": c.code,
            "is_used": c.is_used,
            "use_count": c.use_count,
            "max_uses": c.max_uses,
            "description": c.description,
            "created_at": c.created_at.isoformat() if c.created_at else None,
            "used_at": c.used_at.isoformat() if c.used_at else None,
            "expires_at": c.expires_at.isoformat() if c.expires_at else None
        })
    return result

@router.delete("/api/invite-codes/{code_id}")
def delete_invite_code(code_id: int, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    code = db.query(InviteCode).filter(InviteCode.id == code_id).first()
    if not code:
        raise HTTPException(status_code=404, detail="邀请码不存在")
    db.delete(code)
    db.commit()
    log_operation(db, admin.username, "删除邀请码", f"邀请码ID: {code_id}")
    return {"message": "删除成功"}
