import json
from datetime import datetime, timedelta
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.database import get_db, Device, SensorData, Alert, User, DataSnapshot
from backend.config import logger
from backend.deps import get_current_user, log_operation
from backend.cache import data_cache, temp_trend_cache, alert_cooldown
from backend.models import SensorDataReceive
from backend.routers.alerts import check_alert, check_smoke_alert

router = APIRouter()

@router.post("/api/data/receive")
def receive_sensor_data(
    data: SensorDataReceive,
    db: Session = Depends(get_db)
):
    device = db.query(Device).filter(Device.device_id == data.device_id).first()
    if not device:
        return {"code": 404, "message": "设备不存在"}
    
    device.status = "online"
    device.last_report_time = datetime.now()
    if not device.online_time:
        device.online_time = datetime.now()
    db.commit()
    
    temp_rise_rate = 0.0
    temp_diff = data.temperature - data.ambient_temp
    
    cache_key = f"device_{data.device_id}"
    history = data_cache[cache_key]
    if history:
        last_temp = history[-1]["temperature"]
        time_diff = 1.0
        temp_rise_rate = (data.temperature - last_temp) / time_diff
    
    avg_temp_diff = temp_diff
    if history:
        recent_diffs = [h.get("temp_diff", 0) for h in history[-10:]]
        if recent_diffs:
            avg_temp_diff = round(sum(recent_diffs) / len(recent_diffs), 2)
    
    trend_key = f"trend_{data.device_id}"
    trend = temp_trend_cache[trend_key]
    trend["prev_temps"].append(data.temperature)
    if len(trend["prev_temps"]) > 10:
        trend["prev_temps"].pop(0)
    
    if len(trend["prev_temps"]) >= 3:
        recent = trend["prev_temps"][-3:]
        if all(recent[i] > recent[i+1] for i in range(len(recent)-1)):
            trend["direction"] = "falling"
            trend["stable_since"] = None
        elif all(recent[i] < recent[i+1] for i in range(len(recent)-1)):
            trend["direction"] = "rising"
            trend["stable_since"] = None
        else:
            if trend["direction"] != "stable":
                trend["stable_since"] = datetime.now()
            trend["direction"] = "stable"
    
    temperature = round(data.temperature, 2)
    ambient_temp = round(data.ambient_temp, 2)
    humidity = round(data.humidity, 2)
    smoke_value = data.smoke_value if data.smoke_value else 0
    smoke_detected = data.smoke_detected if data.smoke_detected else 0
    temp_rise_rate = round(temp_rise_rate, 2)
    temp_diff = round(temp_diff, 2)
    
    history.append({
        "temperature": temperature,
        "ambient_temp": ambient_temp,
        "humidity": humidity,
        "smoke_value": smoke_value,
        "smoke_detected": smoke_detected,
        "temp_diff": temp_diff,
        "timestamp": datetime.now().isoformat()
    })
    if len(history) > 60:
        history.pop(0)
    data_cache[cache_key] = history
    
    sensor_record = SensorData(
        device_id=device.id,
        temperature=temperature,
        ambient_temp=ambient_temp,
        humidity=humidity,
        smoke_value=smoke_value,
        smoke_detected=smoke_detected,
        temp_rise_rate=temp_rise_rate,
        temp_diff=temp_diff,
        raw_data=json.dumps(data.dict())
    )
    db.add(sensor_record)
    db.commit()
    
    check_alert(device, temperature, temp_rise_rate, db)
    
    if smoke_detected == 1:
        check_smoke_alert(device, smoke_value, db)
    
    return {"code": 200, "message": "数据接收成功", "avg_temp_diff": avg_temp_diff, "trend": trend["direction"]}

@router.post("/api/data/simulate")
def simulate_data(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    import random
    
    devices = db.query(Device).all()
    if not devices:
        return {"message": "请先添加设备", "code": 400}
    
    created_count = 0
    alert_count = 0
    
    for device in devices:
        db.query(SensorData).filter(SensorData.device_id == device.id).delete()
        db.query(Alert).filter(Alert.device_id == device.id).delete()
        db.commit()
        
        thresholds = json.loads(device.thresholds) if device.thresholds else {"level1": 45, "level2": 60, "level3": 80}
        level1_t = thresholds.get("level1", 45)
        level2_t = thresholds.get("level2", 60)
        level3_t = thresholds.get("level3", 80)
        
        base_temp = random.uniform(24, 28)
        base_ambient = random.uniform(20, 26)
        base_humidity = random.uniform(45, 65)
        base_smoke = random.randint(50, 200)
        
        time_segments = [
            {"start_hours_ago": 24, "end_hours_ago": 22, "interval_min": 10, "temp_offset_range": (0, 2), "label": "正常"},
            {"start_hours_ago": 18, "end_hours_ago": 16, "interval_min": 10, "temp_offset_range": (2, 5), "label": "微温"},
            {"start_hours_ago": 12, "end_hours_ago": 10, "interval_min": 10, "temp_offset_range": (5, 10), "label": "升温"},
            {"start_hours_ago": 6, "end_hours_ago": 4, "interval_min": 10, "temp_offset_range": (10, 18), "label": "高温"},
            {"start_hours_ago": 3, "end_hours_ago": 1, "interval_min": 5, "temp_offset_range": (18, 28), "label": "预警"},
            {"start_hours_ago": 0.5, "end_hours_ago": 0, "interval_min": 3, "temp_offset_range": (28, 38), "label": "危险"},
        ]
        
        device_history = []
        prev_temp = base_temp
        last_alert_level = 0
        last_alert_time = None
        
        for seg in time_segments:
            start_dt = datetime.now() - timedelta(hours=seg["start_hours_ago"])
            end_dt = datetime.now() - timedelta(hours=seg["end_hours_ago"])
            interval = timedelta(minutes=seg["interval_min"])
            low_off, high_off = seg["temp_offset_range"]
            
            current_dt = start_dt
            seg_progress = 0
            total_points = int((seg["start_hours_ago"] - seg["end_hours_ago"]) * 60 / seg["interval_min"])
            
            while current_dt <= end_dt:
                seg_progress += 1
                progress_ratio = seg_progress / max(total_points, 1)
                temp_offset = low_off + (high_off - low_off) * progress_ratio
                
                temp_noise = random.uniform(-1.5, 1.5)
                temp = base_temp + temp_offset + temp_noise
                temp = max(22, min(95, temp))
                
                ambient_noise = random.uniform(-0.8, 0.8)
                ambient = base_ambient + temp_offset * 0.3 + ambient_noise
                ambient = max(18, min(35, ambient))
                
                humidity = base_humidity - temp_offset * 0.5 + random.uniform(-3, 3)
                humidity = max(25, min(90, humidity))
                
                smoke = base_smoke + (temp_offset * 15) + random.randint(-30, 30)
                if temp_offset > 25:
                    smoke += random.uniform(200, 500)
                smoke = max(20, min(1200, smoke))
                smoke_detected = 1 if smoke > 600 else 0
                
                rise_rate = abs(temp - prev_temp) / max(seg["interval_min"], 1) if prev_temp != base_temp else random.uniform(0.1, 0.5)
                rise_rate = max(0.0, min(5.0, rise_rate))
                prev_temp = temp
                
                sensor_record = SensorData(
                    device_id=device.id,
                    temperature=round(temp, 2),
                    ambient_temp=round(ambient, 2),
                    humidity=round(humidity, 1),
                    smoke_value=round(smoke, 1),
                    smoke_detected=smoke_detected,
                    temp_rise_rate=round(rise_rate, 1),
                    temp_diff=round(temp - ambient, 2),
                    raw_data=json.dumps({"simulated": True, "segment": seg["label"]}),
                    timestamp=current_dt
                )
                db.add(sensor_record)
                created_count += 1
                
                alert_level = 0
                alert_type = ""
                if temp >= level3_t:
                    alert_level = 3
                    alert_type = "critical"
                elif temp >= level2_t:
                    alert_level = 2
                    alert_type = "warning"
                elif temp >= level1_t:
                    alert_level = 1
                    alert_type = "notice"
                
                if rise_rate >= 3 and alert_level < 3:
                    alert_level = 3
                    alert_type = "critical_rate"
                elif rise_rate >= 2 and alert_level < 2:
                    alert_level = 2
                    alert_type = "warning_rate"
                elif rise_rate >= 1 and alert_level < 1:
                    alert_level = 1
                    alert_type = "notice_rate"
                
                should_create_alert = False
                if alert_level > 0:
                    if alert_level > last_alert_level:
                        should_create_alert = True
                    elif last_alert_time and (current_dt - last_alert_time).total_seconds() >= 600:
                        should_create_alert = True
                    elif alert_level == 3 and (last_alert_time is None or (current_dt - last_alert_time).total_seconds() >= 300):
                        should_create_alert = True
                
                if should_create_alert:
                    level_name = {1: "提示", 2: "警告", 3: "紧急"}.get(alert_level, "未知")
                    type_name = {"notice": "温度提示", "warning": "温度警告", "critical": "温度紧急", "notice_rate": "温升提示", "warning_rate": "温升警告", "critical_rate": "温升紧急"}.get(alert_type, "预警")
                    trend_info = {"正常": "稳定", "微温": "升温中", "升温": "快速升温", "高温": "持续高温", "预警": "危险升温", "危险": "紧急状态"}.get(seg["label"], "")
                    
                    alert = Alert(
                        device_id=device.id,
                        alert_level=alert_level,
                        alert_type=alert_type,
                        temperature=round(temp, 2),
                        temp_rise_rate=round(rise_rate, 2),
                        message=f"[{level_name}] {device.name} {type_name}: 温度 {temp:.1f}°C, 温升速率 {rise_rate:.1f}°C/min, 趋势: {trend_info}",
                        created_at=current_dt
                    )
                    db.add(alert)
                    alert_count += 1
                    last_alert_level = alert_level
                    last_alert_time = current_dt
                
                if smoke_detected == 1:
                    smoke_alert_cooldown = True
                    if last_alert_time:
                        if (current_dt - last_alert_time).total_seconds() < 180:
                            smoke_alert_cooldown = False
                    if smoke_alert_cooldown:
                        alert = Alert(
                            device_id=device.id,
                            alert_level=3,
                            alert_type="smoke_detected",
                            temperature=round(temp, 2),
                            temp_rise_rate=0.0,
                            message=f"[紧急] {device.name} 检测到烟雾! 烟雾浓度值: {int(smoke)}",
                            created_at=current_dt
                        )
                        db.add(alert)
                        alert_count += 1
                        last_alert_level = 3
                        last_alert_time = current_dt
                
                device_history.append({
                    "temperature": round(temp, 1),
                    "ambient_temp": round(ambient, 1),
                    "humidity": round(humidity, 1),
                    "smoke_value": round(smoke, 1),
                    "smoke_detected": smoke_detected,
                    "timestamp": current_dt.isoformat()
                })
                
                current_dt += interval
        
        if len(device_history) > 60:
            device_history = device_history[-60:]
        cache_key = f"device_{device.device_id}"
        data_cache[cache_key] = device_history

        device.status = "online"
        device.last_report_time = datetime.now()
        if not device.online_time:
            device.online_time = datetime.now()

    db.commit()
    return {"message": f"成功生成 {created_count} 条模拟数据，{alert_count} 条预警记录（6个时间段，含>1小时跨度）", "code": 200}

@router.post("/api/data/clear")
def clear_all_data(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    try:
        db.query(SensorData).delete()
        db.query(Alert).delete()
        devices = db.query(Device).all()
        for device in devices:
            device.status = "offline"
            device.last_report_time = None
        db.commit()
        data_cache.clear()
        temp_trend_cache.clear()
        alert_cooldown.clear()
        snapshot_count = db.query(DataSnapshot).count()
        return {"message": f"已清除所有数据，设备已恢复离线状态（{snapshot_count}个数据镜像不受影响）", "code": 200}
    except Exception as e:
        db.rollback()
        return {"message": f"清除数据失败: {str(e)}", "code": 500}

@router.get("/api/data/realtime")
def get_realtime_data(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    devices = db.query(Device).all()
    result = []
    
    for device in devices:
        cache_key = f"device_{device.device_id}"
        history = data_cache.get(cache_key, [])
        latest = history[-1] if history else None
        
        avg_temp_diff = None
        if history:
            recent_diffs = [h.get("temp_diff", 0) for h in history[-10:]]
            if recent_diffs:
                avg_temp_diff = round(sum(recent_diffs) / len(recent_diffs), 2)
        
        trend_key = f"trend_{device.device_id}"
        trend_info = temp_trend_cache.get(trend_key, {})
        trend_direction = trend_info.get("direction", "stable")
        
        if not latest:
            latest_record = db.query(SensorData).filter(
                SensorData.device_id == device.id
            ).order_by(SensorData.timestamp.desc()).first()
            if latest_record:
                latest = {
                    "temperature": latest_record.temperature,
                    "ambient_temp": latest_record.ambient_temp,
                    "humidity": latest_record.humidity,
                    "smoke_value": latest_record.smoke_value,
                    "smoke_detected": latest_record.smoke_detected,
                    "temp_rise_rate": latest_record.temp_rise_rate or 0.0
                }
        
        is_online = False
        if device.last_report_time:
            time_since_report = (datetime.now() - device.last_report_time).total_seconds()
            is_online = time_since_report < 300

        result.append({
            "id": device.id,
            "device_id": device.device_id,
            "name": device.name,
            "location": device.location,
            "scene_type": device.scene_type,
            "status": "online" if is_online else "offline",
            "temperature": latest["temperature"] if latest else None,
            "ambient_temp": latest["ambient_temp"] if latest else None,
            "humidity": latest["humidity"] if latest else None,
            "smoke_value": latest.get("smoke_value", 0) if latest else 0,
            "smoke_detected": latest.get("smoke_detected", 0) if latest else 0,
            "temp_rise_rate": latest.get("temp_rise_rate", 0) if latest else 0,
            "temp_diff": latest.get("temp_diff", 0) if latest else 0,
            "avg_temp_diff": avg_temp_diff,
            "trend": trend_direction,
            "last_report_time": device.last_report_time.isoformat() if device.last_report_time else None,
            "thresholds": json.loads(device.thresholds)
        })
    
    return result

@router.get("/api/data/history")
def get_history_data(
    device_id: Optional[int] = None,
    start_time: Optional[str] = None,
    end_time: Optional[str] = None,
    limit: int = 1000,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    query = db.query(SensorData)
    
    if device_id:
        query = query.filter(SensorData.device_id == device_id)
    if start_time:
        query = query.filter(SensorData.timestamp >= datetime.fromisoformat(start_time))
    if end_time:
        query = query.filter(SensorData.timestamp <= datetime.fromisoformat(end_time))
    
    data = query.order_by(SensorData.timestamp.desc()).limit(limit).all()
    
    return [{
        "device_id": d.device_id,
        "temperature": d.temperature,
        "ambient_temp": d.ambient_temp,
        "humidity": d.humidity,
        "smoke_value": d.smoke_value,
        "smoke_detected": d.smoke_detected,
        "temp_rise_rate": d.temp_rise_rate,
        "timestamp": d.timestamp.isoformat()
    } for d in data]

@router.get("/api/data/trend")
def get_trend_data(
    device_id: int,
    hours: int = 24,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    start_time = datetime.now() - timedelta(hours=hours)
    
    data = db.query(SensorData).filter(
        SensorData.device_id == device_id,
        SensorData.timestamp >= start_time
    ).order_by(SensorData.timestamp.asc()).all()
    
    return {
        "device_id": device_id,
        "data": [{
            "temperature": d.temperature,
            "ambient_temp": d.ambient_temp,
            "humidity": d.humidity,
            "smoke_value": d.smoke_value,
            "temp_rise_rate": d.temp_rise_rate,
            "timestamp": d.timestamp.isoformat()
        } for d in data]
    }
