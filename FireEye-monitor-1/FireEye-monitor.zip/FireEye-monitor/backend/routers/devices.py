import json
from datetime import datetime
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.database import get_db, Device, User
from backend.deps import get_current_user, require_admin, log_operation
from backend.models import DeviceCreate, DeviceUpdate

router = APIRouter()

@router.get("/api/devices")
def get_devices(
    scene_type: Optional[str] = None,
    status: Optional[str] = None,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    query = db.query(Device)
    if scene_type:
        query = query.filter(Device.scene_type == scene_type)
    if status:
        query = query.filter(Device.status == status)
    
    devices = query.all()
    return [{
        "id": d.id,
        "device_id": d.device_id,
        "name": d.name,
        "location": d.location,
        "scene_type": d.scene_type,
        "status": d.status,
        "online_time": d.online_time.isoformat() if d.online_time else None,
        "last_report_time": d.last_report_time.isoformat() if d.last_report_time else None,
        "relay_enabled": d.relay_enabled,
        "created_at": d.created_at.isoformat()
    } for d in devices]

@router.post("/api/devices")
def create_device(
    device: DeviceCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_admin)
):
    existing = db.query(Device).filter(Device.device_id == device.device_id).first()
    if existing:
        raise HTTPException(status_code=400, detail="设备ID已存在")
    
    new_device = Device(
        device_id=device.device_id,
        name=device.name,
        location=device.location,
        scene_type=device.scene_type,
        thresholds=json.dumps(device.thresholds) if device.thresholds else '{"level1": 45, "level2": 60, "level3": 80, "level1_rate": 1, "level2_rate": 2, "level3_rate": 3}'
    )
    db.add(new_device)
    db.commit()
    db.refresh(new_device)
    
    log_operation(db, user.username, "添加设备", f"设备ID: {device.device_id}")
    
    return {"id": new_device.id, "message": "设备添加成功"}

@router.put("/api/devices/{device_id}")
def update_device(
    device_id: int,
    device_update: DeviceUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_admin)
):
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(status_code=404, detail="设备不存在")
    
    if device_update.name is not None:
        device.name = device_update.name
    if device_update.location is not None:
        device.location = device_update.location
    if device_update.scene_type is not None:
        device.scene_type = device_update.scene_type
    if device_update.thresholds is not None:
        if isinstance(device_update.thresholds, dict):
            device.thresholds = json.dumps(device_update.thresholds)
        else:
            device.thresholds = device_update.thresholds
    if device_update.relay_enabled is not None:
        device.relay_enabled = device_update.relay_enabled
    
    device.updated_at = datetime.now()
    db.commit()
    
    log_operation(db, user.username, "更新设备", f"设备ID: {device.device_id}")
    
    return {"message": "设备更新成功"}

@router.delete("/api/devices/{device_id}")
def delete_device(
    device_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(require_admin)
):
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(status_code=404, detail="设备不存在")
    
    device_id_str = device.device_id
    db.delete(device)
    db.commit()
    
    log_operation(db, user.username, "删除设备", f"设备ID: {device_id_str}")
    
    return {"message": "设备删除成功"}

@router.post("/api/devices/{device_id}/restart")
def restart_device(
    device_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(require_admin)
):
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(status_code=404, detail="设备不存在")
    
    log_operation(db, user.username, "重启设备", f"设备ID: {device.device_id}")
    
    return {"message": "重启指令已下发", "device_id": device.device_id}
