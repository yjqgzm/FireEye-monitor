import json
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.database import get_db, Device, AlertConfig, SystemConfig, User
from backend.deps import require_admin, log_operation
from backend.models import AlertConfigUpdate, SystemConfigUpdate

router = APIRouter()

@router.get("/api/config/alert")
def get_alert_configs(
    db: Session = Depends(get_db),
    user: User = Depends(require_admin)
):
    configs = db.query(AlertConfig).all()
    return [{
        "id": c.id,
        "scene_type": c.scene_type,
        "level1_threshold": c.level1_threshold,
        "level1_rate": c.level1_rate,
        "level2_threshold": c.level2_threshold,
        "level2_rate": c.level2_rate,
        "level3_threshold": c.level3_threshold,
        "level3_rate": c.level3_rate,
        "push_enabled": c.push_enabled,
        "push_email": c.push_email,
        "push_webhook": c.push_webhook,
        "webhook_url": c.webhook_url
    } for c in configs]

@router.put("/api/config/alert/{scene_type}")
def update_alert_config(
    scene_type: str,
    config: AlertConfigUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_admin)
):
    alert_config = db.query(AlertConfig).filter(AlertConfig.scene_type == scene_type).first()
    if not alert_config:
        alert_config = AlertConfig(scene_type=scene_type)
        db.add(alert_config)
    
    if config.level1_threshold is not None:
        alert_config.level1_threshold = config.level1_threshold
    if config.level1_rate is not None:
        alert_config.level1_rate = config.level1_rate
    if config.level2_threshold is not None:
        alert_config.level2_threshold = config.level2_threshold
    if config.level2_rate is not None:
        alert_config.level2_rate = config.level2_rate
    if config.level3_threshold is not None:
        alert_config.level3_threshold = config.level3_threshold
    if config.level3_rate is not None:
        alert_config.level3_rate = config.level3_rate
    if config.push_enabled is not None:
        alert_config.push_enabled = config.push_enabled
    if config.push_email is not None:
        alert_config.push_email = config.push_email
    if config.push_webhook is not None:
        alert_config.push_webhook = config.push_webhook
    if config.webhook_url is not None:
        alert_config.webhook_url = config.webhook_url
    
    db.commit()
    
    devices = db.query(Device).filter(Device.scene_type == scene_type).all()
    for device in devices:
        device.thresholds = json.dumps({
            "level1": alert_config.level1_threshold,
            "level1_rate": alert_config.level1_rate,
            "level2": alert_config.level2_threshold,
            "level2_rate": alert_config.level2_rate,
            "level3": alert_config.level3_threshold,
            "level3_rate": alert_config.level3_rate
        })
    db.commit()
    
    log_operation(db, user.username, "更新预警配置", f"场景: {scene_type}")
    
    return {"message": "配置更新成功"}

@router.get("/api/config/system")
def get_system_configs(
    db: Session = Depends(get_db),
    user: User = Depends(require_admin)
):
    configs = db.query(SystemConfig).all()
    result = {}
    for c in configs:
        if c.config_key == "ai_api_key":
            result[c.config_key] = "***" + c.config_value[-4:] if c.config_value else ""
        else:
            result[c.config_key] = c.config_value
    return result

@router.put("/api/config/system")
def update_system_config(
    config: SystemConfigUpdate,
    db: Session = Depends(get_db),
    user: User = Depends(require_admin)
):
    system_config = db.query(SystemConfig).filter_by(config_key=config.config_key).first()
    if not system_config:
        system_config = SystemConfig(config_key=config.config_key)
        db.add(system_config)
    
    system_config.config_value = config.config_value
    db.commit()
    
    log_operation(db, user.username, "更新系统配置", f"配置项: {config.config_key}")
    
    return {"message": "配置更新成功"}

@router.post("/api/config/test-ai")
def test_ai_connection(user: User = Depends(require_admin), db: Session = Depends(get_db)):
    import httpx
    import time as _time

    provider_config = db.query(SystemConfig).filter_by(config_key="ai_provider").first()
    api_key_config = db.query(SystemConfig).filter_by(config_key="ai_api_key").first()
    model_config = db.query(SystemConfig).filter_by(config_key="ai_model").first()

    api_key = api_key_config.config_value if api_key_config else ""
    if not api_key:
        return {"success": False, "message": "未配置API Key，请先填写并保存"}

    provider = (provider_config.config_value if provider_config else "zhipu") or "zhipu"
    custom_model = model_config.config_value if model_config else ""

    AI_PROVIDERS = {
        "qwen": {
            "name": "通义千问",
            "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
            "default_model": "qwen-turbo",
            "headers_fn": lambda key: {"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        },
        "baidu": {
            "name": "文心一言",
            "base_url": "https://qianfan.baidubce.com/v2/chat/completions",
            "default_model": "ernie-speed-128k",
            "headers_fn": lambda key: {"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        },
        "zhipu": {
            "name": "智谱GLM",
            "base_url": "https://open.bigmodel.cn/api/paas/v4/chat/completions",
            "default_model": "glm-4-flash",
            "headers_fn": lambda key: {"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        },
        "deepseek": {
            "name": "DeepSeek",
            "base_url": "https://api.deepseek.com/v1/chat/completions",
            "default_model": "deepseek-chat",
            "headers_fn": lambda key: {"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        },
        "openai": {
            "name": "OpenAI",
            "base_url": "https://api.openai.com/v1/chat/completions",
            "default_model": "gpt-4o-mini",
            "headers_fn": lambda key: {"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        },
    }

    if provider not in AI_PROVIDERS:
        return {"success": False, "message": f"不支持的AI服务商: {provider}，请在系统设置中重新选择"}

    ai_conf = AI_PROVIDERS[provider]
    model_name = custom_model or ai_conf["default_model"]

    start_time = _time.time()
    try:
        response = httpx.post(
            ai_conf["base_url"],
            headers=ai_conf["headers_fn"](api_key),
            json={
                "model": model_name,
                "messages": [
                    {"role": "user", "content": "你好，请回复'连接测试成功'"}
                ],
                "temperature": 0.1,
                "max_tokens": 20
            },
            timeout=15.0
        )
        elapsed = int((_time.time() - start_time) * 1000)

        if response.status_code == 200:
            result = response.json()
            content = result.get("choices", [{}])[0].get("message", {}).get("content", "")
            return {
                "success": True,
                "message": f"{ai_conf['name']}连接成功",
                "model": model_name,
                "response_time": elapsed,
                "reply": content[:50]
            }
        else:
            error_detail = ""
            try:
                error_body = response.json()
                error_detail = error_body.get("error", {}).get("message", "") or error_body.get("message", "")
            except:
                error_detail = response.text[:200]
            return {
                "success": False,
                "message": f"HTTP {response.status_code}: {error_detail or '请求失败'}",
                "model": model_name,
                "response_time": elapsed
            }
    except httpx.TimeoutException:
        return {"success": False, "message": "连接超时(15s)，请检查网络或API地址是否正确"}
    except httpx.ConnectError:
        return {"success": False, "message": "无法连接到AI服务，请检查网络"}
    except Exception as e:
        return {"success": False, "message": f"连接异常: {str(e)[:100]}"}
