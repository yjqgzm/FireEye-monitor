from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.database import get_db, User
from backend.config import hash_password
from backend.deps import require_admin, log_operation
from backend.models import UserCreate

router = APIRouter()

@router.get("/api/users")
def get_users(
    db: Session = Depends(get_db),
    user: User = Depends(require_admin)
):
    users = db.query(User).all()
    return [{
        "id": u.id,
        "username": u.username,
        "role": u.role,
        "email": u.email,
        "is_active": u.is_active,
        "is_invited": u.is_invited if u.is_invited is not None else False,
        "created_at": u.created_at.isoformat(),
        "last_login": u.last_login.isoformat() if u.last_login else None
    } for u in users]

@router.post("/api/users")
def create_user(
    user_data: UserCreate,
    db: Session = Depends(get_db),
    admin: User = Depends(require_admin)
):
    existing = db.query(User).filter(User.username == user_data.username).first()
    if existing:
        raise HTTPException(status_code=400, detail="用户名已存在")
    
    new_user = User(
        username=user_data.username,
        password_hash=hash_password(user_data.password),
        role=user_data.role,
        email=user_data.email
    )
    db.add(new_user)
    db.commit()
    
    log_operation(db, admin.username, "创建用户", f"用户名: {user_data.username}")
    
    return {"message": "用户创建成功"}

@router.delete("/api/users/{user_id}")
def delete_user(
    user_id: int,
    db: Session = Depends(get_db),
    admin: User = Depends(require_admin)
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    
    if user.username == "admin":
        raise HTTPException(status_code=400, detail="不能删除管理员账号")
    
    username = user.username
    db.delete(user)
    db.commit()
    
    log_operation(db, admin.username, "删除用户", f"用户名: {username}")
    
    return {"message": "用户删除成功"}
