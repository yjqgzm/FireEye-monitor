import os
import shutil
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.database import get_db, Device, Alert, SensorData, User, DataSnapshot
from backend.config import logger, verify_password, hash_password
from backend.deps import get_current_user, require_admin, log_operation
from backend.models import ChangePasswordRequest, ChangeEmailRequest, CreateSnapshotRequest

router = APIRouter()

@router.put("/api/settings/password")
def change_password(request: ChangePasswordRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not verify_password(request.old_password, user.password_hash):
        raise HTTPException(status_code=400, detail="原密码错误")
    if len(request.new_password) < 6:
        raise HTTPException(status_code=400, detail="新密码长度不能少于6位")
    user.password_hash = hash_password(request.new_password)
    db.commit()
    log_operation(db, user.username, "修改密码", "成功修改密码")
    return {"message": "密码修改成功"}

@router.put("/api/settings/email")
def change_email(request: ChangeEmailRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not verify_password(request.password, user.password_hash):
        raise HTTPException(status_code=400, detail="密码验证失败")
    existing = db.query(User).filter(User.email == request.new_email, User.id != user.id).first()
    if existing:
        raise HTTPException(status_code=400, detail="该邮箱已被其他用户绑定")
    old_email = user.email
    user.email = request.new_email
    db.commit()
    log_operation(db, user.username, "修改邮箱", f"从 {old_email} 修改为 {request.new_email}")
    return {"message": "邮箱修改成功"}

@router.post("/api/snapshots")
def create_snapshot(request: CreateSnapshotRequest, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    db_path = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "fire_detection.db"))
    if not os.path.exists(db_path):
        db_path = "fire_detection.db"
    if not os.path.exists(db_path):
        raise HTTPException(status_code=404, detail="数据库文件不存在")
    snapshot_dir = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "snapshots"))
    os.makedirs(snapshot_dir, exist_ok=True)
    timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    snapshot_filename = f"snapshot_{timestamp_str}.db"
    snapshot_path = os.path.join(snapshot_dir, snapshot_filename)
    try:
        shutil.copy2(db_path, snapshot_path)
    except Exception as e:
        logger.error(f"复制数据库文件失败: {e}")
        raise HTTPException(status_code=500, detail=f"复制数据库文件失败: {str(e)}")
    db_size = os.path.getsize(snapshot_path)
    device_count = db.query(Device).count()
    alert_count = db.query(Alert).count()
    sensor_count = db.query(SensorData).count()
    snapshot = DataSnapshot(
        name=request.name,
        description=request.description,
        snapshot_type="manual",
        db_file_path=snapshot_path,
        db_size=db_size,
        device_count=device_count,
        alert_count=alert_count,
        sensor_data_count=sensor_count,
        created_by=user.id
    )
    db.add(snapshot)
    db.flush()
    db.commit()
    snapshot_id = snapshot.id
    snapshot_created_at = snapshot.created_at.isoformat() if snapshot.created_at else None
    try:
        log_operation(db, user.username, "创建数据镜像", f"镜像名称: {request.name}, 设备数: {device_count}, 预警数: {alert_count}")
    except Exception as e:
        logger.warning(f"记录操作日志失败(不影响镜像): {e}")
    logger.info(f"镜像创建成功: id={snapshot_id}, name={request.name}")
    return {
        "message": "数据镜像创建成功",
        "snapshot": {
            "id": snapshot_id,
            "name": request.name,
            "db_size": db_size,
            "device_count": device_count,
            "alert_count": alert_count,
            "sensor_data_count": sensor_count,
            "created_at": snapshot_created_at
        }
    }

@router.get("/api/snapshots")
def list_snapshots(user: User = Depends(require_admin), db: Session = Depends(get_db)):
    db.commit()
    snapshots = db.query(DataSnapshot).order_by(DataSnapshot.created_at.desc()).all()
    result = []
    for s in snapshots:
        file_exists = os.path.exists(s.db_file_path) if s.db_file_path else False
        result.append({
            "id": s.id,
            "name": s.name,
            "description": s.description,
            "snapshot_type": s.snapshot_type,
            "db_size": s.db_size,
            "device_count": s.device_count,
            "alert_count": s.alert_count,
            "sensor_data_count": s.sensor_data_count,
            "file_exists": file_exists,
            "created_at": s.created_at.isoformat() if s.created_at else None
        })
    return result

@router.post("/api/snapshots/{snapshot_id}/restore")
def restore_snapshot(snapshot_id: int, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    snapshot = db.query(DataSnapshot).filter(DataSnapshot.id == snapshot_id).first()
    if not snapshot:
        raise HTTPException(status_code=404, detail="镜像不存在")
    if not os.path.exists(snapshot.db_file_path):
        raise HTTPException(status_code=404, detail="镜像文件已丢失，无法恢复")
    snap_name = snapshot.name
    db_path = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "fire_detection.db"))
    if not os.path.exists(db_path):
        db_path = "fire_detection.db"
    pre_restore_dir = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "snapshots"))
    os.makedirs(pre_restore_dir, exist_ok=True)
    pre_restore_filename = f"pre_restore_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    pre_restore_path = os.path.join(pre_restore_dir, pre_restore_filename)
    if os.path.exists(db_path):
        shutil.copy2(db_path, pre_restore_path)
        pre_size = os.path.getsize(pre_restore_path)
        pre_snapshot = DataSnapshot(
            name=f"恢复前自动备份",
            description=f"恢复镜像 #{snapshot_id} 前的自动备份",
            snapshot_type="auto_pre_restore",
            db_file_path=pre_restore_path,
            db_size=pre_size,
            created_by=user.id
        )
        db.add(pre_snapshot)
    db.commit()
    try:
        shutil.copy2(snapshot.db_file_path, db_path)
    except Exception as e:
        logger.error(f"恢复镜像文件失败: {e}")
        raise HTTPException(status_code=500, detail=f"恢复镜像文件失败: {str(e)}")
    log_operation(db, user.username, "恢复数据镜像", f"从镜像 #{snapshot_id} '{snap_name}' 恢复")
    return {"message": f"已从镜像 '{snap_name}' 恢复数据，请重启后端服务使更改生效"}

@router.delete("/api/snapshots/{snapshot_id}")
def delete_snapshot(snapshot_id: int, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    snapshot = db.query(DataSnapshot).filter(DataSnapshot.id == snapshot_id).first()
    if not snapshot:
        raise HTTPException(status_code=404, detail="镜像不存在")
    if os.path.exists(snapshot.db_file_path):
        os.remove(snapshot.db_file_path)
    db.delete(snapshot)
    db.commit()
    log_operation(db, user.username, "删除数据镜像", f"删除镜像 #{snapshot_id} '{snapshot.name}'")
    return {"message": "镜像已删除"}
