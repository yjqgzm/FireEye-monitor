"""
数据库模块 - SQLite轻量化数据库，自动初始化
"""

import os
from datetime import datetime
from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean, DateTime, Text, ForeignKey
from sqlalchemy.orm import DeclarativeBase, sessionmaker, relationship

# 数据库配置 - 使用绝对路径，避免多数据库文件问题
_DB_DIR = os.path.dirname(os.path.abspath(__file__))
_DB_PATH = os.path.join(os.path.dirname(_DB_DIR), "fire_detection.db")
DATABASE_URL = f"sqlite:///{_DB_PATH.replace(os.sep, '/')}"

# 创建引擎
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},
    echo=False
)

class Base(DeclarativeBase):
    pass

class Device(Base):
    """设备表"""
    __tablename__ = "devices"
    
    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(String(50), unique=True, index=True, nullable=False)
    name = Column(String(100), nullable=False)
    location = Column(String(200))
    scene_type = Column(String(50), default="laboratory")
    status = Column(String(20), default="offline")
    online_time = Column(DateTime, nullable=True)
    last_report_time = Column(DateTime, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    thresholds = Column(Text, default='{"level1": 45, "level2": 60, "level3": 80, "level1_rate": 1, "level2_rate": 2, "level3_rate": 3}')
    relay_enabled = Column(Boolean, default=True)
    
    sensors = relationship("SensorData", back_populates="device", cascade="all, delete-orphan")
    alerts = relationship("Alert", back_populates="device", cascade="all, delete-orphan")

class SensorData(Base):
    """传感器数据表"""
    __tablename__ = "sensor_data"
    
    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id"))
    temperature = Column(Float)
    ambient_temp = Column(Float)
    humidity = Column(Float)
    smoke_value = Column(Integer, default=0)  # 新增：烟雾传感器ADC值
    smoke_detected = Column(Integer, default=0)  # 新增：是否检测到烟雾(0/1)
    temp_rise_rate = Column(Float, default=0.0)
    temp_diff = Column(Float, default=0.0)
    raw_data = Column(Text)
    timestamp = Column(DateTime, default=datetime.now, index=True)
    
    device = relationship("Device", back_populates="sensors")

class Alert(Base):
    """预警记录表"""
    __tablename__ = "alerts"
    
    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id"))
    alert_level = Column(Integer)
    alert_type = Column(String(50))
    temperature = Column(Float)
    temp_rise_rate = Column(Float)
    message = Column(Text)
    status = Column(String(20), default="pending")
    ai_analysis = Column(Text, nullable=True)
    ai_provider = Column(String(30), nullable=True)
    handling_notes = Column(Text, nullable=True)
    handled_by = Column(String(50), nullable=True)
    handled_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.now, index=True)
    
    device = relationship("Device", back_populates="alerts")

class User(Base):
    """用户表"""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    password_hash = Column(String(200), nullable=False)
    role = Column(String(20), default="user")
    email = Column(String(100))
    phone = Column(String(20))
    is_active = Column(Boolean, default=True)
    is_invited = Column(Boolean, default=False)
    invite_code_id = Column(Integer, ForeignKey("invite_codes.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.now)
    last_login = Column(DateTime, nullable=True)

class InviteCode(Base):
    """邀请码表"""
    __tablename__ = "invite_codes"
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(20), unique=True, index=True, nullable=False)
    created_by = Column(Integer, ForeignKey("users.id"))
    used_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    is_used = Column(Boolean, default=False)
    max_uses = Column(Integer, default=1)
    use_count = Column(Integer, default=0)
    description = Column(String(200), nullable=True)
    created_at = Column(DateTime, default=datetime.now)
    used_at = Column(DateTime, nullable=True)
    expires_at = Column(DateTime, nullable=True)

class AlertConfig(Base):
    """预警配置表"""
    __tablename__ = "alert_configs"
    
    id = Column(Integer, primary_key=True, index=True)
    scene_type = Column(String(50), unique=True, index=True)
    level1_threshold = Column(Float, default=45.0)
    level1_rate = Column(Float, default=1.0)
    level2_threshold = Column(Float, default=60.0)
    level2_rate = Column(Float, default=2.0)
    level3_threshold = Column(Float, default=80.0)
    level3_rate = Column(Float, default=3.0)
    push_enabled = Column(Boolean, default=True)
    push_email = Column(Boolean, default=True)
    push_webhook = Column(Boolean, default=False)
    webhook_url = Column(String(200), nullable=True)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)

class SystemConfig(Base):
    """系统配置表"""
    __tablename__ = "system_configs"
    
    id = Column(Integer, primary_key=True, index=True)
    config_key = Column(String(50), unique=True, index=True)
    config_value = Column(Text)
    description = Column(String(200))
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)

class OperationLog(Base):
    __tablename__ = "operation_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50))
    action = Column(String(100))
    details = Column(Text)
    ip_address = Column(String(50))
    timestamp = Column(DateTime, default=datetime.now, index=True)

class DataSnapshot(Base):
    __tablename__ = "data_snapshots"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    description = Column(String(200), nullable=True)
    snapshot_type = Column(String(20), default="manual")
    db_file_path = Column(String(300), nullable=False)
    db_size = Column(Integer, default=0)
    device_count = Column(Integer, default=0)
    alert_count = Column(Integer, default=0)
    sensor_data_count = Column(Integer, default=0)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.now, index=True)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def _migrate_db(db):
    """数据库迁移：为已有表添加新列 + 创建缺失表"""
    import sqlite3
    from sqlalchemy import text

    db_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "fire_detection.db")
    if not os.path.exists(db_path):
        db_path = "fire_detection.db"
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute("PRAGMA table_info(users)")
    user_columns = [col[1] for col in cursor.fetchall()]

    if "is_invited" not in user_columns:
        cursor.execute("ALTER TABLE users ADD COLUMN is_invited BOOLEAN DEFAULT 0")

    if "invite_code_id" not in user_columns:
        cursor.execute("ALTER TABLE users ADD COLUMN invite_code_id INTEGER REFERENCES invite_codes(id)")

    cursor.execute("UPDATE users SET is_invited = 1 WHERE role = 'admin' AND is_invited = 0")

    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='invite_codes'")
    if not cursor.fetchone():
        cursor.execute("""
            CREATE TABLE invite_codes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code VARCHAR(20) NOT NULL,
                created_by INTEGER REFERENCES users(id),
                used_by INTEGER REFERENCES users(id),
                is_used BOOLEAN DEFAULT 0,
                max_uses INTEGER DEFAULT 1,
                use_count INTEGER DEFAULT 0,
                description VARCHAR(200),
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                used_at DATETIME,
                expires_at DATETIME
            )
        """)

    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='data_snapshots'")
    if not cursor.fetchone():
        cursor.execute("""
            CREATE TABLE data_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name VARCHAR(100) NOT NULL,
                description VARCHAR(200),
                snapshot_type VARCHAR(20) DEFAULT 'manual',
                db_file_path VARCHAR(300) NOT NULL,
                db_size INTEGER DEFAULT 0,
                device_count INTEGER DEFAULT 0,
                alert_count INTEGER DEFAULT 0,
                sensor_data_count INTEGER DEFAULT 0,
                created_by INTEGER REFERENCES users(id),
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

    conn.commit()
    conn.close()

    try:
        columns = db.execute(text("PRAGMA table_info(alerts)")).fetchall()
        col_names = {col[1] for col in columns}
        if 'ai_provider' not in col_names:
            db.execute(text("ALTER TABLE alerts ADD COLUMN ai_provider VARCHAR(30)"))
            print("[迁移] alerts 表添加 ai_provider 列")
    except Exception as e:
        print(f"[迁移警告] {e}")

def get_db():
    """获取数据库会话"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def init_db():
    """初始化数据库，创建表结构和默认数据"""
    Base.metadata.create_all(bind=engine)
    
    db = SessionLocal()
    try:
        _migrate_db(db)
        
        existing_user = db.query(User).first()
        if not existing_user:
            from backend.config import hash_password, DEFAULT_ADMIN_PASSWORD
            
            admin_user = User(
                username="admin",
                password_hash=hash_password(DEFAULT_ADMIN_PASSWORD),
                role="admin",
                email="admin@example.com",
                is_invited=True
            )
            db.add(admin_user)
            
            normal_user = User(
                username="user",
                password_hash=hash_password("123456"),
                role="user",
                email="user@example.com",
                is_invited=False
            )
            db.add(normal_user)
        
        # 检查是否已有设备
        existing_device = db.query(Device).first()
        if not existing_device:
            # 创建默认设备
            devices = [
                Device(device_id="SENSOR_001", name="实验室温度传感器1", location="一楼实验室", scene_type="laboratory"),
                Device(device_id="SENSOR_002", name="实验室温度传感器2", location="二楼实验室", scene_type="laboratory"),
                Device(device_id="SENSOR_003", name="宿舍区传感器1", location="A栋宿舍301", scene_type="dormitory"),
                Device(device_id="SENSOR_004", name="仓库温度传感器1", location="1号仓库", scene_type="warehouse"),
                Device(device_id="SENSOR_005", name="商铺温度传感器1", location="临街商铺A", scene_type="shop"),
                Device(device_id="SENSOR_006", name="配电房传感器1", location="主配电房", scene_type="power_room"),
            ]
            for device in devices:
                db.add(device)
        
        # 检查是否已有默认预警配置
        existing_config = db.query(AlertConfig).first()
        if not existing_config:
            scenes = ["laboratory", "dormitory", "warehouse", "shop", "power_room"]
            for scene in scenes:
                config = AlertConfig(
                    scene_type=scene,
                    level1_threshold=45.0 if scene != "power_room" else 50.0,
                    level1_rate=1.0,
                    level2_threshold=60.0 if scene != "power_room" else 70.0,
                    level2_rate=2.0,
                    level3_threshold=80.0 if scene != "power_room" else 90.0,
                    level3_rate=3.0
                )
                db.add(config)
        
        # 检查是否已有AI配置
        existing_ai_config = db.query(SystemConfig).filter_by(config_key="ai_api_key").first()
        if not existing_ai_config:
            ai_config = SystemConfig(
                config_key="ai_api_key",
                config_value="",  # 【必改】在此填入你的AI API Key
                description="AI API Key"
            )
            db.add(ai_config)
        
        db.commit()
    finally:
        db.close()
