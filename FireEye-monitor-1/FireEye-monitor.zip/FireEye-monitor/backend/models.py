from pydantic import BaseModel
from typing import Optional

class LoginRequest(BaseModel):
    username: str
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str

class DeviceCreate(BaseModel):
    device_id: str
    name: str
    location: str
    scene_type: str = "laboratory"
    thresholds: Optional[dict] = None

class DeviceUpdate(BaseModel):
    name: Optional[str] = None
    location: Optional[str] = None
    scene_type: Optional[str] = None
    thresholds: Optional[dict] = None
    relay_enabled: Optional[bool] = None

class SensorDataReceive(BaseModel):
    device_id: str
    temperature: float
    ambient_temp: float
    humidity: float
    smoke_value: Optional[int] = 0
    smoke_detected: Optional[int] = 0
    status: str = "online"
    sensor_status: str = "ok"

class AlertCreate(BaseModel):
    device_id: int
    alert_level: int
    alert_type: str
    temperature: float
    temp_rise_rate: float
    message: str

class AlertHandle(BaseModel):
    status: str
    handling_notes: Optional[str] = None

class UserCreate(BaseModel):
    username: str
    password: str
    role: str = "user"
    email: Optional[str] = None

class RegisterRequest(BaseModel):
    username: str
    password: str
    email: str
    invite_code: Optional[str] = None

class ActivateInviteRequest(BaseModel):
    invite_code: str

class InviteCodeCreate(BaseModel):
    count: int = 1
    max_uses: int = 1
    description: Optional[str] = None

class AlertConfigUpdate(BaseModel):
    scene_type: str
    level1_threshold: Optional[float] = None
    level1_rate: Optional[float] = None
    level2_threshold: Optional[float] = None
    level2_rate: Optional[float] = None
    level3_threshold: Optional[float] = None
    level3_rate: Optional[float] = None
    push_enabled: Optional[bool] = None
    push_email: Optional[bool] = None
    push_webhook: Optional[bool] = None
    webhook_url: Optional[str] = None

class SystemConfigUpdate(BaseModel):
    config_key: str
    config_value: str

class ChangePasswordRequest(BaseModel):
    old_password: str
    new_password: str

class ChangeEmailRequest(BaseModel):
    new_email: str
    password: str

class CreateSnapshotRequest(BaseModel):
    name: str
    description: str = ""

class RestoreSnapshotRequest(BaseModel):
    snapshot_id: int
