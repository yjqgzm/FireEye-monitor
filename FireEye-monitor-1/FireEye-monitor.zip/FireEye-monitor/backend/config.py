import os
import logging
import secrets
from datetime import datetime, timedelta, timezone
import bcrypt
from jose import JWTError, jwt
from fastapi import HTTPException

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load .env file with UTF-8 encoding before slowapi reads it
_env_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env")
if os.path.isfile(_env_file):
    with open(_env_file, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if "=" in line and not line.startswith("#"):
                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip().strip("\"'")
                if key and key not in os.environ:
                    os.environ[key] = value

SECRET_KEY = os.getenv("SECRET_KEY", "")
if not SECRET_KEY:
    SECRET_KEY = secrets.token_hex(32)
    logger.warning("=" * 60)
    logger.warning("SECRET_KEY not configured!")
    logger.warning("Auto-generated temporary key (will be lost on restart).")
    logger.warning("For production, set SECRET_KEY in .env file.")
    logger.warning("Generate key: python -c \"import secrets; print(secrets.token_hex(32))\"")
    logger.warning("=" * 60)
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24

_origins_str = os.getenv("ALLOWED_ORIGINS", "http://localhost:3000")
ALLOWED_ORIGINS = [origin.strip() for origin in _origins_str.split(",") if origin.strip()]

DEFAULT_ADMIN_PASSWORD = os.getenv("DEFAULT_ADMIN_PASSWORD", "123456")
if DEFAULT_ADMIN_PASSWORD == "123456":
    logger.warning("=" * 60)
    logger.warning("Using default admin password '123456'!")
    logger.warning("This is INSECURE. Change DEFAULT_ADMIN_PASSWORD in .env")
    logger.warning("before deploying to production!")
    logger.warning("=" * 60)

from slowapi import Limiter
from slowapi.util import get_remote_address
limiter = Limiter(default_limits=["100/minute"], key_func=get_remote_address)

def hash_password(password):
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

def verify_password(plain_password, hashed_password):
    return bcrypt.checkpw(plain_password.encode("utf-8"), hashed_password.encode("utf-8"))

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def verify_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=401, detail="无效的令牌")
        return username
    except JWTError:
        raise HTTPException(status_code=401, detail="令牌验证失败")
