from collections import defaultdict

data_cache = defaultdict(list)
alert_counter = defaultdict(lambda: {"count": 0, "last_alert_time": None})
temp_trend_cache = defaultdict(lambda: {"prev_temps": [], "direction": "stable", "stable_since": None})
alert_cooldown = defaultdict(lambda: {"last_alert_time": None, "alert_level": 0, "repeat_count": 0, "last_escalation_time": None})
