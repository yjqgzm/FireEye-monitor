import pytest


class TestAlertListAndStats:
    def test_get_alerts_empty(self, client, admin_headers):
        resp = client.get("/api/alerts", headers=admin_headers)
        assert resp.status_code == 200
        assert resp.json() == []

    def test_get_alert_stats(self, client, admin_headers):
        resp = client.get("/api/alerts/stats", headers=admin_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert "total" in data
        assert "today" in data
        assert "pending" in data
        assert "level_counts" in data

    def test_handle_alert_not_found(self, client, admin_headers):
        resp = client.put("/api/alerts/99999/handle", json={
            "status": "resolved",
            "handling_notes": "测试处理"
        }, headers=admin_headers)
        assert resp.status_code == 404

    def test_analyze_alert_not_found(self, client, admin_headers):
        resp = client.post("/api/alerts/99999/analyze", headers=admin_headers)
        assert resp.status_code == 404

    def test_alerts_no_token(self, client):
        resp = client.get("/api/alerts")
        assert resp.status_code == 401
