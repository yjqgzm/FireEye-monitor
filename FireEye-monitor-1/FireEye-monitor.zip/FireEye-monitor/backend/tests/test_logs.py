import pytest


class TestGetLogs:
    def test_get_logs_admin(self, client, admin_headers):
        resp = client.get("/api/logs", headers=admin_headers)
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_get_logs_no_token(self, client):
        resp = client.get("/api/logs")
        assert resp.status_code == 401

    def test_get_logs_normal_user_forbidden(self, client):
        reg_resp = client.post("/api/auth/register", json={
            "username": "logviewer",
            "password": "test123456",
            "email": "logviewer@example.com"
        })
        token = reg_resp.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}
        resp = client.get("/api/logs", headers=headers)
        assert resp.status_code == 403


class TestLogFiltering:
    def test_logs_with_action_filter(self, client, admin_headers):
        client.post("/api/auth/login", json={
            "username": "testadmin",
            "password": "test123456"
        }, headers=admin_headers)

        resp = client.get("/api/logs?action=登录", headers=admin_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, list)

    def test_logs_with_username_filter(self, client, admin_headers):
        resp = client.get("/api/logs?username=testadmin", headers=admin_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, list)
        for log in data:
            assert log["username"] == "testadmin"

    def test_logs_limit(self, client, admin_headers):
        resp = client.get("/api/logs?limit=5", headers=admin_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) <= 5
