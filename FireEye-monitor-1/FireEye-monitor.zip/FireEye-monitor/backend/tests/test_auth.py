import pytest


class TestLogin:
    def test_login_success(self, client):
        client.post("/api/auth/register", json={
            "username": "logintest",
            "password": "test123456",
            "email": "logintest@example.com"
        })
        resp = client.post("/api/auth/login", json={
            "username": "logintest",
            "password": "test123456"
        })
        assert resp.status_code == 200
        data = resp.json()
        assert "access_token" in data
        assert data["token_type"] == "bearer"

    def test_login_wrong_password(self, client):
        client.post("/api/auth/register", json={
            "username": "wrongpw",
            "password": "test123456",
            "email": "wrongpw@example.com"
        })
        resp = client.post("/api/auth/login", json={
            "username": "wrongpw",
            "password": "wrongpassword"
        })
        assert resp.status_code == 401
        assert "密码错误" in resp.json()["detail"]

    def test_login_nonexistent_user(self, client):
        resp = client.post("/api/auth/login", json={
            "username": "ghost",
            "password": "whatever"
        })
        assert resp.status_code == 401


class TestRegister:
    def test_register_success(self, client):
        resp = client.post("/api/auth/register", json={
            "username": "newuser",
            "password": "test123456",
            "email": "newuser@example.com"
        })
        assert resp.status_code == 200
        data = resp.json()
        assert "access_token" in data

    def test_register_duplicate_username(self, client):
        client.post("/api/auth/register", json={
            "username": "dupuser",
            "password": "test123456",
            "email": "dup1@example.com"
        })
        resp = client.post("/api/auth/register", json={
            "username": "dupuser",
            "password": "test123456",
            "email": "dup2@example.com"
        })
        assert resp.status_code == 400
        assert "用户名已存在" in resp.json()["detail"]

    def test_register_duplicate_email(self, client):
        client.post("/api/auth/register", json={
            "username": "emaildup1",
            "password": "test123456",
            "email": "same@example.com"
        })
        resp = client.post("/api/auth/register", json={
            "username": "emaildup2",
            "password": "test123456",
            "email": "same@example.com"
        })
        assert resp.status_code == 400
        assert "邮箱已被注册" in resp.json()["detail"]

    def test_register_short_username(self, client):
        resp = client.post("/api/auth/register", json={
            "username": "ab",
            "password": "test123456",
            "email": "short@example.com"
        })
        assert resp.status_code == 400

    def test_register_short_password(self, client):
        resp = client.post("/api/auth/register", json={
            "username": "shortpw",
            "password": "123",
            "email": "shortpw@example.com"
        })
        assert resp.status_code == 400

    def test_register_invalid_email(self, client):
        resp = client.post("/api/auth/register", json={
            "username": "bademail",
            "password": "test123456",
            "email": "notanemail"
        })
        assert resp.status_code == 400


class TestAuthMe:
    def test_get_user_info(self, client, admin_headers):
        resp = client.get("/api/auth/me", headers=admin_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["username"] == "testadmin"
        assert "role" in data

    def test_get_user_info_no_token(self, client):
        resp = client.get("/api/auth/me")
        assert resp.status_code == 401
