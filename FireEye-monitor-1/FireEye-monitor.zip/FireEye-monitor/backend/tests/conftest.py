import os
import sys
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from fastapi.testclient import TestClient

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from backend.database import Base, get_db, User
from backend.config import hash_password, create_access_token
from backend.main import app

TEST_DATABASE_URL = "sqlite:///file:memdb?mode=memory&cache=shared&uri=true"

test_engine = create_engine(
    TEST_DATABASE_URL,
    connect_args={"check_same_thread": False},
    echo=False
)

TestSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=test_engine)


def override_get_db():
    db = TestSessionLocal()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db


@pytest.fixture(autouse=True)
def setup_db():
    Base.metadata.create_all(bind=test_engine)
    yield
    Base.metadata.drop_all(bind=test_engine)


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture
def admin_token(client):
    db = TestSessionLocal()
    admin = User(
        username="testadmin",
        password_hash=hash_password("test123456"),
        role="admin",
        email="testadmin@example.com",
        is_active=True
    )
    db.add(admin)
    db.commit()
    db.close()
    token = create_access_token(data={"sub": "testadmin", "role": "admin"})
    return token


@pytest.fixture
def admin_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}
