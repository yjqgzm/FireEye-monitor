import pytest


class TestDeviceCRUD:
    def test_create_device(self, client, admin_headers):
        resp = client.post("/api/devices", json={
            "device_id": "DEV-001",
            "name": "测试设备",
            "location": "实验室A",
            "scene_type": "laboratory"
        }, headers=admin_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert "id" in data

    def test_create_duplicate_device(self, client, admin_headers):
        client.post("/api/devices", json={
            "device_id": "DEV-DUP",
            "name": "重复设备",
            "location": "实验室B",
            "scene_type": "laboratory"
        }, headers=admin_headers)
        resp = client.post("/api/devices", json={
            "device_id": "DEV-DUP",
            "name": "重复设备2",
            "location": "实验室C",
            "scene_type": "laboratory"
        }, headers=admin_headers)
        assert resp.status_code == 400
        assert "设备ID已存在" in resp.json()["detail"]

    def test_list_devices(self, client, admin_headers):
        client.post("/api/devices", json={
            "device_id": "DEV-LIST",
            "name": "列表设备",
            "location": "实验室D",
            "scene_type": "warehouse"
        }, headers=admin_headers)
        resp = client.get("/api/devices", headers=admin_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, list)
        assert any(d["device_id"] == "DEV-LIST" for d in data)

    def test_update_device(self, client, admin_headers):
        create_resp = client.post("/api/devices", json={
            "device_id": "DEV-UPD",
            "name": "更新前",
            "location": "实验室E",
            "scene_type": "laboratory"
        }, headers=admin_headers)
        device_id = create_resp.json()["id"]
        resp = client.put(f"/api/devices/{device_id}", json={
            "name": "更新后",
            "location": "实验室F"
        }, headers=admin_headers)
        assert resp.status_code == 200

        list_resp = client.get("/api/devices", headers=admin_headers)
        devices = list_resp.json()
        updated = next(d for d in devices if d["id"] == device_id)
        assert updated["name"] == "更新后"
        assert updated["location"] == "实验室F"

    def test_delete_device(self, client, admin_headers):
        create_resp = client.post("/api/devices", json={
            "device_id": "DEV-DEL",
            "name": "删除设备",
            "location": "实验室G",
            "scene_type": "laboratory"
        }, headers=admin_headers)
        device_id = create_resp.json()["id"]
        resp = client.delete(f"/api/devices/{device_id}", headers=admin_headers)
        assert resp.status_code == 200

        list_resp = client.get("/api/devices", headers=admin_headers)
        devices = list_resp.json()
        assert not any(d["id"] == device_id for d in devices)

    def test_device_no_token(self, client):
        resp = client.get("/api/devices")
        assert resp.status_code == 401

    def test_device_non_admin_create(self, client):
        reg_resp = client.post("/api/auth/register", json={
            "username": "normaluser",
            "password": "test123456",
            "email": "normal@example.com"
        })
        token = reg_resp.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}
        resp = client.post("/api/devices", json={
            "device_id": "DEV-NONADMIN",
            "name": "非管理员设备",
            "location": "实验室H",
            "scene_type": "laboratory"
        }, headers=headers)
        assert resp.status_code == 403
