import pytest


class TestGetUsers:
    def test_get_users_admin(self, client, admin_headers):
        resp = client.get("/api/users", headers=admin_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, list)
        assert any(u["username"] == "testadmin" for u in data)

    def test_get_users_no_token(self, client):
        resp = client.get("/api/users")
        assert resp.status_code == 401

    def test_get_users_normal_user_forbidden(self, client):
        reg_resp = client.post("/api/auth/register", json={
            "username": "normalviewer",
            "password": "test123456",
            "email": "normalviewer@example.com"
        })
        token = reg_resp.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}
        resp = client.get("/api/users", headers=headers)
        assert resp.status_code == 403


class TestCreateUser:
    def test_create_user_admin(self, client, admin_headers):
        resp = client.post("/api/users", json={
            "username": "newbyadmin",
            "password": "test123456",
            "role": "user",
            "email": "newbyadmin@example.com"
        }, headers=admin_headers)
        assert resp.status_code == 200
        assert "成功" in resp.json()["message"]

        users_resp = client.get("/api/users", headers=admin_headers)
        usernames = [u["username"] for u in users_resp.json()]
        assert "newbyadmin" in usernames

    def test_create_user_duplicate(self, client, admin_headers):
        client.post("/api/users", json={
            "username": "dupuser",
            "password": "test123456",
            "role": "user",
            "email": "dup1@example.com"
        }, headers=admin_headers)
        resp = client.post("/api/users", json={
            "username": "dupuser",
            "password": "test123456",
            "role": "user",
            "email": "dup2@example.com"
        }, headers=admin_headers)
        assert resp.status_code == 400
        assert "用户名已存在" in resp.json()["detail"]

    def test_create_user_no_token(self, client):
        resp = client.post("/api/users", json={
            "username": "notokenuser",
            "password": "test123456",
            "role": "user",
            "email": "notoken@example.com"
        })
        assert resp.status_code == 401


class TestDeleteUser:
    def test_delete_user_admin(self, client, admin_headers):
        create_resp = client.post("/api/users", json={
            "username": "todelete",
            "password": "test123456",
            "role": "user",
            "email": "todelete@example.com"
        }, headers=admin_headers)
        assert create_resp.status_code == 200

        users_resp = client.get("/api/users", headers=admin_headers)
        target = next(u for u in users_resp.json() if u["username"] == "todelete")
        user_id = target["id"]

        resp = client.delete(f"/api/users/{user_id}", headers=admin_headers)
        assert resp.status_code == 200
        assert "成功" in resp.json()["message"]

    def test_delete_admin_self_forbidden(self, client, admin_headers):
        client.post("/api/users", json={
            "username": "admin",
            "password": "test123456",
            "role": "admin",
            "email": "admin@example.com"
        }, headers=admin_headers)
        users_resp = client.get("/api/users", headers=admin_headers)
        admin_user = next(u for u in users_resp.json() if u["username"] == "admin")
        resp = client.delete(f"/api/users/{admin_user['id']}", headers=admin_headers)
        assert resp.status_code == 400
        assert "不能删除管理员" in resp.json()["detail"]

    def test_delete_user_not_found(self, client, admin_headers):
        resp = client.delete("/api/users/99999", headers=admin_headers)
        assert resp.status_code == 404
