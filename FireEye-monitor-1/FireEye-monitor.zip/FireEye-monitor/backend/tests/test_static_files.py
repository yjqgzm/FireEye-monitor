import pytest


class TestRootEndpoint:
    def test_root_returns_html(self, client):
        resp = client.get("/")
        assert resp.status_code == 200
        assert "text/html" in resp.headers.get("content-type", "")

    def test_root_contains_title(self, client):
        resp = client.get("/")
        assert resp.status_code == 200
        body = resp.text
        assert "火睛智控" in body or "FireGuard" in body or "V2.1" in body


class TestStaticFallback:
    def test_api_path_returns_404(self, client):
        resp = client.get("/api/nonexistent")
        assert resp.status_code == 404

    def test_nonexistent_path_fallback(self, client):
        resp = client.get("/some/random/path")
        assert resp.status_code in (200, 404)
