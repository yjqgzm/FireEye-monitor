import pytest


class TestFullWorkflow:
    def test_register_login_device_data_alert_flow(self, client, admin_headers):
        reg_resp = client.post("/api/auth/register", json={
            "username": "flowuser",
            "password": "test123456",
            "email": "flow@example.com"
        })
        assert reg_resp.status_code == 200
        member_token = reg_resp.json()["access_token"]
        member_headers = {"Authorization": f"Bearer {member_token}"}

        me_resp = client.get("/api/auth/me", headers=member_headers)
        assert me_resp.status_code == 200
        assert me_resp.json()["username"] == "flowuser"
        assert me_resp.json()["role"] == "user"

        create_resp = client.post("/api/devices", json={
            "device_id": "SENSOR_FLOW",
            "name": "集成测试传感器",
            "location": "测试区域A",
            "scene_type": "laboratory"
        }, headers=admin_headers)
        assert create_resp.status_code == 200

        devices_resp = client.get("/api/devices", headers=member_headers)
        assert devices_resp.status_code == 200
        devices = devices_resp.json()
        flow_device = next(d for d in devices if d["device_id"] == "SENSOR_FLOW")
        assert flow_device["scene_type"] == "laboratory"

        data_resp = client.post("/api/data/receive", json={
            "device_id": "SENSOR_FLOW",
            "temperature": 25.0,
            "ambient_temp": 22.0,
            "humidity": 50.0
        })
        assert data_resp.status_code == 200
        assert data_resp.json()["code"] == 200

        realtime_resp = client.get("/api/data/realtime", headers=member_headers)
        assert realtime_resp.status_code == 200
        realtime_data = realtime_resp.json()
        assert any(d["device_id"] == "SENSOR_FLOW" for d in realtime_data)

        history_resp = client.get("/api/data/history", headers=member_headers)
        assert history_resp.status_code == 200
        assert isinstance(history_resp.json(), list)

        alerts_resp = client.get("/api/alerts", headers=member_headers)
        assert alerts_resp.status_code == 200

        stats_resp = client.get("/api/alerts/stats", headers=member_headers)
        assert stats_resp.status_code == 200

    def test_high_temperature_triggers_alert(self, client, admin_headers):
        client.post("/api/devices", json={
            "device_id": "SENSOR_HOT",
            "name": "高温传感器",
            "location": "高温测试区",
            "scene_type": "laboratory"
        }, headers=admin_headers)

        for i in range(4):
            temp = 45.0 + i * 5
            client.post("/api/data/receive", json={
                "device_id": "SENSOR_HOT",
                "temperature": temp,
                "ambient_temp": 22.0,
                "humidity": 40.0
            })

        alerts_resp = client.get("/api/alerts", headers=admin_headers)
        assert alerts_resp.status_code == 200

    def test_user_lifecycle(self, client, admin_headers):
        create_resp = client.post("/api/users", json={
            "username": "lifecycle_user",
            "password": "test123456",
            "role": "user",
            "email": "lifecycle@example.com"
        }, headers=admin_headers)
        assert create_resp.status_code == 200

        login_resp = client.post("/api/auth/login", json={
            "username": "lifecycle_user",
            "password": "test123456"
        })
        assert login_resp.status_code == 200
        user_token = login_resp.json()["access_token"]
        user_headers = {"Authorization": f"Bearer {user_token}"}

        me_resp = client.get("/api/auth/me", headers=user_headers)
        assert me_resp.json()["username"] == "lifecycle_user"

        email_resp = client.put("/api/settings/email", json={
            "new_email": "updated@example.com",
            "password": "test123456"
        }, headers=user_headers)
        assert email_resp.status_code == 200

        pwd_resp = client.put("/api/settings/password", json={
            "old_password": "test123456",
            "new_password": "newpass123"
        }, headers=user_headers)
        assert pwd_resp.status_code == 200

        relogin_resp = client.post("/api/auth/login", json={
            "username": "lifecycle_user",
            "password": "newpass123"
        })
        assert relogin_resp.status_code == 200

    def test_config_and_settings_workflow(self, client, admin_headers):
        configs_resp = client.get("/api/config/alert", headers=admin_headers)
        assert configs_resp.status_code == 200
        initial_configs = configs_resp.json()

        if len(initial_configs) == 0:
            update_resp = client.put("/api/config/alert/laboratory", json={
                "scene_type": "laboratory",
                "level1_threshold": 45.0,
                "level2_threshold": 55.0,
                "level3_threshold": 65.0,
                "rate_threshold": 5.0
            }, headers=admin_headers)
            assert update_resp.status_code == 200

        update_resp = client.put("/api/config/alert/laboratory", json={
            "scene_type": "laboratory",
            "level1_threshold": 55.0
        }, headers=admin_headers)
        assert update_resp.status_code == 200

        verify_resp = client.get("/api/config/alert", headers=admin_headers)
        lab_config = next(c for c in verify_resp.json() if c["scene_type"] == "laboratory")
        assert lab_config["level1_threshold"] == 55.0

        sys_resp = client.put("/api/config/system", json={
            "config_key": "test_workflow_key",
            "config_value": "test_workflow_value"
        }, headers=admin_headers)
        assert sys_resp.status_code == 200

        sys_get_resp = client.get("/api/config/system", headers=admin_headers)
        assert sys_get_resp.json().get("test_workflow_key") == "test_workflow_value"

    def test_data_snapshot_workflow(self, client, admin_headers):
        snapshots_resp = client.get("/api/snapshots", headers=admin_headers)
        assert snapshots_resp.status_code == 200
        initial_count = len(snapshots_resp.json())

        client.post("/api/devices", json={
            "device_id": "SENSOR_SNAP",
            "name": "快照传感器",
            "location": "快照测试区",
            "scene_type": "warehouse"
        }, headers=admin_headers)

        client.post("/api/data/receive", json={
            "device_id": "SENSOR_SNAP",
            "temperature": 30.0,
            "ambient_temp": 22.0,
            "humidity": 45.0
        })

        after_snap_resp = client.get("/api/snapshots", headers=admin_headers)
        assert after_snap_resp.status_code == 200
