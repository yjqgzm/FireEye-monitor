import pytest


class TestGetAlertConfigs:
    def test_get_alert_configs_admin(self, client, admin_headers):
        resp = client.get("/api/config/alert", headers=admin_headers)
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_get_alert_configs_no_token(self, client):
        resp = client.get("/api/config/alert")
        assert resp.status_code == 401

    def test_get_alert_configs_normal_user_forbidden(self, client):
        reg_resp = client.post("/api/auth/register", json={
            "username": "configviewer",
            "password": "test123456",
            "email": "configviewer@example.com"
        })
        token = reg_resp.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}
        resp = client.get("/api/config/alert", headers=headers)
        assert resp.status_code == 403


class TestUpdateAlertConfig:
    def test_update_alert_config_admin(self, client, admin_headers):
        resp = client.put("/api/config/alert/laboratory", json={
            "scene_type": "laboratory",
            "level1_threshold": 50.0
        }, headers=admin_headers)
        assert resp.status_code == 200
        assert "成功" in resp.json()["message"]

        configs_resp = client.get("/api/config/alert", headers=admin_headers)
        configs = configs_resp.json()
        lab_config = next((c for c in configs if c["scene_type"] == "laboratory"), None)
        assert lab_config is not None
        assert lab_config["level1_threshold"] == 50.0

    def test_update_alert_config_no_token(self, client):
        resp = client.put("/api/config/alert/laboratory", json={
            "scene_type": "laboratory",
            "level1_threshold": 50.0
        })
        assert resp.status_code == 401


class TestSystemConfig:
    def test_get_system_configs_admin(self, client, admin_headers):
        resp = client.get("/api/config/system", headers=admin_headers)
        assert resp.status_code == 200
        assert isinstance(resp.json(), dict)

    def test_update_system_config_admin(self, client, admin_headers):
        resp = client.put("/api/config/system", json={
            "config_key": "test_key",
            "config_value": "test_value"
        }, headers=admin_headers)
        assert resp.status_code == 200
        assert "成功" in resp.json()["message"]

        configs_resp = client.get("/api/config/system", headers=admin_headers)
        configs = configs_resp.json()
        assert configs.get("test_key") == "test_value"

    def test_get_system_configs_no_token(self, client):
        resp = client.get("/api/config/system")
        assert resp.status_code == 401
