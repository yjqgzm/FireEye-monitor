import pytest


class TestReceiveSensorData:
    def test_receive_data_device_not_found(self, client):
        resp = client.post("/api/data/receive", json={
            "device_id": "NONEXISTENT",
            "temperature": 25.0,
            "ambient_temp": 22.0,
            "humidity": 50.0
        })
        assert resp.status_code == 200
        assert resp.json()["code"] == 404

    def test_receive_data_success(self, client, admin_headers):
        create_resp = client.post("/api/devices", json={
            "device_id": "SENSOR_TEST",
            "name": "测试传感器",
            "location": "测试位置",
            "scene_type": "laboratory"
        }, headers=admin_headers)
        assert create_resp.status_code == 200

        resp = client.post("/api/data/receive", json={
            "device_id": "SENSOR_TEST",
            "temperature": 25.0,
            "ambient_temp": 22.0,
            "humidity": 50.0
        })
        assert resp.status_code == 200
        assert resp.json()["code"] == 200
        assert "trend" in resp.json()

    def test_receive_data_with_smoke(self, client, admin_headers):
        client.post("/api/devices", json={
            "device_id": "SENSOR_SMOKE",
            "name": "烟雾传感器",
            "location": "测试位置",
            "scene_type": "laboratory"
        }, headers=admin_headers)

        resp = client.post("/api/data/receive", json={
            "device_id": "SENSOR_SMOKE",
            "temperature": 30.0,
            "ambient_temp": 22.0,
            "humidity": 45.0,
            "smoke_value": 700,
            "smoke_detected": 1
        })
        assert resp.status_code == 200
        assert resp.json()["code"] == 200


class TestRealtimeData:
    def test_get_realtime_data_auth(self, client, admin_headers):
        resp = client.get("/api/data/realtime", headers=admin_headers)
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_get_realtime_data_no_token(self, client):
        resp = client.get("/api/data/realtime")
        assert resp.status_code == 401


class TestHistoryData:
    def test_get_history_data_auth(self, client, admin_headers):
        resp = client.get("/api/data/history", headers=admin_headers)
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_get_history_data_no_token(self, client):
        resp = client.get("/api/data/history")
        assert resp.status_code == 401

    def test_get_history_data_with_device_filter(self, client, admin_headers):
        create_resp = client.post("/api/devices", json={
            "device_id": "SENSOR_HIST",
            "name": "历史传感器",
            "location": "测试位置",
            "scene_type": "laboratory"
        }, headers=admin_headers)
        device_id = create_resp.json()["id"]

        client.post("/api/data/receive", json={
            "device_id": "SENSOR_HIST",
            "temperature": 26.0,
            "ambient_temp": 22.0,
            "humidity": 50.0
        })

        resp = client.get(f"/api/data/history?device_id={device_id}", headers=admin_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, list)
        assert len(data) >= 1


class TestClearData:
    def test_clear_data_auth(self, client, admin_headers):
        resp = client.post("/api/data/clear", headers=admin_headers)
        assert resp.status_code == 200
        assert resp.json()["code"] == 200

    def test_clear_data_no_token(self, client):
        resp = client.post("/api/data/clear")
        assert resp.status_code == 401
