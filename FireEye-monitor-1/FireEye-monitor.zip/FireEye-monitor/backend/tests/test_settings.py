import pytest


class TestChangePassword:
    def test_change_password_success(self, client, admin_headers):
        resp = client.put("/api/settings/password", json={
            "old_password": "test123456",
            "new_password": "newpass123"
        }, headers=admin_headers)
        assert resp.status_code == 200
        assert "成功" in resp.json()["message"]

    def test_change_password_wrong_old(self, client, admin_headers):
        resp = client.put("/api/settings/password", json={
            "old_password": "wrongpassword",
            "new_password": "newpass123"
        }, headers=admin_headers)
        assert resp.status_code == 400
        assert "原密码错误" in resp.json()["detail"]

    def test_change_password_too_short(self, client, admin_headers):
        resp = client.put("/api/settings/password", json={
            "old_password": "test123456",
            "new_password": "123"
        }, headers=admin_headers)
        assert resp.status_code == 400
        assert "不能少于6位" in resp.json()["detail"]

    def test_change_password_no_token(self, client):
        resp = client.put("/api/settings/password", json={
            "old_password": "test123456",
            "new_password": "newpass123"
        })
        assert resp.status_code == 401


class TestChangeEmail:
    def test_change_email_success(self, client, admin_headers):
        resp = client.put("/api/settings/email", json={
            "new_email": "newemail@example.com",
            "password": "test123456"
        }, headers=admin_headers)
        assert resp.status_code == 200
        assert "成功" in resp.json()["message"]

    def test_change_email_wrong_password(self, client, admin_headers):
        resp = client.put("/api/settings/email", json={
            "new_email": "wrong@example.com",
            "password": "wrongpassword"
        }, headers=admin_headers)
        assert resp.status_code == 400
        assert "密码验证失败" in resp.json()["detail"]

    def test_change_email_no_token(self, client):
        resp = client.put("/api/settings/email", json={
            "new_email": "notoken@example.com",
            "password": "test123456"
        })
        assert resp.status_code == 401


class TestSnapshots:
    def test_list_snapshots_admin(self, client, admin_headers):
        resp = client.get("/api/snapshots", headers=admin_headers)
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_list_snapshots_no_token(self, client):
        resp = client.get("/api/snapshots")
        assert resp.status_code == 401

    def test_list_snapshots_normal_user_forbidden(self, client):
        reg_resp = client.post("/api/auth/register", json={
            "username": "snapviewer",
            "password": "test123456",
            "email": "snapviewer@example.com"
        })
        token = reg_resp.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}
        resp = client.get("/api/snapshots", headers=headers)
        assert resp.status_code == 403
